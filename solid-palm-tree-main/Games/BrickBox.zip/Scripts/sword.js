"use strict";
/* sword.js — a grantable melee Sword tool: a first-person viewmodel, a quick
   Minecraft-style slash animation, and short-range damage to other players.

   Networked so nearby players HEAR the swing / hit / equip, and the victim takes
   the damage locally (health is locally authoritative — the same model combat
   already uses). Two host rules gate it:
     · netPerms.sword        — may a client use the sword at all
     · netPerms.friendlyFire — may sword hits actually hurt other players

   Loaded after flashlight.js so TOOLS + toolGranted + remoteCubes exist. */

// register the tool (starts un-granted, like the Flashlight — grant it from the ToolRay menu)
TOOLS.push({ name:"Sword", desc:"melee slash" });
const SWORD_TOOL = TOOLS.length - 1;
if (typeof toolGranted !== "undefined") toolGranted[SWORD_TOOL] = false;

const SWORD_MODEL_URL = (typeof SWORD_GLB_B64 !== "undefined")
  ? "data:application/octet-stream;base64," + SWORD_GLB_B64
  : "Assets/Models/Tools/Sword/Sword.glb";
const _SS = "Assets/Sounds/Tools/Sword/";
const SND_WIND = _SS + "Wind.ogg", SND_HIT = _SS + "Hit.ogg", SND_EQUIP = _SS + "Equip.ogg";

const SWORD_DAMAGE   = 20;
const SWORD_RANGE    = 4.2;              // a target must be this close to be hit
const SWORD_ARC      = Math.cos(Math.PI/4);   // and within ~45° of where you look ("in front")
const SWORD_SWING_CD = 1000;             // ms between swings
const SWORD_EQUIP_CD = 750;              // ms after equipping before you can swing
const SWORD_SWING_DUR = 0.28;            // seconds the slash animation takes
const SWORD_HEAR_RANGE = 40;             // how far the swing/hit/equip sounds carry

// host rule helpers
function canUseSword(){ return !netIsClient() || netPerms.anything || netPerms.sword; }
function friendlyFireOn(){ return !!(typeof netPerms !== "undefined" && netPerms.friendlyFire); }

/* ---- model loading (mirrors the flashlight) --------------------------- */
let _swGLB = null, _swGLBPromise = null;
function loadSwordModel(){
  if (_swGLBPromise) return _swGLBPromise;
  _swGLBPromise = (typeof loadGLB === "function" ? loadGLB(SWORD_MODEL_URL) : Promise.reject())
    .then(g => { _swGLB = g; return g; })
    .catch(e => { console.warn("Sword GLB:", e); return null; });
  return _swGLBPromise;
}
function makeSwordMesh(scaleTarget){
  if (!_swGLB) return null;
  const g = _swGLB.clone(true);
  const bb = new T.Box3().setFromObject(g);
  const sz = bb.getSize(new T.Vector3()), mx = Math.max(sz.x, sz.y, sz.z);
  const s = (scaleTarget || 0.7) / mx;
  if (mx > 0) g.scale.set(-s, s, s);   // negative X mirrors the blade
  const bb2 = new T.Box3().setFromObject(g);
  g.position.sub(bb2.getCenter(new T.Vector3()));   // recenter on origin
  return g;
}

/* ---- local first-person viewmodel + swing ----------------------------- */
let _swHolder = null, _swViewModel = null, _swBob = 0;
let _swWasEquipped = false;
let _swSwingT = -1;                      // seconds into the current slash, or -1 when idle
let _lastSwing = 0, _swEquipReadyAt = 0;
function ensureLocalSword(){
  if (_swHolder) return;
  _swHolder = new T.Group(); _swHolder.visible = false; scene.add(_swHolder);
  loadSwordModel().then(() => { const m = makeSwordMesh(1.3); if (m){ _swViewModel = m; _swHolder.add(m); } });
}
// position the held model each frame + play the slash arc
function updateSword(dt){
  const equipped = activeTool === SWORD_TOOL;
  ensureLocalSword();
  // equip transition: play the equip sound (to us + nearby) and start the cooldown
  if (equipped && !_swWasEquipped) onSwordEquipped();
  _swWasEquipped = equipped;

  if (_swHolder) _swHolder.visible = equipped;
  if (!equipped){ _swSwingT = -1; return; }

  const fwd   = new T.Vector3(0,0,-1).applyEuler(camera.rotation);
  const right = new T.Vector3(1,0,0).applyEuler(camera.rotation);
  const down  = new T.Vector3(0,-1,0).applyEuler(camera.rotation);
  _swBob += dt || 0;

  // gentle idle sway + movement bob, same signals the flashlight uses
  let swayX = Math.sin(_swBob * 0.8) * 0.006, swayY = Math.sin(_swBob * 1.1) * 0.008;
  const amp   = (typeof bobAmp   !== "undefined") ? bobAmp   : 0;
  const phase = (typeof bobPhase !== "undefined") ? bobPhase : _swBob * 8;
  swayX += Math.sin(phase)     * amp * 0.42;
  swayY += Math.sin(phase * 2) * amp * 0.28;

  // advance the slash animation
  let slash = 0;
  if (_swSwingT >= 0){
    _swSwingT += dt || 0;
    if (_swSwingT >= SWORD_SWING_DUR) _swSwingT = -1;
    else slash = Math.sin((_swSwingT / SWORD_SWING_DUR) * Math.PI);   // 0→1→0 over the swing
  }

  if (_swHolder){
    // near flashlight position, flipped so blade tilts the other way
    _swHolder.position.copy(camera.position)
      .addScaledVector(right, 0.58 + swayX).addScaledVector(down, 0.28 + swayY).addScaledVector(fwd, 0.52);
    const e = new T.Euler(camera.rotation.x, camera.rotation.y, camera.rotation.z, "YXZ");
    _swHolder.quaternion.setFromEuler(e);
    // flipped: positive Z tilt, sweep goes opposite direction
    const slashQ = new T.Quaternion().setFromEuler(new T.Euler(-slash * 1.7, -slash * 0.5, 0.5 - slash * 1.4, "YXZ"));
    _swHolder.quaternion.multiply(slashQ);
  }
}
function onSwordEquipped(){
  _swEquipReadyAt = performance.now() + SWORD_EQUIP_CD;
  oneShot(SND_EQUIP, 0.7);
  netSwordEquip();
}

/* ---- swinging + hit detection ----------------------------------------- */
// the nearest other player in front of + within reach of the crosshair, or null
function swordTargetId(){
  if (typeof remoteCubes === "undefined") return null;
  const fwd = forwardVec();
  let best = null, bestD = SWORD_RANGE;
  for (const [id, c] of remoteCubes){
    const p = c.mesh.position;
    const dx = p.x - camera.position.x, dy = p.y - camera.position.y, dz = p.z - camera.position.z;
    const d = Math.hypot(dx, dy, dz);
    if (d > SWORD_RANGE || d < 0.001) continue;
    const dot = (dx*fwd.x + dy*fwd.y + dz*fwd.z) / d;   // how "in front" the target is
    if (dot < SWORD_ARC) continue;
    if (d < bestD){ bestD = d; best = id; }
  }
  return best;
}
function swingSword(){
  if (activeTool !== SWORD_TOOL) return;
  if (netIsClient() && !canUseSword()){ toast("The host disabled the sword"); return; }
  const now = performance.now();
  if (now < _swEquipReadyAt) return;                 // still in the equip cooldown
  if (now - _lastSwing < SWORD_SWING_CD) return;     // 1s swing cooldown
  _lastSwing = now;
  _swSwingT = 0;                                     // kick off the slash animation
  oneShot(SND_WIND, 0.85);                           // our own swing whoosh
  netSwordSwing();                                   // let nearby players hear it too

  const victim = swordTargetId();
  if (victim != null && friendlyFireOn()) netSwordHit(victim);   // friendly-fire off = no hit at all
}

/* ---- networking -------------------------------------------------------
   Sounds are positional: each receiver plays them attenuated by distance from
   the event. Damage is delivered to the specific victim, who applies it locally. */
function playSwordFxLocal(type, pos){
  const dist = camera.position.distanceTo(new T.Vector3(pos.x, pos.y, pos.z));
  const vol = Math.max(0, Math.min(1, 1 - dist / SWORD_HEAR_RANGE));
  if (vol <= 0.02) return;
  const src = type === "hit" ? SND_HIT : type === "equip" ? SND_EQUIP : SND_WIND;
  oneShot(src, vol * 0.9, "sfx");
}
function _myPos(){ return { x:camera.position.x, y:camera.position.y, z:camera.position.z }; }
function _playerPos(id){
  if (id === 0 || id === myPlayerId) return _myPos();
  if (typeof hostPeers !== "undefined"){ const pe = hostPeers.find(p => p.id === id); if (pe && pe.state) return { x:pe.state.x, y:pe.state.y, z:pe.state.z }; }
  if (typeof remoteCubes !== "undefined"){ const c = remoteCubes.get(id); if (c) return { x:c.mesh.position.x, y:c.mesh.position.y, z:c.mesh.position.z }; }
  return _myPos();
}
// host: fan an fx event out to peers (optionally skipping the originator)
function hostBroadcastSwordFx(kind, id, pos, exceptId){
  if (typeof hostPeers === "undefined") return;
  const msg = { t:kind, id, x:pos.x, y:pos.y, z:pos.z };
  for (const pe of hostPeers){ if (pe.id === exceptId) continue; send(pe.ch, msg); }
}

function netSwordSwing(){
  const pos = _myPos();
  if (netIsHost()) hostBroadcastSwordFx("swordSwing", 0, pos);
  else if (netIsClient()) send(clientCh, { t:"sword", act:"swing" });
}
function netSwordEquip(){
  const pos = _myPos();
  if (netIsHost()) hostBroadcastSwordFx("swordEquip", 0, pos);
  else if (netIsClient()) send(clientCh, { t:"sword", act:"equip" });
}
function netSwordHit(targetId){
  if (netIsHost()) hostDeliverSwordHit(targetId, 0);
  else if (netIsClient()) send(clientCh, { t:"sword", act:"hit", target:targetId });
}

// host: apply a sword hit — damage the victim + play Hit.ogg for everyone near them
function hostDeliverSwordHit(targetId, attackerId){
  if (!friendlyFireOn()) return;                     // no damage, no sound when off
  const vpos = _playerPos(targetId);
  if (targetId === 0){ if (typeof applyDamage === "function") applyDamage(SWORD_DAMAGE, "sword"); }   // host is the victim
  else if (typeof hostPeers !== "undefined"){ const pe = hostPeers.find(p => p.id === targetId); if (pe) send(pe.ch, { t:"swordHurt" }); }
  hostBroadcastSwordFx("swordHitFx", targetId, vpos);
  playSwordFxLocal("hit", vpos);                     // the host hears it too if nearby
}

// host receives a client's sword action
function hostOnSword(peer, m){
  if (!(netPerms.anything || netPerms.sword)) return;   // permission gate (authoritative)
  const pos = peer.state ? { x:peer.state.x, y:peer.state.y, z:peer.state.z } : _myPos();
  if (m.act === "swing"){
    hostBroadcastSwordFx("swordSwing", peer.id, pos, peer.id);   // to others; not back to the swinger
    playSwordFxLocal("swing", pos);
    remoteSwordSwing(peer.id);
  } else if (m.act === "equip"){
    hostBroadcastSwordFx("swordEquip", peer.id, pos, peer.id);
    playSwordFxLocal("equip", pos);
  } else if (m.act === "hit"){
    hostDeliverSwordHit(m.target, peer.id);
  }
}

// client receives fx / damage from the host
function onNetSwordSwing(m){ if (m.id !== myPlayerId){ playSwordFxLocal("swing", m); remoteSwordSwing(m.id); } }
function onNetSwordEquip(m){ if (m.id !== myPlayerId) playSwordFxLocal("equip", m); }
function onNetSwordHitFx(m){ playSwordFxLocal("hit", m); }
function onNetSwordHurt(){ if (typeof applyDamage === "function") applyDamage(SWORD_DAMAGE, "sword"); }

/* ---- remote players: held sword + slash (rides the flashlight bit table) */
const remoteSword = new Map();           // id -> { holder, model }
const _remoteSwordSwing = new Map();     // id -> seconds into their slash
function remoteSwordSwing(id){ _remoteSwordSwing.set(id, 0); }
function ensureRemoteSword(id){
  let rs = remoteSword.get(id);
  if (!rs){
    const holder = new T.Group(); holder.visible = false; scene.add(holder);
    rs = { holder, model:null };
    remoteSword.set(id, rs);
    loadSwordModel().then(() => { const m = makeSwordMesh(1.6); if (m){ rs.model = m; holder.add(m); } });
  }
  return rs;
}
function dropRemoteSword(id){
  const rs = remoteSword.get(id); if (!rs) return;
  scene.remove(rs.holder); remoteSword.delete(id); _remoteSwordSwing.delete(id);
}
// states: Map id -> flashlight/sword bits (bit2 = sword). Called from the main loop.
function updateRemoteSwords(states, dt){
  if (typeof remoteCubes === "undefined") return;
  for (const [id, c] of remoteCubes){
    const bits = states.get(id) || 0;
    if (!(bits & 4)){ if (remoteSword.has(id)) dropRemoteSword(id); continue; }
    const rs = ensureRemoteSword(id);
    const m = c.mesh;
    const fwd   = new T.Vector3(0,0,-1).applyEuler(new T.Euler(0, c.ry, 0));
    const right = new T.Vector3(1,0,0).applyEuler(new T.Euler(0, c.ry, 0));
    rs.holder.visible = true;
    rs.holder.position.copy(m.position).addScaledVector(right, 1.5).addScaledVector(fwd, 0.25);
    rs.holder.position.y += 0.1;
    // advance their slash if one is playing
    let slash = 0;
    if (_remoteSwordSwing.has(id)){
      let t = _remoteSwordSwing.get(id) + (dt || 0);
      if (t >= SWORD_SWING_DUR) _remoteSwordSwing.delete(id);
      else { _remoteSwordSwing.set(id, t); slash = Math.sin((t / SWORD_SWING_DUR) * Math.PI); }
    }
    // Z tilt makes the swing clearly visible to other players
    rs.holder.quaternion.setFromEuler(new T.Euler(-slash * 1.7, c.ry, 0.4 - slash * 1.2, "YXZ"));
  }
  for (const id of [...remoteSword.keys()]) if (!remoteCubes.has(id)) dropRemoteSword(id);
}

// the tool now exists — refresh the hotbar (won't show until granted)
if (typeof drawTools === "function") drawTools();
