"use strict";
/* flashlight.js — a grantable Flashlight tool with a first-person viewport model,
   a real spotlight beam, multiplayer visibility (others see you holding it + its
   light), and drop/pick-up into your inventory.

   Loaded after wiring.js/gadgets.js so TOOLS + toolGranted + TOOLRAY modes exist. */

// register the tool (starts un-granted, like Wiring — grant it from the ToolRay menu)
TOOLS.push({ name:"Flashlight", desc:"light the way" });
const FLASHLIGHT_TOOL = TOOLS.length - 1;
if (typeof toolGranted !== "undefined") toolGranted[FLASHLIGHT_TOOL] = false;

// Inlined as base64 (like the Radio) so the model loads under file:// — a plain
// fetch of a .glb from file:// is blocked by CORS, so we decode a data: URI instead.
const FL_MODEL_URL = (typeof FLASHLIGHT_GLB_B64 !== "undefined")
  ? "data:application/octet-stream;base64," + FLASHLIGHT_GLB_B64
  : "Assets/Models/Tools/Flashlight/Flashlight.glb";
const FL_TOGGLE_SND = "Assets/Sounds/Tools/Flashlight/Toggle.ogg";
const FL_PICKUP_RANGE = 6;            // how close you must be to pick a dropped light up

let flashlightOn = false;             // local beam state
let _flBob = 0;                       // idle bob phase for the held model
let _flGLB = null, _flGLBPromise = null;
function loadFlashlightModel(){
  if (_flGLBPromise) return _flGLBPromise;
  _flGLBPromise = (typeof loadGLB === "function" ? loadGLB(FL_MODEL_URL) : Promise.reject())
    .then(g => { _flGLB = g; return g; })
    .catch(e => { console.warn("Flashlight GLB:", e); return null; });
  return _flGLBPromise;
}
// a fresh copy of the model, normalized to a sensible size (~0.5 units long)
function makeFlashlightMesh(scaleTarget){
  if (!_flGLB) return null;
  const g = _flGLB.clone(true);
  const bb = new T.Box3().setFromObject(g);
  const sz = bb.getSize(new T.Vector3()), mx = Math.max(sz.x, sz.y, sz.z);
  if (mx > 0) g.scale.setScalar((scaleTarget || 0.5) / mx);
  const bb2 = new T.Box3().setFromObject(g);
  g.position.sub(bb2.getCenter(new T.Vector3()));   // recenter on origin
  return g;
}

/* ---- local first-person model + beam ---------------------------------- */
let _flViewModel = null, _flHolder = null;   // holder groups the model so we can offset it
let _flSpot = null, _flSpotTarget = null;
function ensureLocalFlashlight(){
  if (!_flHolder){
    _flHolder = new T.Group(); _flHolder.visible = false; scene.add(_flHolder);
    loadFlashlightModel().then(() => {
      const m = makeFlashlightMesh(0.5);
      if (m){ _flViewModel = m; _flHolder.add(m); }
    });
  }
  if (!_flSpot){
    _flSpot = new T.SpotLight(0xfff4d0, 0, 55, Math.PI/7, 0.35, 1.2);
    _flSpot.castShadow = false;
    _flSpotTarget = new T.Object3D();
    scene.add(_flSpot); scene.add(_flSpotTarget);
    _flSpot.target = _flSpotTarget;
  }
}
function toggleFlashlight(){
  flashlightOn = !flashlightOn;
  oneShot(FL_TOGGLE_SND, 0.8);
  toast("Flashlight " + (flashlightOn ? "on" : "off"));
}
// position the held model + beam each frame relative to the camera
function updateFlashlight(dt){
  const equipped = activeTool === FLASHLIGHT_TOOL;
  ensureLocalFlashlight();
  if (_flHolder) _flHolder.visible = equipped;
  if (_flSpot) _flSpot.intensity = (equipped && flashlightOn) ? 6.5 : 0;
  if (!equipped){ return; }

  const fwd   = new T.Vector3(0,0,-1).applyEuler(camera.rotation);
  const right = new T.Vector3(1,0,0).applyEuler(camera.rotation);
  const down  = new T.Vector3(0,-1,0).applyEuler(camera.rotation);
  _flBob += dt || 0;

  // Idle: a very slow, gentle breathing sway (always present, tiny).
  let swayX = Math.sin(_flBob * 0.8) * 0.006;
  let swayY = Math.sin(_flBob * 1.1) * 0.008;

  // Movement bob: a classic figure-eight weapon bob, scaled by how fast you're
  // moving. bobAmp (from player.js) is a smoothed 0 (idle) -> ~0.055 (walk) ->
  // ~0.12 (run) signal, and bobPhase is footstep-synced, so the light speeds up
  // and swings wider as you go from walk to run, and eases back smoothly.
  const amp   = (typeof bobAmp   !== "undefined") ? bobAmp   : 0;
  const phase = (typeof bobPhase !== "undefined") ? bobPhase : _flBob * 8;
  swayX += Math.sin(phase)     * amp * 0.42;
  swayY += Math.sin(phase * 2) * amp * 0.28;

  // held down in the bottom-right corner, viewmodel-style
  if (_flHolder){
    _flHolder.position.copy(camera.position)
      .addScaledVector(right, 0.98 + swayX).addScaledVector(down, 0.62 + swayY).addScaledVector(fwd, 0.52);
    _flHolder.quaternion.setFromEuler(camera.rotation);
  }
  if (_flSpot){
    _flSpot.position.copy(camera.position).addScaledVector(fwd, 0.7).addScaledVector(down, 0.15);
    _flSpotTarget.position.copy(camera.position).addScaledVector(fwd, 30);
  }
}

/* ---- input: toggle, drop, pick up ------------------------------------- */
function flashlightPrimary(){ if (activeTool === FLASHLIGHT_TOOL) toggleFlashlight(); }

// drop the held flashlight into the world in front of you, removing it from your inventory
function dropFlashlight(){
  const fwd = new T.Vector3(0,0,-1).applyEuler(camera.rotation);
  const fx = camera.position.x + fwd.x*3, fz = camera.position.z + fwd.z*3;
  // find the ground under that point
  raycaster.set(new T.Vector3(fx, camera.position.y, fz), DOWN); raycaster.far = 50;
  const hit = raycaster.intersectObjects(groundTargets(), false)[0];
  raycaster.far = Infinity;
  const y = hit ? hit.point.y + 0.2 : 1;
  const pos = { x:fx, y, z:fz };
  if (netIsClient()) netClientCmd({ t:"cmd", cmd:"flDrop", x:pos.x, y:pos.y, z:pos.z });
  else hostSpawnFlashDrop(pos);
  flashlightOn = false;
  // remove from inventory + unequip
  if (typeof toolGranted !== "undefined") toolGranted[FLASHLIGHT_TOOL] = false;
  setTool(-1);
  if (typeof drawTools === "function") drawTools();
  oneShot(FL_TOGGLE_SND, 0.5);
  toast("Dropped flashlight");
}

// with an empty hand, click a nearby dropped flashlight to pick it up into your inventory
function tryPickupFlashlight(){
  if (typeof canUseFlashlight === "function" && !canUseFlashlight()){ return false; }
  const drop = aimedFlashDrop();
  if (!drop) return false;
  const dx = drop.x - camera.position.x, dy = drop.y - camera.position.y, dz = drop.z - camera.position.z;
  if (dx*dx + dy*dy + dz*dz > FL_PICKUP_RANGE*FL_PICKUP_RANGE){ toast("Too far — get closer"); return true; }
  if (netIsClient()) netClientCmd({ t:"cmd", cmd:"flPickup", id:drop.id });
  else hostRemoveFlashDrop(drop.id);
  // grant + equip locally (inventory is per-player)
  if (typeof toolGranted !== "undefined") toolGranted[FLASHLIGHT_TOOL] = true;
  if (typeof drawTools === "function") drawTools();
  setTool(FLASHLIGHT_TOOL);
  oneShot(FL_TOGGLE_SND, 0.7);
  toast("Picked up flashlight");
  return true;
}

/* ---- dropped-flashlight world objects (host-authoritative) ------------ */
const flashDrops = [];               // host/single: { id, group, x, y, z }
const flashDropMeshes = [];          // raycast targets (groups)
let _flDropId = 1;
function makeDropVisual(x, y, z){
  const holder = new T.Group(); holder.position.set(x, y, z); scene.add(holder);
  loadFlashlightModel().then(() => {
    const m = makeFlashlightMesh(0.7);
    if (m){ m.rotation.z = Math.PI/2; holder.add(m); }   // lie it on its side
  });
  return holder;
}
function hostSpawnFlashDrop(pos){
  const id = _flDropId++;
  const group = makeDropVisual(pos.x, pos.y, pos.z);
  const drop = { id, group, x:pos.x, y:pos.y, z:pos.z };
  group.userData.flDrop = drop;
  flashDrops.push(drop); flashDropMeshes.push(group);
  if (typeof hostBroadcastFlashDrops === "function") hostBroadcastFlashDrops();
  return drop;
}
function hostRemoveFlashDrop(id){
  const i = flashDrops.findIndex(d => d.id === id);
  if (i < 0) return;
  const d = flashDrops[i];
  scene.remove(d.group);
  const j = flashDropMeshes.indexOf(d.group); if (j >= 0) flashDropMeshes.splice(j, 1);
  flashDrops.splice(i, 1);
  if (typeof hostBroadcastFlashDrops === "function") hostBroadcastFlashDrops();
}
// which dropped flashlight (host list or client ghosts) the crosshair is on
function aimedFlashDrop(){
  raycaster.setFromCamera(CENTER, camera);
  const targets = netIsClient() ? clientFlashDropMeshes : flashDropMeshes;
  if (!targets.length) return null;
  const hits = raycaster.intersectObjects(targets, true);
  if (!hits.length) return null;
  let o = hits[0].object;
  while (o && !(o.userData && o.userData.flDrop)) o = o.parent;
  return o ? o.userData.flDrop : null;
}
// client ghost drops (rendered from the host's broadcast table)
const clientFlashDrops = new Map();       // id -> group
const clientFlashDropMeshes = [];
function applyFlashDrops(list){
  const seen = new Set();
  for (const e of list){
    seen.add(e.id);
    if (!clientFlashDrops.has(e.id)){
      const g = makeDropVisual(e.x, e.y, e.z);
      g.userData.flDrop = { id:e.id, x:e.x, y:e.y, z:e.z };
      clientFlashDrops.set(e.id, g); clientFlashDropMeshes.push(g);
    }
  }
  for (const [id, g] of clientFlashDrops){
    if (seen.has(id)) continue;
    scene.remove(g);
    const j = clientFlashDropMeshes.indexOf(g); if (j >= 0) clientFlashDropMeshes.splice(j, 1);
    clientFlashDrops.delete(id);
  }
}
function clearFlashDrops(){
  for (const d of flashDrops) scene.remove(d.group);
  flashDrops.length = 0; flashDropMeshes.length = 0;
  for (const [id, g] of clientFlashDrops) scene.remove(g);
  clientFlashDrops.clear(); clientFlashDropMeshes.length = 0;
}

/* ---- local player flashlight state for the network -------------------- */
// bit0 = flashlight equipped, bit1 = flashlight on, bit2 = sword equipped
// (the sword rides this same per-player table so others can see it held — see sword.js)
function localFlashlightBits(){
  let b = (activeTool === FLASHLIGHT_TOOL ? 1 : 0) | (flashlightOn ? 2 : 0);
  if (typeof SWORD_TOOL !== "undefined" && activeTool === SWORD_TOOL) b |= 4;
  return b;
}

/* ---- remote players: model to the right + spotlight ------------------- */
// remoteFlash: playerId -> { holder, model, spot, target }
const remoteFlash = new Map();
function ensureRemoteFlash(id){
  let rf = remoteFlash.get(id);
  if (!rf){
    const holder = new T.Group(); holder.visible = false; scene.add(holder);
    const spot = new T.SpotLight(0xfff4d0, 0, 50, Math.PI/7, 0.35, 1.2); spot.castShadow = false;
    const target = new T.Object3D(); scene.add(spot); scene.add(target); spot.target = target;
    rf = { holder, model:null, spot, target };
    remoteFlash.set(id, rf);
    loadFlashlightModel().then(() => { const m = makeFlashlightMesh(0.55); if (m){ rf.model = m; holder.add(m); } });
  }
  return rf;
}
function dropRemoteFlash(id){
  const rf = remoteFlash.get(id); if (!rf) return;
  scene.remove(rf.holder); scene.remove(rf.spot); scene.remove(rf.target);
  remoteFlash.delete(id);
}
// states: Map id -> bits. cubes: the remoteCubes map from net.js
function updateRemoteFlashlights(states){
  if (typeof remoteCubes === "undefined") return;
  for (const [id, c] of remoteCubes){
    const bits = states.get(id) || 0;
    const equipped = !!(bits & 1), on = !!(bits & 2);
    if (!equipped){ if (remoteFlash.has(id)) dropRemoteFlash(id); continue; }
    const rf = ensureRemoteFlash(id);
    const m = c.mesh;
    const fwd   = new T.Vector3(0,0,-1).applyEuler(new T.Euler(0, c.ry, 0));
    const right = new T.Vector3(1,0,0).applyEuler(new T.Euler(0, c.ry, 0));
    // hold it to the player's right, at hand height
    rf.holder.visible = true;
    rf.holder.position.copy(m.position).addScaledVector(right, 0.9).addScaledVector(fwd, 0.3);
    rf.holder.position.y += 0.1;
    rf.holder.quaternion.setFromEuler(new T.Euler(0, c.ry, 0));
    rf.spot.intensity = on ? 6.0 : 0;
    rf.spot.position.copy(rf.holder.position).addScaledVector(fwd, 0.3);
    rf.target.position.copy(m.position).addScaledVector(fwd, 28);
  }
  // remove flashlight visuals for players no longer present
  for (const id of [...remoteFlash.keys()]) if (!remoteCubes.has(id)) dropRemoteFlash(id);
}

// the tool now exists — refresh the hotbar (won't show until granted)
if (typeof drawTools === "function") drawTools();
