"use strict";
/* tools.js — ToolRay (spawn) and GravityRay (grab/punt) plus the aim raycaster. */
const TOOLS = [
  { name:"ToolRay",    desc:"spawn props" },
  { name:"GravityRay", desc:"grab & fling" },
];
let activeTool = 0, selectedProp = 0;   // activeTool -1 = nothing equipped
let weldEnabled = false, weldFirst = null;

const raycaster = new T.Raycaster();
const CENTER = new T.Vector2(0,0), DOWN = new T.Vector3(0,-1,0);
let held = null, holdDist = 8;

const beam = new T.Line(
  new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3()]),
  new T.LineBasicMaterial({ color:0x7cf6c9, transparent:true, opacity:0.85 }));
beam.visible = false; beam.frustumCulled = false; scene.add(beam);

function forwardVec(){ return new T.Vector3(0,0,-1).applyEuler(camera.rotation); }
function aimedProp(){
  raycaster.setFromCamera(CENTER, camera);
  const hits = raycaster.intersectObjects(propMeshes, false);
  return hits.length ? { p:hits[0].object.userData.prop, dist:hits[0].distance } : null;
}
function spawnSelected(){
  const dir = forwardVec();
  const pos = {
    x: camera.position.x + dir.x*6,
    y: Math.max(2, camera.position.y + dir.y*6),
    z: camera.position.z + dir.z*6
  };
  if (netIsClient()){
    if (!canPlace()){ toast("Placing props is disabled by the host"); return; }
    if (typeof canUseItem === "function" && !canUseItem(selectedProp)){ toast("The host blocked that item"); return; }
    netClientCmd({ t:"cmd", cmd:"spawn", ti:selectedProp, pos });   // ask the host to spawn
  } else spawnProp(selectedProp, pos);
  oneShot(S+"Tools/ToolRay/ToolRay.ogg");
}

// primary ToolRay action: welding, then whichever mode is enabled, else spawn
function toolRayPrimary(){
  if (weldEnabled && !netIsClient()){   // welding is host-only for now
    const a = aimedProp();
    if (a){ weldPick(a.p); return; }
  }
  const mode = (typeof toolRayMode !== "undefined") ? toolRayMode : "spawn";
  if (mode === "paint"){ paintPrimary(); return; }
  if (mode === "configure"){ wrenchPrimary(); return; }
  if (mode === "resize"){ startResizeDrag(); return; }   // grab a handle under the crosshair
  if (mode === "move"){ moveRayPrimary(); return; }
  if (mode === "lock"){ lockRayPrimary(); return; }
  if (mode === "clone"){ clonePrimary(); return; }
  spawnSelected();
}
function setWeldHighlight(p, on){
  if (!p) return;
  p.mesh.material.emissive = new T.Color(on ? 0xffbb33 : 0x000000);
  p.mesh.material.emissiveIntensity = on ? 0.5 : 0;
}
function weldPick(p){
  if (!weldFirst){ weldFirst = p; setWeldHighlight(p, true); toast("Weld: select second prop"); }
  else if (p === weldFirst){ setWeldHighlight(p, false); weldFirst = null; toast("Weld cancelled"); }
  else {
    setWeldHighlight(weldFirst, false);
    // weld the two props exactly where they sit — no snapping/repositioning, so
    // touching objects stay put instead of jumping to a computed flush position.
    if (weldProps(weldFirst, p, false)){ oneShot(S+"Tools/ToolRay/ToolRay.ogg"); toast("Welded!"); }
    weldFirst = null;
  }
}

function grab(){
  if (netIsClient()){ if (!canUseTools()){ toast("Tools are disabled by the host"); return; } netClientGrab(); return; }
  const a = aimedProp(); if (!a) return;
  held = a.p; holdDist = Math.max(3, Math.min(28, a.dist));
  if (held.frozen) setFrozen(held, false);
  held.body.wakeUp(); beam.visible = true;
  oneShot(S+"Tools/GravityRay/Open.ogg");          // grab = "use"
}
function releaseGrab(){
  held = null; beam.visible = false;
  if (typeof clientGrabId !== "undefined" && clientGrabId != null) netClientRelease();
}
function punt(){
  if (netIsClient()){ netClientPunt(); return; }
  if (!held) return;
  const dir = forwardVec(); held.body.wakeUp();
  held.body.velocity.set(dir.x*34, dir.y*34+4, dir.z*34);
  held.body.angularVelocity.set((Math.random()-.5)*8,(Math.random()-.5)*8,(Math.random()-.5)*8);
  releaseGrab();
  oneShot(S+"Tools/GravityRay/Close.ogg");          // fired a prop
  toast("Punt!");
}
let lastDry = 0;
function dryFire(){                                   // punt with nothing held
  const t = performance.now();
  if (t - lastDry < 1500) return;                     // 1.5s cooldown
  lastDry = t;
  oneShot(S+"Tools/GravityRay/dryfire.ogg");
}
function updateHeld(){
  if (netIsClient()){ clientUpdateBeam(); return; }   // client beam tracks the interpolated ghost prop
  if (!held){ beam.visible = false; return; }
  const dir = forwardVec();
  const tx = camera.position.x + dir.x*holdDist, ty = camera.position.y + dir.y*holdDist, tz = camera.position.z + dir.z*holdDist;
  const b = held.body; b.wakeUp();
  const k = 9;
  b.velocity.set((tx-b.position.x)*k, (ty-b.position.y)*k, (tz-b.position.z)*k);
  b.angularVelocity.scale(0.82, b.angularVelocity);
  const start = new T.Vector3(-0.5,-0.4,-1).applyEuler(camera.rotation).add(camera.position);
  const arr = beam.geometry.attributes.position.array;
  arr[0]=start.x; arr[1]=start.y; arr[2]=start.z;
  arr[3]=b.position.x; arr[4]=b.position.y; arr[5]=b.position.z;
  beam.geometry.attributes.position.needsUpdate = true; beam.visible = true;
}
