﻿"use strict";
/* net.js — serverless LAN multiplayer over manual-signaling WebRTC.

   No server, no STUN: on a LAN the peer connection uses local host ICE
   candidates directly. Signaling is done by hand — the base64 SDP IS the
   invite code, copy-pasted between players. The flow is JOINER-OFFERS /
   HOST-ANSWERS, so a single host can accept many joiners by repeating a
   paste-offer -> copy-answer step.

   The host is authoritative: it runs the physics sim and broadcasts world
   snapshots. Clients render those snapshots (interpolated), move their own
   camera locally, and send position + tool intent (spawn/delete/freeze,
   grab/punt) back. Every player is drawn to everyone else as a floating,
   uniquely-colored cube with a name tag.

   Perf: snapshots are packed BINARY (DataView) so the client never JSON-parses
   the hot path, and props are INTERPOLATED between the ~25Hz snapshots so
   motion stays smooth at the render framerate. */

let netRole = "single";                 // "single" | "host" | "client"
let myPlayerId = 0, myColor = 0x4a8cff, myName = "Host";

const PLAYER_COLORS = [0x4a8cff,0xff5b5b,0x7cf6c9,0xffd23f,0xc06cff,0xff9f40,0x51e07a,0xff6ec7];
const SNAP_HZ = 25, SNAP_DT = 1/SNAP_HZ;
const MAX_PLAYERS = 5;                   // host + 4 joiners
function netIsFull(){ return hostPeers.length >= MAX_PLAYERS - 1; }

// pre-load face images as plain <img> elements so makeFaceTexForImg can composite them
const faceOpenImg  = new Image();
const faceClosedImg = new Image();
faceOpenImg.src  = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+oHCw8VO5PIgVgAAAqFSURBVHja7Z1tbFtXGcd/t01Li706DSSrEamtdFJc3ELFypCiZCtFGwpaVIo2SMSgUxGbtEgwYOLlw6BICMSb+gEC0/aBTtoUKUzLxhAGtUq3hoFE2y3b2s0tq5eQbFlTzY3zIpdh5+HDOQ6Oe69j3zh+6c5fOmpjX59z7/M/z/Oc8zznngMGBgbOWFvk9VuAe4CD+u/zRoSVgRf4MvAyILrMAF1GNIvoAh4DfgmEV5OI+4AXs4jILkcMD4tkzGTJ5TLwHPAtbVVKgg7gbw5EZMohwwUAv80jozGtNcGVNLBXs+zUyH+BEytt5BrCV5fpuAJccGviG4C/5Kl4UDt2Q8ZS0/5r4MoypEwBNxZb+UeAV20qewvoNrLPS8pntF+dBNIOpHy72Iq3An/MqmBBm6ewkXnBCAJfB/5pQ8jt+X5o2Xy2HmgHfgB8CHgBeBD4l10FIhICdgMeIKT/BYgC88BrwGnLsubfo1qzD/gSkAKeAfqBuWIIyZASBD4IjGpzlUvEfuBmXbboujzAGn3JvNaueeAkcAp4zLKsqfcoMdcBs/nIyEeII7RG3AXcAfh1Q8vVM69v5FngUeBErWiMiNTrzlmfVQCms8qoZVnTpWjPKvLm9gPfBD4KbHJB6DxwUZPyUDVri4gEgV26fGwZQl4CRoARy7JGy3WD+0XktIikZOW4KCKHRKSpGjVCRPaIyGEReVFELhfwPJf1tYf1b+triYyqJUVEgiJyv4gcL5AIO2KO6zqCq2KytM94GGjDITo8NzdHIpHg8uXLpFIpADZt2kR9fT0+n4+1ax2DylN6ePinSvsULcC7gQMlmPSOarN8pFgTVlfANXdpn7HWjojx8XGi0ShjY2NcuHCBZDKpBuLBIM3NzYRCIVpaWmhoaLAjpkkL4CQQu0bIyMxDDui6j5TMr2hTFRWRhVzdnJ2dlUgkIg888ICEw2HHcEFPT4888sgjMjExIamUrcWbE5EfVcp0aZ9xv4i8IaXHG7ru+lLd7GERSTiR0dXVtVxAbbH09fXlI+U5EbmhQoTs0XZ/tXBcRPaU4kZD2pFfpR0nT56U7u7ugsnIlIGBAZmbm3PSkh4R8VTAiR9ezoGnUilJJpOSSCQkHo9LPB6XRCIhyWTSqYPlOvrDhTr5fD5kd9YMfInfGB4e5pVXXilaAIODg+zevZutW7fm+hOPbm9Iz1XKhV3Anqy5xRKk02muXLnC1NQUsViMc+fOMTk5CYDf76e1tZWWlhaamprYsGGD0+ClXrfxnHb2rnvPvSLyVi7d58+fl4MHDxatHZly7NgxSSaTdj3pIRHxl9l3HHLSjlQqJRMTEzIwMCA9PT15feTAwEA+c5zRkkMr8iVO/uPo0aNF+Q47X5JIJCruR0Rkl4gM5iOjr6+vVD5SdFu7lruvNXm+89h9H4/HSSQSrgUxOTlJOp12as8qo7mqdzJV8XicSCRCb29vwZX19vYSiUSIx+NFt1coIdc6bAWUTqeJxWIMDQ0VXeHQ0BCxWMypw62YkKidg21oaMDn87mWgt/vd3J+r5XZodsKKJFIEI1G6e/vL7rC/v5+otGokwVZMSGZfMYSBAIBGhsbXUuhtbWV9evXO7UnlVab6elpxsfHXf9+fHyc6Wn3kfh8hNj2WL/fz44dOwiHi8/o9vT00NLSwrp16wrWyNWUvS5LMDMzw+io+9Hp6OgoMzMzBbdXDCGndYxpiZC8Xi8dHR3s3Lmz6Jvdv38/TU1NdiYrisrbz1aakEq350iIjr6ewiblGAqFOHDgAF1dhS8z6uvro62tjQ0bNth9fQp427IsqbSA6urq2Lhxo+tKN27cSF1dnWtClov2PgbchFop4cnWkvb29kWfEIlEOHv2rKOZ2rt3L52dnWzZssVJOx5GZRLLiVFUpm/JTH3z5s1s27bNdaXbtm1j8+bNdmS8VMhMPS8hlmVNicijwCeAllzT1d7eTiAQoK2tzW34PUP6y5ZlpcvJhmVZ0yIyooW0OGHz+XwEAgHC4bBjJ3NCOBwmEAjYjUJHUendFWsI2rY/CvSi8hdLSNm+fTvNzc1uE1SDwBOohcqVwAhq4UUwoyVer5dQKERnZ2fRhHR2dhIKhfB6vbna8axuq2RhhiYdi7lYwrD0kyLycRFZSwVhF353k17o6uqSSCQis7OzqxN+X2VSqoKMrCDjVQmqDCnd3d15E3DhcFi6u7udyCg6QVXsMqAm4FOo9OTN2Y6+QES1z3gCeL3cfiPPcwWxSeHOzc0RjUYZHh7mzJkzXLp0aXEW7vP5aGxsZMeOHXR0dNiZqlFc5NXdLJTzANfrm9+DWs3tKYCIU3o09TIwU+YhrmtSMsRMTk4yNja2GDxsaGggEAjg9/tziXBNhitCcrRlkx6BZdb2bs8iJzPTz0z63gYuVotW5CHlc6j1uLsKiT3ZDG9HgKeBp9wsbrBK8BAe1NrVNSwNoWdiU/PAbLVpRD6fosnYpy1AsABiprVWPKvJGHG7tNTCIJ+2lH0pqSGkMI0JUqbF1gYGBgYGBgYGBgYGBgYGBgYGBrWC1UqheoHbUPtDvYvaHcegQvACP+b/eedxXOwRZVA6fIWlG3mlgV8YsVQG7cCbXL0642EjmvKbqX2ovLndcpk7jYhWH0Hgu6hNuf6OWrnutEej14hrdbXhO9pZL7ei7zxma8Ci4LS216NHRrcAHwbWZV2/k6zFyXkQR60HPmvEvDJ4gC8A/0btE7hA4a89L6D29I0BtxpRlgbXA78qkoT/oN7veB14CvikEWPpTFZS+4dCEAOOAj7Unr5NwPvJeW3BYGWhk3eBCdTmYmv13zOorcffQe1Q+irwkHbuJ1DLL1uzTF4StfevQZGw8nx+HdDI1TsszOv5Rubdw4Ce+N2WQ+odekhsUIFh8G9sfMsfjGgqh1uARA4hL5gJYWl8iBu8g3qRJ5j1mV/P3ke0CTMoMzptzNYlrT0GFcIzNqQcvwZM142oYyZur7Vn2WNDSBp1FlOtooulUeyv1RopR2zCLZPUZpAxrKMP2c/yuPaPNYObuDoUn0adm1FLPetW4Bz2ybaa0hCvnoPYxb1+WgP3HwR+bjOMz7wveTc1qupnbR5oBpXmrdaOdJ/WipRDhzpGDR+G1s7VKd006v3tatOIB1EvbuaLaj/NNXAy3Q9R+ZHch7unSkZPf0YFS/MREQd+dq1EHYL6oXMf8goq/hUskym6AfgialuPY8A/HDpKdpkGfq8ntmUjwyoTKfcC38v5fEGHVb6BOuLVbd1BHRHwAJ/Vo7wFVDR6E+qgzA8AzcD7Cqw3gTrX5EmWOcSrFgnJ4PvAT2w+v4TKryRtvktp4bzr0PNbUQkxjxZ2Pe73Il7Q7RzXo8HhSpiUchLiRaV3P11lZjUOPA+cQW2Y/3y5taJShIDaqGYQdWBludvO5P+TevQ3gTqN4a9aQ+eqoXdUYmuNO4HfabteaixoM3dFh2umtQbE9f/P6+HtmyzNelYNKrXXyY3A51Ep4kbAbu/YOlQa2aO/X2Mj/GnUcqW09jUxTcQb1Sz0aiSkGL+zBecN0uZrUegGBgYGBgYGBgYGBgYGBgYGBgYGBiXH/wD0WzngCTOC1gAAAABJRU5ErkJggg==";
faceClosedImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+oHCxMlF2tqgVwAAASnSURBVHja7Z1diFRlGMd/q7EUjCQlooIxYC7kLHRhBAULUxQRtQRelBJFFFZ4EfZx44X0caFeRKCFEWF1EeKFEQSFJaV9myhCkWbUWEatnytpObru7HjxPEfPjnPme86cmf3/4GU/2H3PO89/3ud5z/vMeV4QQkQzvc6/nwM8CTzuP/8qE3aGFPAI8CNQ9HYaGJZpLjEMvA+8CmTaKcQKYF9IiHB7TzpcEuN0yC6ngC+B59yrtIQh4JsIIYL2krQAYGMFG/3psybdzAXudJWjLnIB+KrZi/QQT1R54xaB3xt18dcB2yp0/KEHdokx2bW/DpyrIsoxYHG9nS8C9pfp7B9gqWxfUZR7PK6OAIUIUZ6vt+MbgI9CHUy4e8rI5jWTBp4BdpcR5P56O+v3GLLT7zO2AAtl44ZnzcPAJ/4mX+6/i6SvgihpYBbwh7sr0ZwwM4AzwH8yhxAiQRSLxZmyQvJE0X2aRBESRTFFCLmuzty5rgT+xvZ3zgGf08BOqKjd4HcAm7AEzRgwjuVRLvj3pZtuBWBzjGNMA09he3X7sS2N81jm7zMsQdd19AODwCpsA+03IE/1ZE1UOxPDmLPAHi7vZEeNpeBiddUu91xgA5Pzyc20PTGMeUeD48p2gyCDoTjQbDsBLIsjvjbYTnWDKM0KMgYcAt7ymJNK6AwJ2o52D+6qJv//JPAB8Bi2319KARj1d9dJIAf84rEm+Bp3fuBlYDaWqsYDeR44DFwPzCM6T9T2GdLXgqA+gH2aYshfzDQsp7wd2IoluJK4CpzL5aTRiL8xUsDdvki52V9fmJ0+k0UHBFuIpVx/CLmrrEwjRK8wXSYQQoj23rYreZRIUdKygkQREkUxRWi2aMYIIYQQQgghhBBCCCGEEEIIIYToTdrxAeks9kQVJPNhnSnFUiY/k5eVSTpHBntOLyzIJpmlPqa1qJ85wFpgfsnvr5aJ4yeFVTwo9xjxCzJPPPRjjxDfB3wbIcYoOs4iNjFuA94BzhL9kP04VutcorSZAaxqT63VD44BTxNPlYYpye3Ap0RX84kS5k1aeLhJm8kC73pL/NJ9HrAGKz8e1MDKe2BfhtXHihJlG8kud5QCXiwz7q4QZRh4FliNHdOQwkp1PETlw2AOAY8m0IVlsLNRevIkoSHgYyqf0PM9dqRDOgGzYgXwV4Xx9sSOQwo7Cuh4lZVYDlgH3NqBWbME2FtlUbKy1xYBw1VcWNCOYgVe1odcYKtJYxuf64Evqownjx3t1JMsxoqUjdQgzARWw+onrI7j2+7aGp1BKeABX3TkgP9rGMPBTt0/9cV8vQzwiruKeij4LMsBB4DvsEqiM7DCaEFV0eAaDwILsL20G/3e6ZoarnPWl+dvMMVSB/f6iqbR4pljwL++9D7scWA78DVWu7He/vLYKZ0drxvclwBXtgQ7WmkQuIUrq7i1g8A1jmJ7ca+5mEx1QUp9/V3u72cBM4GbsE3MVjCBVdDOucv7GdhV4u4kSA0xJxwP5vtKaXYDceeg35TuSnJ8SLogZVbRIqwQ5YAb/FrfIwsqrI4DR3yVlrgZIIQQQgghhBBCCCGEEEIIIYQQ0VwEz+pHqG/QWEwAAAAASUVORK5CYII=";

// the KO ("knocked out") face shown on a dead player's cube while they wait to respawn
const faceKOImg = new Image();
faceKOImg.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+oHCxMwAagL0hkAAAYrSURBVHja7Z1diBVVHMB/d68fobcWK1w3iS6xoWRCtD0qKERkICFBJOyDPvnUw4IvEcJCsj74YPiQPRhF0WYUmBakkCkJFWVfVO6ubbrVLrur6bq6trvuvXd6OP9rs+N83o+5M+v/B8NVZmbnnP//nP/HOTPngKIoiqJURlZFUBU54CEgL/++KUfFZKq49wFgM9ABtAHNouAM0GRT9k9AJ3AqZYJuA1YDrcBi27k24GlgpdS1LMNzQBfwfqMK/TxwBigCVsBxMmUtfytwPkS9nMeZRhb6ZWAmQmHTxJkKlGEB16t9cFMV914G/gl57amUKWRVBfcUgU8aWejHgP3AFaDg02p+BDakTCE9wGyEnjElymiv9sHVOPVFwH3Ag3IsB5ZKSxkB+oABYDKF0VM78AqwEVjiIqeC1PFz4BDwXUrrqSiaGGqiFzd5SYD+BIaAN8TW5uaBQl4ChsVRzwAfSX2jKvUR4An5rbtctolDs0cZI5JMpZ2/HfUqAd9EiJ42A2elV1nA73HIpcsj9LuRwvDWiVuoWwSOhIjKjokCY8/etwXkHLl51EPsSlnvcc8GSZDrlr2H8SHDPgXYnmKFvOaT5PY7/ElOfE7Q8FFPHAXvsNlJ5zERYHPzwD7gEjAOHAbWJShgOewj3G7btVskQ/dTxvlaZO9hI4kDHjazbLrcopN1wC+O+woihCRFkX0e9fpXBJwDfvZRRAH4EFgTd8HPehSo5GhNAJsw415u148nzHRtwXta4Qiww6cxjogFyTWq4NM+pisvzvC0TwUsMV9JSxC/92lsVz3OjVWQt8RmukrAx8C1ADtbEp9CAntJkI9wRmKbkm5zg45Z4HijW1VAYwtbl0NJa02FiMq4COxMqDLsje1aiLpciNuBh2lNvRG69qm4wsEa8FZAfWYSFLbPiaCmQ5inL6Q3pSmb3xFQr8T5v/UyPOBX6GspHefKS07lVa/fkmZyX8QMKgaZqekUmSg7rweE6y8kqeXsI9w7WeXjRMpMVV4yc786HWt0nTJievorCHFLpGfOJGzIWwSebWRBm4GvAgp52SehGktaeOjBxpCm2AKONrKgqwKy137xFXt8rjmYcGW0Y2b6wvb8QiMDlsdxn1UrOTLuPGbO3a0CVxKqiNXAmwHh+9WkRZEPYwYK7c58Slq9M/zbgPucSTGhCtkd4MQvYSaw/M7HHkkulSTwA8zbegeBZ3wijWMerSmJfOkj7JsS4ufFD3pdd4SEswUzDG+3t0cTWtb3PML4KeZOS3f4+NGpNISPWzFvXlzHzC8nNUHcBPzgUMogt0825TAfILn50mGUmprjtcBz0rPbgXsC8pRZh1k7oGJsbCbfjXl7cxjzacYaFYuiKIqiKIqiKIqiKIqiKIqiKIqiKIqiKIqiKIqiKIqiKIoy/8nU6O+47UgzQ/oX5U+dQtox6/g+BdwV4voi5ovdKNi3T4pC+ePS8lqJl4FRzKfbXwPfRmwozkZ3L2bLjieBFv7fiyWLWY1uJw3YN6WH6OtkJeWod7lPNqKHXGd+rPmeGAvUVOUD+1XmnlRkrrI16CFrMTvtlO122U+UaqT0tLId8xVvrCYrJw7ublHOiIeT9NsX0I9KIrXys9ZjVpNow3xh2yS/y6QhVtpQSraAIQMscLmmF3hUjUQ48pgNBbrkN287t9/FOd+0ds1a1q5ZC7gx2jlk2f7/BzVeLnbBHaiQQeBtj3MXAu6dwGwSVqbVwy9/VmnhmrTDzGEkQEatLbkW+7lFLtefq6YAqpC59IUNfAql4l8e5/aqQmrHgNeJsckxJOM3gss0rfAYHTikCqkdnlGcmKpb/sPCynooZFIVEh+3esiC3YuHXM5XvQmzKiQCo51DS2w9YWU95KkKiUA5wipaxZJHynBaFRIDmVcXFiybucpmsgvdAi9JNlUhNcZtj/jsxPTEuIS742OTF93u+1V7SH341K2TLNt7/3Lx280r9rm5D47X4uGqkNt5B7N0n5OFF8YHsdxlZgHvqujqQw6zcUCU2cEBFVt9aSf82u8l0r27aWrYQ/C2qpY4cp3GjoG8hLFX8d4WsJd0blSTesV0Y4bmJzCTUidI/g5ziqIoyh3Gf7Rnqvzk2NLzAAAAAElFTkSuQmCC";

// the face decal placed on the camera-facing side of every remote player cube — kept for colorSpace ref
const faceTex = new T.TextureLoader().load("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+oHCw8VO5PIgVgAAAqFSURBVHja7Z1tbFtXGcd/t01Li706DSSrEamtdFJc3ELFypCiZCtFGwpaVIo2SMSgUxGbtEgwYOLlw6BICMSb+gEC0/aBTtoUKUzLxhAGtUq3hoFE2y3b2s0tq5eQbFlTzY3zIpdh5+HDOQ6Oe69j3zh+6c5fOmpjX59z7/M/z/Oc8zznngMGBgbOWFvk9VuAe4CD+u/zRoSVgRf4MvAyILrMAF1GNIvoAh4DfgmEV5OI+4AXs4jILkcMD4tkzGTJ5TLwHPAtbVVKgg7gbw5EZMohwwUAv80jozGtNcGVNLBXs+zUyH+BEytt5BrCV5fpuAJccGviG4C/5Kl4UDt2Q8ZS0/5r4MoypEwBNxZb+UeAV20qewvoNrLPS8pntF+dBNIOpHy72Iq3An/MqmBBm6ewkXnBCAJfB/5pQ8jt+X5o2Xy2HmgHfgB8CHgBeBD4l10FIhICdgMeIKT/BYgC88BrwGnLsubfo1qzD/gSkAKeAfqBuWIIyZASBD4IjGpzlUvEfuBmXbboujzAGn3JvNaueeAkcAp4zLKsqfcoMdcBs/nIyEeII7RG3AXcAfh1Q8vVM69v5FngUeBErWiMiNTrzlmfVQCms8qoZVnTpWjPKvLm9gPfBD4KbHJB6DxwUZPyUDVri4gEgV26fGwZQl4CRoARy7JGy3WD+0XktIikZOW4KCKHRKSpGjVCRPaIyGEReVFELhfwPJf1tYf1b+triYyqJUVEgiJyv4gcL5AIO2KO6zqCq2KytM94GGjDITo8NzdHIpHg8uXLpFIpADZt2kR9fT0+n4+1ax2DylN6ePinSvsULcC7gQMlmPSOarN8pFgTVlfANXdpn7HWjojx8XGi0ShjY2NcuHCBZDKpBuLBIM3NzYRCIVpaWmhoaLAjpkkL4CQQu0bIyMxDDui6j5TMr2hTFRWRhVzdnJ2dlUgkIg888ICEw2HHcEFPT4888sgjMjExIamUrcWbE5EfVcp0aZ9xv4i8IaXHG7ru+lLd7GERSTiR0dXVtVxAbbH09fXlI+U5EbmhQoTs0XZ/tXBcRPaU4kZD2pFfpR0nT56U7u7ugsnIlIGBAZmbm3PSkh4R8VTAiR9ezoGnUilJJpOSSCQkHo9LPB6XRCIhyWTSqYPlOvrDhTr5fD5kd9YMfInfGB4e5pVXXilaAIODg+zevZutW7fm+hOPbm9Iz1XKhV3Anqy5xRKk02muXLnC1NQUsViMc+fOMTk5CYDf76e1tZWWlhaamprYsGGD0+ClXrfxnHb2rnvPvSLyVi7d58+fl4MHDxatHZly7NgxSSaTdj3pIRHxl9l3HHLSjlQqJRMTEzIwMCA9PT15feTAwEA+c5zRkkMr8iVO/uPo0aNF+Q47X5JIJCruR0Rkl4gM5iOjr6+vVD5SdFu7lruvNXm+89h9H4/HSSQSrgUxOTlJOp12as8qo7mqdzJV8XicSCRCb29vwZX19vYSiUSIx+NFt1coIdc6bAWUTqeJxWIMDQ0VXeHQ0BCxWMypw62YkKidg21oaMDn87mWgt/vd3J+r5XZodsKKJFIEI1G6e/vL7rC/v5+otGokwVZMSGZfMYSBAIBGhsbXUuhtbWV9evXO7UnlVab6elpxsfHXf9+fHyc6Wn3kfh8hNj2WL/fz44dOwiHi8/o9vT00NLSwrp16wrWyNWUvS5LMDMzw+io+9Hp6OgoMzMzBbdXDCGndYxpiZC8Xi8dHR3s3Lmz6Jvdv38/TU1NdiYrisrbz1aakEq350iIjr6ewiblGAqFOHDgAF1dhS8z6uvro62tjQ0bNth9fQp427IsqbSA6urq2Lhxo+tKN27cSF1dnWtClov2PgbchFop4cnWkvb29kWfEIlEOHv2rKOZ2rt3L52dnWzZssVJOx5GZRLLiVFUpm/JTH3z5s1s27bNdaXbtm1j8+bNdmS8VMhMPS8hlmVNicijwCeAllzT1d7eTiAQoK2tzW34PUP6y5ZlpcvJhmVZ0yIyooW0OGHz+XwEAgHC4bBjJ3NCOBwmEAjYjUJHUendFWsI2rY/CvSi8hdLSNm+fTvNzc1uE1SDwBOohcqVwAhq4UUwoyVer5dQKERnZ2fRhHR2dhIKhfB6vbna8axuq2RhhiYdi7lYwrD0kyLycRFZSwVhF353k17o6uqSSCQis7OzqxN+X2VSqoKMrCDjVQmqDCnd3d15E3DhcFi6u7udyCg6QVXsMqAm4FOo9OTN2Y6+QES1z3gCeL3cfiPPcwWxSeHOzc0RjUYZHh7mzJkzXLp0aXEW7vP5aGxsZMeOHXR0dNiZqlFc5NXdLJTzANfrm9+DWs3tKYCIU3o09TIwU+YhrmtSMsRMTk4yNja2GDxsaGggEAjg9/tziXBNhitCcrRlkx6BZdb2bs8iJzPTz0z63gYuVotW5CHlc6j1uLsKiT3ZDG9HgKeBp9wsbrBK8BAe1NrVNSwNoWdiU/PAbLVpRD6fosnYpy1AsABiprVWPKvJGHG7tNTCIJ+2lH0pqSGkMI0JUqbF1gYGBgYGBgYGBgYGBgYGBgYGBrWC1UqheoHbUPtDvYvaHcegQvACP+b/eedxXOwRZVA6fIWlG3mlgV8YsVQG7cCbXL0642EjmvKbqX2ovLndcpk7jYhWH0Hgu6hNuf6OWrnutEej14hrdbXhO9pZL7ei7zxma8Ci4LS216NHRrcAHwbWZV2/k6zFyXkQR60HPmvEvDJ4gC8A/0btE7hA4a89L6D29I0BtxpRlgbXA78qkoT/oN7veB14CvikEWPpTFZS+4dCEAOOAj7Unr5NwPvJeW3BYGWhk3eBCdTmYmv13zOorcffQe1Q+irwkHbuJ1DLL1uzTF4StfevQZGw8nx+HdDI1TsszOv5Rubdw4Ce+N2WQ+odekhsUIFh8G9sfMsfjGgqh1uARA4hL5gJYWl8iBu8g3qRJ5j1mV/P3ke0CTMoMzptzNYlrT0GFcIzNqQcvwZM142oYyZur7Vn2WNDSBp1FlOtooulUeyv1RopR2zCLZPUZpAxrKMP2c/yuPaPNYObuDoUn0adm1FLPetW4Bz2ybaa0hCvnoPYxb1+WgP3HwR+bjOMz7wveTc1qupnbR5oBpXmrdaOdJ/WipRDhzpGDR+G1s7VKd006v3tatOIB1EvbuaLaj/NNXAy3Q9R+ZHch7unSkZPf0YFS/MREQd+dq1EHYL6oXMf8goq/hUskym6AfgialuPY8A/HDpKdpkGfq8ntmUjwyoTKfcC38v5fEGHVb6BOuLVbd1BHRHwAJ/Vo7wFVDR6E+qgzA8AzcD7Cqw3gTrX5EmWOcSrFgnJ4PvAT2w+v4TKryRtvktp4bzr0PNbUQkxjxZ2Pe73Il7Q7RzXo8HhSpiUchLiRaV3P11lZjUOPA+cQW2Y/3y5taJShIDaqGYQdWBludvO5P+TevQ3gTqN4a9aQ+eqoXdUYmuNO4HfabteaixoM3dFh2umtQbE9f/P6+HtmyzNelYNKrXXyY3A51Ep4kbAbu/YOlQa2aO/X2Mj/GnUcqW09jUxTcQb1Sz0aiSkGL+zBecN0uZrUegGBgYGBgYGBgYGBgYGBgYGBgYGBiXH/wD0WzngCTOC1gAAAABJRU5ErkJggg==");
faceTex.colorSpace = (T.SRGBColorSpace !== undefined) ? T.SRGBColorSpace : faceTex.colorSpace;

// live host-controlled permissions for non-host players. The host owns the
// canonical copy; clients receive a mirror and enforce it locally (the host
// re-checks authoritatively when it processes their commands).
let netPerms = { anything:false, fly:false, tools:true, place:true, grant:false, wiring:true, flashlight:true, sword:true, friendlyFire:true,
                 // item + tool + ToolRay-mode allow-lists. policy: "all" | "whitelist" | "blacklist"
                 itemPolicy:"all", itemList:[], toolPolicy:"all", toolList:[], modePolicy:"all", modeList:[],
                 // combat: who is invulnerable. "all" (default, nobody takes damage) | "none" (everyone
                 // can die, host included) | "host" (only the host is immune) | "some" (only ids in
                 // immunityList are immune). worldSpawn = respawn point.
                 immunityMode:"all", immunityList:[], worldSpawn:null };

// is player `id` currently immune to damage under the host's combat rules?
function playerIsImmune(id){
  const mode = netPerms.immunityMode || "all";
  if (mode === "all") return true;               // everyone immune (no damage)
  if (mode === "none") return false;             // no one immune — everyone can die (host included)
  if (mode === "host") return id === 0;
  if (mode === "some") return (netPerms.immunityList || []).includes(id);
  return true;
}

// mesh peer connections between clients (established via host as relay)
// peerId -> { pc, ch }  — channels to other clients for host-migration re-routing
const meshPeers = new Map();

// last decoded snapshot's prop data — used to reconstruct the world when this client promotes to host
const _hostStateProps = [];
function permTools(){ return netPerms.anything || netPerms.tools; }
function permPlace(){ return permTools() && (netPerms.anything || netPerms.place); }
function permFly(){ return netPerms.anything || netPerms.fly; }
// gates used at call sites — host is never restricted, only clients are
function canUseTools(){ return !netIsClient() || permTools(); }
function canPlace(){ return !netIsClient() || permPlace(); }
function canFly(){ return !netIsClient() || permFly(); }
function canUseFlashlight(){ return !netIsClient() || netPerms.anything || netPerms.flashlight; }

// item (prop type) allow-list — the host's master switch bypasses it
function itemAllowedClient(ti){
  if (netPerms.anything) return true;
  const list = netPerms.itemList || [];
  if (netPerms.itemPolicy === "whitelist") return list.includes(ti);
  if (netPerms.itemPolicy === "blacklist") return !list.includes(ti);
  return true;
}
// tool allow-list (targets the grantable tools: Wiring/Wrench/PaintRay/ResizeRay)
function toolAllowedClient(i){
  if (netPerms.anything) return true;
  const list = netPerms.toolList || [];
  if (netPerms.toolPolicy === "whitelist") return list.includes(i);
  if (netPerms.toolPolicy === "blacklist") return !list.includes(i);
  return true;
}
// ToolRay-mode allow-list (paint / configure / resize)
function modeAllowedClient(id){
  if (netPerms.anything) return true;
  const list = netPerms.modeList || [];
  if (netPerms.modePolicy === "whitelist") return list.includes(id);
  if (netPerms.modePolicy === "blacklist") return !list.includes(id);
  return true;
}
function canUseItem(ti){ return !netIsClient() || itemAllowedClient(ti); }
function canUseToolIdx(i){ return !netIsClient() || toolAllowedClient(i); }
function canUseMode(id){ return !netIsClient() || modeAllowedClient(id); }

// name roster shared across everyone, keyed by player id
const netRoster = new Map();            // id -> { name, color }
function nameOf(id){
  const r = netRoster.get(id);
  if (r && r.name) return r.name;
  return id === 0 ? "Host" : "Player " + id;
}

function netIsClient(){ return netRole === "client"; }
function netIsHost(){ return netRole === "host"; }

/* ---- WebRTC plumbing -------------------------------------------------- */
function newPeer(){ return new RTCPeerConnection({ iceServers: [] }); }
function waitIce(pc){
  return new Promise(res => {
    if (pc.iceGatheringState === "complete") return res();
    const check = () => {
      if (pc.iceGatheringState === "complete"){ pc.removeEventListener("icegatheringstatechange", check); res(); }
    };
    pc.addEventListener("icegatheringstatechange", check);
  });
}
function encodeDesc(d){ return btoa(JSON.stringify({ t:d.type, s:d.sdp })); }
function decodeDesc(code){ const o = JSON.parse(atob(code.trim())); return { type:o.t, sdp:o.s }; }
function send(ch, obj){ if (ch && ch.readyState === "open") ch.send(JSON.stringify(obj)); }
function sendBin(ch, buf){ if (ch && ch.readyState === "open") ch.send(buf); }
const rnd = v => Math.round(v*100)/100;

/* ---- binary snapshot codec -------------------------------------------
   layout (little-endian):
     u8  type(=1)
     u8  numPlayers
     per player  (21B): u8 id, u32 color, f32 x, f32 y, f32 z, f32 yaw
     u16 numProps
     per prop    (32B): u16 netId, u8 type, u8 flags, f32 x,y,z, f32 qx,qy,qz,qw */
function encodeSnap(players){
  const P = players.length, N = props.length;
  const buf = new ArrayBuffer(2 + 21*P + 2 + 32*N);
  const dv = new DataView(buf); let o = 0;
  dv.setUint8(o++, 1); dv.setUint8(o++, P);
  for (const pl of players){
    dv.setUint8(o, pl.id); o += 1;
    dv.setUint32(o, pl.color, true); o += 4;
    dv.setFloat32(o, pl.x, true); o += 4;
    dv.setFloat32(o, pl.y, true); o += 4;
    dv.setFloat32(o, pl.z, true); o += 4;
    dv.setFloat32(o, pl.ry || 0, true); o += 4;
  }
  dv.setUint16(o, N, true); o += 2;
  for (const p of props){
    const b = p.body, q = b.quaternion;
    dv.setUint16(o, p.netId, true); o += 2;
    dv.setUint8(o, p.type); o += 1;
    dv.setUint8(o, (p.frozen ? 1 : 0) | (p.lit ? 2 : 0)); o += 1;   // bit0 frozen, bit1 lit
    dv.setFloat32(o, b.position.x, true); o += 4;
    dv.setFloat32(o, b.position.y, true); o += 4;
    dv.setFloat32(o, b.position.z, true); o += 4;
    dv.setFloat32(o, q.x, true); o += 4;
    dv.setFloat32(o, q.y, true); o += 4;
    dv.setFloat32(o, q.z, true); o += 4;
    dv.setFloat32(o, q.w, true); o += 4;
  }
  return buf;
}
const _snapPlayers = [];                 // reused scratch array to avoid per-snapshot alloc
function decodeSnap(buf){
  const dv = new DataView(buf); let o = 1;
  const P = dv.getUint8(o++);
  _snapPlayers.length = 0;
  for (let i = 0; i < P; i++){
    const id = dv.getUint8(o); o += 1;
    const color = dv.getUint32(o, true); o += 4;
    const x = dv.getFloat32(o, true); o += 4;
    const y = dv.getFloat32(o, true); o += 4;
    const z = dv.getFloat32(o, true); o += 4;
    const ry = dv.getFloat32(o, true); o += 4;
    _snapPlayers.push({ id, color, x, y, z, ry });
  }
  const N = dv.getUint16(o, true); o += 2;
  _seen.clear();
  _hostStateProps.length = 0;
  for (let i = 0; i < N; i++){
    const netId = dv.getUint16(o, true); o += 2;
    const type = dv.getUint8(o); o += 1;
    const flags = dv.getUint8(o); o += 1;
    const x = dv.getFloat32(o, true); o += 4;
    const y = dv.getFloat32(o, true); o += 4;
    const z = dv.getFloat32(o, true); o += 4;
    const qx = dv.getFloat32(o, true); o += 4;
    const qy = dv.getFloat32(o, true); o += 4;
    const qz = dv.getFloat32(o, true); o += 4;
    const qw = dv.getFloat32(o, true); o += 4;
    _hostStateProps.push({ netId, type, flags, x, y, z, qx, qy, qz, qw });
    _seen.add(netId);
    updateClientProp(netId, type, flags, x, y, z, qx, qy, qz, qw);
  }
  pruneClientProps(_seen);
  applyPlayers(_snapPlayers, myPlayerId);
}

/* ---- HOST ------------------------------------------------------------- */
const hostPeers = [];        // { pc, ch, id, color, state, grabId, grabTarget }
let nextPlayerId = 1;

async function hostAcceptOffer(code){
  if (netIsFull()){ toast("Game is full (5 players)"); throw new Error("full"); }
  const pc = newPeer();
  const peer = { pc, ch:null, id:nextPlayerId++, color:PLAYER_COLORS[hostPeers.length+1 & 7], name:"", state:null, grabId:null, grabTarget:null, wireChain:null };
  pc.ondatachannel = e => { peer.ch = e.channel; peer.ch.binaryType = "arraybuffer"; wireHostChannel(peer); };
  await pc.setRemoteDescription(decodeDesc(code));
  const ans = await pc.createAnswer();
  await pc.setLocalDescription(ans);
  await waitIce(pc);
  hostPeers.push(peer);
  return encodeDesc(pc.localDescription);
}
function wireHostChannel(peer){
  const ch = peer.ch;
  ch.onopen = () => {
    send(ch, { t:"hello", id:peer.id, color:peer.color });
    send(ch, { t:"perms", p:netPerms });           // hand the newcomer the current rules
    hostBroadcastLights();                          // and the current light colours
    hostBroadcastPaints(); hostBroadcastSizes();    // paint + resize tables
    hostSyncRoster();
    // Tell every already-connected peer about the newcomer, and the newcomer about them,
    // so they can establish direct mesh WebRTC connections for host-migration failover.
    for (const existing of hostPeers){
      if (existing === peer || !existing.ch || existing.ch.readyState !== "open") continue;
      send(existing.ch, { t:"meshPeer", id:peer.id });
      send(peer.ch,     { t:"meshPeer", id:existing.id });
    }
    if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
    hostBroadcastRadios();
    if (typeof hostBroadcastPropCfg === "function") hostBroadcastPropCfg();
    if (typeof hostBroadcastTime === "function") hostBroadcastTime();
    if (typeof hostBroadcastFlashDrops === "function") hostBroadcastFlashDrops();
    _flashSig = ""; _deathSig = "";   // force a flashlight + death-state resend to the newcomer
    toast("A player joined"); logLine("A player joined the game.", true);
    if (typeof onHostPeerOpen === "function") onHostPeerOpen(peer);   // launcher bridge: live player count
  };
  ch.onmessage = e => hostOnMessage(peer, JSON.parse(e.data));   // clients only ever send small JSON
  ch.onclose = () => hostDropPeer(peer);
}
function hostOnMessage(peer, m){
  if (m.t === "me"){
    peer.state = m;
    peer.grabId = (m.g != null && permTools()) ? m.g : null;   // grab intent rides along; drop it if tools are off
    peer.grabTarget = m.gt || null;
    peer.fl = m.fl || 0;                                        // flashlight bits (equipped/on)
    peer.dead = !!m.dead;                                        // death (knocked-out) flag
  } else if (m.t === "name"){
    peer.name = (m.name || "").slice(0,16) || ("Player " + peer.id);
    hostSyncRoster();
  } else if (m.t === "chat"){
    hostBroadcastChat(peer.id, peer.name || ("Player " + peer.id), m.text);
  } else if (m.t === "cmd"){
    hostRunCmd(m);
  } else if (m.t === "punt"){
    if (!permTools()) return;
    const p = findProp(m.netId);
    if (p){ p.body.wakeUp();
      p.body.velocity.set(m.dir[0]*34, m.dir[1]*34+4, m.dir[2]*34);
      p.body.angularVelocity.set((Math.random()-.5)*8,(Math.random()-.5)*8,(Math.random()-.5)*8); }
    peer.grabId = null; peer.grabTarget = null;
  } else if (m.t === "meshOffer"){
    // relay mesh SDP offer to the target client
    const target = hostPeers.find(pe => pe.id === m.to);
    if (target) send(target.ch, { t:"meshOffer", from:peer.id, sdp:m.sdp });
  } else if (m.t === "meshAnswer"){
    // relay mesh SDP answer back to the initiator
    const target = hostPeers.find(pe => pe.id === m.to);
    if (target) send(target.ch, { t:"meshAnswer", from:peer.id, sdp:m.sdp });
  } else if (m.t === "wire"){
    if (!netPerms.wiring && !netPerms.anything) return;
    if (typeof hostRunWireCmd === "function") hostRunWireCmd(m, peer);
  } else if (m.t === "sword"){
    if (typeof hostOnSword === "function") hostOnSword(peer, m);
  }
}
function findProp(netId){ for (const p of props) if (p.netId === netId) return p; return null; }
function hostRunCmd(m){
  if (m.cmd === "spawn"){ if (!permPlace() || !itemAllowedClient(m.ti)) return; spawnProp(m.ti, m.pos); }   // authoritative perm + item re-check
  else if (m.cmd === "clone"){ if (!permPlace()) return; const p = findProp(m.netId); if (p && itemAllowedClient(p.type) && typeof doClone === "function") doClone(p); }
  else if (m.cmd === "delete"){ if (!permTools()) return; const p = findProp(m.netId); if (p) removeProp(p); }
  else if (m.cmd === "freeze"){ if (!permTools()) return; const p = findProp(m.netId); if (p) setFrozen(p, !p.frozen); }
  else if (m.cmd === "paint"){ if (!permTools()) return; const p = findProp(m.netId); if (p) doPaint(p, m.color); }
  else if (m.cmd === "resize"){ if (!permTools()) return; const p = findProp(m.netId); if (p) doResize(p, m.factor); }
  else if (m.cmd === "resizeAxis"){ if (!permTools()) return; const p = findProp(m.netId); if (p && Array.isArray(m.s)) doResizeAxis(p, m.s, m.face); }
  else if (m.cmd === "config"){ if (!permTools()) return; const p = findProp(m.netId); if (p) doConfigLight(p, m); }
  else if (m.cmd === "configProp"){ if (!permTools()) return; const p = findProp(m.netId); if (p) doConfigProp(p, m); }
  else if (m.cmd === "lockProp"){ if (!permTools()) return; const p = findProp(m.netId); if (p) setFrozen(p, !!m.lock); }
  else if (m.cmd === "moveStart"){ if (!permTools()) return; const p = findProp(m.netId); if (p && !p.frozen){ p._moveClient = true; p.body.type = CANNON.Body.STATIC; p.body.velocity.set(0,0,0); p.body.angularVelocity.set(0,0,0); } }
  else if (m.cmd === "movePos"){ if (!permTools()) return; const p = findProp(m.netId); if (p && p._moveClient){ if (m.x != null) p.body.position.set(m.x, m.y, m.z); if (m.qx != null){ p.body.quaternion.set(m.qx, m.qy, m.qz, m.qw); p.mesh.quaternion.set(m.qx, m.qy, m.qz, m.qw); } } }
  else if (m.cmd === "moveEnd"){ if (!permTools()) return; const p = findProp(m.netId); if (p){ p._moveClient = false; if (m.x != null){ p.body.position.set(m.x, m.y, m.z); p.mesh.position.set(m.x, m.y, m.z); } if (m.qx != null){ p.body.quaternion.set(m.qx, m.qy, m.qz, m.qw); p.mesh.quaternion.set(m.qx, m.qy, m.qz, m.qw); } if (m.frozen) setFrozen(p, true); else { p.body.type = CANNON.Body.DYNAMIC; p.body.mass = p.origMass; p.body.updateMassProperties(); p.body.wakeUp(); } } }
  else if (m.cmd === "radioInteract"){ if (!permTools()) return; const p = findProp(m.netId); if (p && p.type === RADIO && typeof radioInteract === "function") radioInteract(p); }
  else if (m.cmd === "radioOff"){ if (!permTools()) return; const p = findProp(m.netId); if (p && p.type === RADIO && typeof setRadioOn === "function") setRadioOn(p, false, true); }
  else if (m.cmd === "time"){ if (!permTools()) return; if (typeof applyTimeOfDay === "function"){ applyTimeOfDay(m.id); hostBroadcastTime(); } }
  else if (m.cmd === "flDrop"){ if (!(netPerms.anything || netPerms.flashlight)) return; if (typeof hostSpawnFlashDrop === "function") hostSpawnFlashDrop({ x:m.x, y:m.y, z:m.z }); }
  else if (m.cmd === "flPickup"){ if (typeof hostRemoveFlashDrop === "function") hostRemoveFlashDrop(m.id); }
}
function hostDropPeer(peer){
  const i = hostPeers.indexOf(peer); if (i >= 0) hostPeers.splice(i, 1);
  dropCube(peer.id);
  logLine(nameOf(peer.id) + (peer._kicked ? " was kicked." : " left the game."), true);
  netRoster.delete(peer.id);
  hostSyncRoster();
  if (typeof onHostPeerClose === "function") onHostPeerClose(peer);   // launcher bridge: live player count
}
// host kicks a connected player by id: tell them, then tear the connection down
function hostKick(id){
  const peer = hostPeers.find(pe => pe.id === id);
  if (!peer) return;
  peer._kicked = true;
  send(peer.ch, { t:"kicked" });
  toast("Kicked " + nameOf(id));
  try { if (peer.ch) peer.ch.close(); } catch(e){}
  try { if (peer.pc) peer.pc.close(); } catch(e){}
  hostDropPeer(peer);           // close events may not fire after pc.close — drop now
}

// rebuild the roster from host + peers, apply it locally, and push it to everyone
function hostSyncRoster(){
  netRoster.clear();
  netRoster.set(0, { name:myName, color:myColor });
  for (const pe of hostPeers) netRoster.set(pe.id, { name:pe.name || ("Player " + pe.id), color:pe.color });
  const list = [...netRoster].map(([id, r]) => ({ id, name:r.name, color:r.color }));
  for (const pe of hostPeers) send(pe.ch, { t:"roster", list });
  refreshCubeTags();
  if (typeof renderMpMenu === "function" && mpmenuOpen) renderMpMenu();
}
function hostBroadcastPerms(){
  for (const pe of hostPeers) send(pe.ch, { t:"perms", p:netPerms });
}
// broadcast a detonation so clients (who run no physics) can play the blast
function hostBroadcastBoom(pos){
  for (const pe of hostPeers) send(pe.ch, { t:"boom", x:rnd(pos.x), y:rnd(pos.y), z:rnd(pos.z) });
}
// send the Light colour table so clients can tint their ghost lights correctly
function hostBroadcastLights(){
  if (!netIsHost()) return;
  const list = props.filter(p => p.type === LIGHT).map(p => ({ n:p.netId, lc:p.lightColor, bc:p.blockColor, rng:p.lightRange, int:p.lightIntensity }));
  for (const pe of hostPeers) send(pe.ch, { t:"lights", list });
}
// PaintRay colours — colours aren't in the binary snapshot, so stream them as a table
function hostBroadcastPaints(){
  if (!netIsHost()) return;
  const list = props.filter(p => p.paintColor != null).map(p => ({ n:p.netId, c:p.paintColor }));
  for (const pe of hostPeers) send(pe.ch, { t:"paints", list });
}
// ResizeRay scales — per-axis [sx,sy,sz], streamed as a table
function hostBroadcastSizes(){
  if (!netIsHost()) return;
  const list = props.filter(p => (p.sx||1)!==1 || (p.sy||1)!==1 || (p.sz||1)!==1)
                    .map(p => ({ n:p.netId, s:[rnd(p.sx||1), rnd(p.sy||1), rnd(p.sz||1)] }));
  for (const pe of hostPeers) send(pe.ch, { t:"sizes", list });
}
function hostBroadcastChat(id, name, text){
  text = ("" + text).slice(0, 200);
  for (const pe of hostPeers) send(pe.ch, { t:"chat", id, name, text });
  logChatMessage(name, text, id);                // host sees it too
}
function hostBroadcastWireState(){
  if (!netIsHost()) return;
  if (typeof serializeWireStateForNet !== "function") return;
  const data = serializeWireStateForNet();
  const msg = { t:"wireState", nodes:data.nodes, links:data.links };
  for (const pe of hostPeers) send(pe.ch, msg);
}
function hostBroadcastRadios(){
  if (!netIsHost()) return;
  const list = props.filter(p => p.type === RADIO).map(p => ({ n:p.netId, on:!!p.radioOn, song:p.radioSong||0 }));
  for (const pe of hostPeers) send(pe.ch, { t:"radios", list });
}
/* ---- flashlight: per-player held/on state + dropped world objects ------ */
const clientFlashStates = new Map();     // id -> bits (received by clients)
let _flashSig = "";
// gather everyone's flashlight bits into a table and broadcast it when it changes
function hostMaybeBroadcastFlash(){
  if (!netIsHost()) return;
  const list = [];
  if (typeof localFlashlightBits === "function") list.push({ i:0, b:localFlashlightBits() });
  for (const pe of hostPeers) if (pe.fl) list.push({ i:pe.id, b:pe.fl });
  const sig = list.map(e => e.i + ":" + e.b).join(",");
  if (sig === _flashSig) return;
  _flashSig = sig;
  for (const pe of hostPeers) send(pe.ch, { t:"pflash", list });
}
// the flashlight-state map used to render OTHER players' flashlights this frame
function netFlashStates(){
  if (netRole === "host"){
    const map = new Map();
    for (const pe of hostPeers) map.set(pe.id, pe.fl || 0);
    return map;
  }
  if (netRole === "client") return clientFlashStates;
  return _emptyFlashMap;
}
const _emptyFlashMap = new Map();

/* ---- death: per-player "knocked out" flag (mirrors the flashlight table) --- */
const clientDeathStates = new Map();     // id -> 1 while dead (received by clients)
let _deathSig = "";
function hostMaybeBroadcastDeath(){
  if (!netIsHost()) return;
  const list = [];
  if (typeof localDeathBit === "function" && localDeathBit()) list.push(0);
  for (const pe of hostPeers) if (pe.dead) list.push(pe.id);
  const sig = list.join(",");
  if (sig === _deathSig) return;
  _deathSig = sig;
  for (const pe of hostPeers) send(pe.ch, { t:"pdeath", list });
}
// the set of player ids currently dead, used to render OTHER players' KO cubes
function netDeathStates(){
  if (netRole === "host"){
    const s = new Set();
    for (const pe of hostPeers) if (pe.dead) s.add(pe.id);
    return s;
  }
  if (netRole === "client"){
    const s = new Set();
    for (const [id, v] of clientDeathStates) if (v) s.add(id);
    return s;
  }
  return _emptyDeathSet;
}
const _emptyDeathSet = new Set();

// dropped-flashlight table
function hostBroadcastFlashDrops(){
  if (!netIsHost()) return;
  const list = (typeof flashDrops !== "undefined") ? flashDrops.map(d => ({ id:d.id, x:d.x, y:d.y, z:d.z })) : [];
  for (const pe of hostPeers) send(pe.ch, { t:"fdrops", list });
}
// current time-of-day preset
function hostBroadcastTime(){
  if (!netIsHost()) return;
  const id = (typeof currentTime !== "undefined") ? currentTime : "noon";
  for (const pe of hostPeers) send(pe.ch, { t:"time", id });
}
// wrench flags (explodable / collides) — only send props that differ from defaults
function hostBroadcastPropCfg(){
  if (!netIsHost()) return;
  const list = props.filter(p => p.explodable === false || p.collides === false)
                    .map(p => ({ n:p.netId, e:p.explodable !== false, c:p.collides !== false }));
  for (const pe of hostPeers) send(pe.ch, { t:"propcfg", list });
}
function hostRunWireCmd(m, peer){
  // temporarily swap wireChain to this client's last-chained node
  const savedGlobal = wireChain;
  wireChain = peer.wireChain || null;
  if (m.action === "placeNode"){
    if (m.chainFrom != null && m.chainFrom >= 0) wireChain = wireNodes[m.chainFrom] || null;
    const pos = new T.Vector3(m.x, m.y, m.z);
    const prop = (m.propNetId != null) ? findProp(m.propNetId) : null;
    peer.wireChain = addNode(pos, { prop });
  } else if (m.action === "placeButton"){
    peer.wireChain = addNode(new T.Vector3(m.x, m.y, m.z), { button:true });
  } else if (m.action === "placeSwitch"){
    peer.wireChain = addNode(new T.Vector3(m.x, m.y, m.z), { sw:true });
  } else if (m.action === "placeRepeater"){
    if (m.chainFrom != null && m.chainFrom >= 0) wireChain = wireNodes[m.chainFrom] || null;
    peer.wireChain = addNode(new T.Vector3(m.x, m.y, m.z), { rep:true });
  } else if (m.action === "chain"){
    peer.wireChain = wireNodes[m.nodeIdx] || null;
    wireChain = savedGlobal;
    return;
  } else if (m.action === "press"){
    const pos = new T.Vector3(m.x, m.y, m.z);
    let nearest = null, best = 3;
    for (const n of wireNodes){ const d = n.pos.distanceTo(pos); if (d < best){ best = d; nearest = n; } }
    if (nearest){ if (nearest.button) pressButton(nearest); else if (nearest.sw) toggleSwitch(nearest); }
  } else if (m.action === "delete"){
    const pos = new T.Vector3(m.x, m.y, m.z);
    let nearest = null, best = 2;
    for (const n of wireNodes){ const d = n.pos.distanceTo(pos); if (d < best){ best = d; nearest = n; } }
    if (nearest){ if (peer.wireChain === nearest) peer.wireChain = null; deleteNode(nearest); }
  }
  wireChain = savedGlobal;
  hostBroadcastWireState();
}

// spring a peer's grabbed prop toward their aim point — run every frame, like updateHeld
function hostApplyGrabs(){
  for (const pe of hostPeers){
    if (pe.grabId == null || !pe.grabTarget) continue;
    const p = findProp(pe.grabId); if (!p){ pe.grabId = null; continue; }
    if (p.frozen) setFrozen(p, false);
    const b = p.body, t = pe.grabTarget, k = 9;
    b.wakeUp();
    b.velocity.set((t[0]-b.position.x)*k, (t[1]-b.position.y)*k, (t[2]-b.position.z)*k);
    b.angularVelocity.scale(0.82, b.angularVelocity);
  }
}

let snapTimer = 0;
function hostTick(dt){
  hostApplyGrabs();                              // every frame
  snapTimer += dt;
  if (snapTimer < SNAP_DT) return;
  snapTimer = 0;
  _snapPlayers.length = 0;
  _snapPlayers.push({ id:0, color:myColor, x:camera.position.x, y:camera.position.y, z:camera.position.z, ry:camera.rotation.y });
  for (const pe of hostPeers) if (pe.state) _snapPlayers.push({ id:pe.id, color:pe.color, x:pe.state.x, y:pe.state.y, z:pe.state.z, ry:pe.state.ry||0 });
  const buf = encodeSnap(_snapPlayers);
  for (const pe of hostPeers) sendBin(pe.ch, buf);
  applyPlayers(_snapPlayers, 0);                 // host sees everyone else as a cube
  hostMaybeBroadcastFlash();                     // push flashlight held/on changes
  hostMaybeBroadcastDeath();                     // push death (KO) state changes
}

/* ---- CLIENT ----------------------------------------------------------- */
let clientPc = null, clientCh = null, meTimer = 0, _wasKicked = false;
let clientGrabId = null, clientHoldDist = 8;

async function clientCreateOffer(){
  clientPc = newPeer();
  clientCh = clientPc.createDataChannel("game");
  clientCh.binaryType = "arraybuffer";
  clientCh.onopen = onClientConnected;
  clientCh.onmessage = e => { if (typeof e.data === "string") clientOnJson(JSON.parse(e.data)); else decodeSnap(e.data); };
  clientCh.onclose = onClientDisconnected;
  const off = await clientPc.createOffer();
  await clientPc.setLocalDescription(off);
  await waitIce(clientPc);
  return encodeDesc(clientPc.localDescription);
}
async function clientUseAnswer(code){ await clientPc.setRemoteDescription(decodeDesc(code)); }

function onClientConnected(){
  netRole = "client";
  mpmenuOpen = false; mpmenuEl.classList.remove("open");   // leave the menu; drop into the world
  clearAll();                     // drop the local seed scene; the host's world takes over
  if (typeof clearClientWiring === "function") clearClientWiring();
  if (typeof clearFlashDrops === "function") clearFlashDrops();
  clientFlashStates.clear();
  meshPeers.clear();
  send(clientCh, { t:"name", name:myName });
  enterSandbox();
  toast("Connected!");
  if (typeof onClientOpen === "function") onClientOpen();            // launcher bridge: handshake done
}
function onClientDisconnected(){
  if (netRole !== "client") return;

  if (_wasKicked){ _wasKicked = false; netRole = "single"; netRoster.clear(); return; }

  // Save roster before clearing so we know who should become the new host
  const savedRoster = new Map(netRoster);
  const peerIds = [...savedRoster.keys()].filter(id => id !== 0).sort((a, b) => a - b);
  const newHostId = peerIds[0] != null ? peerIds[0] : null;
  const newHostName = newHostId != null
    ? (savedRoster.get(newHostId)?.name || "Player " + newHostId)
    : null;

  netRole = "single";
  netRoster.clear();

  if (newHostId == null || meshPeers.size === 0){
    // Only player, or no mesh connections — just disconnect
    toast("Disconnected from host");
    logLine("Lost connection to the host.", true);
    meshPeers.clear();
    return;
  }

  // Show the big red announcement
  if (typeof logHostLeft === "function") logHostLeft(newHostName);

  if (myPlayerId === newHostId){
    promoteToHost(savedRoster);
  } else {
    switchToMeshHost(newHostId);
  }
}

/* ---- host migration ------------------------------------------------------- */
function reconstructWorldFromCache(){
  clearAll();
  if (typeof clearWiring === "function") clearWiring();
  if (typeof clearClientWiring === "function") clearClientWiring();
  for (const pd of _hostStateProps){
    try {
      const p = spawnProp(pd.type, [pd.x, pd.y, pd.z]);
      if (!p) continue;
      p.body.quaternion.set(pd.qx, pd.qy, pd.qz, pd.qw);
      if (pd.flags & 1) setFrozen(p, true);
      const paint = clientPaintCfg.get(pd.netId);
      if (paint != null) doPaint(p, paint);
      const size = clientSizeCfg.get(pd.netId);
      if (size) doResizeAxis(p, size);
      const lc = clientLightCfg.get(pd.netId);
      if (lc && typeof doConfigLight === "function") doConfigLight(p, { lightColor:lc.lc, blockColor:lc.bc, range:lc.rng, intensity:lc.int });
      const rc = clientRadioCfg.get(pd.netId);
      if (rc && p.type === RADIO && typeof setRadioOn === "function" && rc.on) setRadioOn(p, true, true);
    } catch(e){}
  }
}
function promoteToHost(savedRoster){
  reconstructWorldFromCache();
  netRole = "host";
  myPlayerId = 0;
  myColor = PLAYER_COLORS[0];
  hostPeers.length = 0;
  nextPlayerId = 1;
  for (const [id, mp] of meshPeers){
    if (!mp.ch || mp.ch.readyState !== "open") continue;
    const r = savedRoster.get(id) || {};
    const peer = { pc:mp.pc, ch:mp.ch, id, color:r.color || PLAYER_COLORS[id & 7],
                   name:r.name || ("Player " + id), state:null, grabId:null, grabTarget:null, wireChain:null };
    hostPeers.push(peer);
    nextPlayerId = Math.max(nextPlayerId, id + 1);
    mp.ch.onmessage = e => { if (typeof e.data === "string") hostOnMessage(peer, JSON.parse(e.data)); else decodeSnap(e.data); };
    mp.ch.onclose = () => hostDropPeer(peer);
    send(mp.ch, { t:"hello", id:peer.id, color:peer.color });
    send(mp.ch, { t:"perms", p:netPerms });
  }
  netRoster.set(0, { name:myName, color:myColor });
  for (const pe of hostPeers) netRoster.set(pe.id, { name:pe.name, color:pe.color });
  hostSyncRoster();
  hostBroadcastLights(); hostBroadcastPaints(); hostBroadcastSizes(); hostBroadcastRadios();
  if (typeof updateMpButton === "function") updateMpButton();
}
function switchToMeshHost(newHostId){
  const mp = meshPeers.get(newHostId);
  if (!mp || !mp.ch || mp.ch.readyState !== "open"){
    toast("Could not reach new host — disconnected");
    logLine("Could not connect to the new host.", true);
    if (typeof clearClientWiring === "function") clearClientWiring();
    meshPeers.clear();
    return;
  }
  clientCh = mp.ch;
  clientCh.onmessage = e => { if (typeof e.data === "string") clientOnJson(JSON.parse(e.data)); else decodeSnap(e.data); };
  clientCh.onclose = onClientDisconnected;
  netRole = "client";
}

/* ---- mesh peer setup (client side) --------------------------------------- */
async function clientSetupMesh(peerId){
  const pc = newPeer();
  const ch = pc.createDataChannel("mesh");
  ch.binaryType = "arraybuffer";
  meshPeers.set(peerId, { pc, ch });
  ch.onclose = () => meshPeers.delete(peerId);
  const off = await pc.createOffer();
  await pc.setLocalDescription(off);
  await waitIce(pc);
  send(clientCh, { t:"meshOffer", to:peerId, sdp:pc.localDescription.sdp });
}
async function clientHandleMeshOffer(fromId, sdp){
  const pc = newPeer();
  const mp = { pc, ch:null };
  meshPeers.set(fromId, mp);
  pc.ondatachannel = e => {
    mp.ch = e.channel;
    mp.ch.binaryType = "arraybuffer";
    mp.ch.onclose = () => meshPeers.delete(fromId);
  };
  await pc.setRemoteDescription({ type:"offer", sdp });
  const ans = await pc.createAnswer();
  await pc.setLocalDescription(ans);
  await waitIce(pc);
  send(clientCh, { t:"meshAnswer", to:fromId, sdp:pc.localDescription.sdp });
}
async function clientHandleMeshAnswer(fromId, sdp){
  const mp = meshPeers.get(fromId);
  if (mp) await mp.pc.setRemoteDescription({ type:"answer", sdp });
}
function clientOnJson(m){
  if (m.t === "hello"){ myPlayerId = m.id; myColor = m.color; }
  else if (m.t === "perms"){ applyPerms(m.p); }
  else if (m.t === "roster"){
    netRoster.clear();
    for (const r of m.list) netRoster.set(r.id, { name:r.name, color:r.color });
    refreshCubeTags();
  }
  else if (m.t === "kicked"){ _wasKicked = true; toast("You were kicked by the host"); logLine("You were kicked by the host.", true); }
  else if (m.t === "chat"){ logChatMessage(m.name, m.text, m.id); }
  else if (m.t === "boom"){ boomFx(new T.Vector3(m.x, m.y, m.z)); }
  else if (m.t === "lights"){ applyLightCfg(m.list || []); }
  else if (m.t === "paints"){ applyPaintCfg(m.list || []); }
  else if (m.t === "sizes"){ applySizeCfg(m.list || []); }
  else if (m.t === "meshPeer"){ clientSetupMesh(m.id); }
  else if (m.t === "meshOffer"){ clientHandleMeshOffer(m.from, m.sdp); }
  else if (m.t === "meshAnswer"){ clientHandleMeshAnswer(m.from, m.sdp); }
  else if (m.t === "radios"){ applyRadioCfg(m.list || []); }
  else if (m.t === "propcfg"){ applyPropCfg(m.list || []); }
  else if (m.t === "time"){ if (typeof applyTimeOfDay === "function") applyTimeOfDay(m.id); }
  else if (m.t === "pflash"){ clientFlashStates.clear(); for (const e of (m.list || [])) clientFlashStates.set(e.i, e.b); }
  else if (m.t === "pdeath"){ clientDeathStates.clear(); for (const id of (m.list || [])) clientDeathStates.set(id, 1); }
  else if (m.t === "fdrops"){ if (typeof applyFlashDrops === "function") applyFlashDrops(m.list || []); }
  else if (m.t === "wireState"){ if (typeof applyWireState === "function") applyWireState(m); }
  else if (m.t === "swordSwing"){ if (typeof onNetSwordSwing === "function") onNetSwordSwing(m); }
  else if (m.t === "swordEquip"){ if (typeof onNetSwordEquip === "function") onNetSwordEquip(m); }
  else if (m.t === "swordHitFx"){ if (typeof onNetSwordHitFx === "function") onNetSwordHitFx(m); }
  else if (m.t === "swordHurt"){ if (typeof onNetSwordHurt === "function") onNetSwordHurt(m); }
  else if (m.t === "hostLeaving"){ onClientDisconnected(); }
}
// client-side paint + size tables (ghost props read these; colours/scales aren't in the snapshot)
const clientPaintCfg = new Map();   // netId -> color
const clientSizeCfg  = new Map();   // netId -> scale
const clientRadioCfg = new Map();   // netId -> { on, song }
const clientPropCfg  = new Map();   // netId -> { explodable, collides, lock } (wrench flags, for the config UI)
function applyPropCfg(list){
  for (const e of list){
    clientPropCfg.set(e.n, { explodable:e.e, collides:e.c });
    const cp = clientProps.get(e.n);                 // mirror onto the ghost so the player passes through it
    if (cp) cp.mesh.userData.noCollide = e.c === false;
  }
}
function applyPaintCfg(list){
  for (const e of list){
    clientPaintCfg.set(e.n, e.c);
    const cp = clientProps.get(e.n); if (cp) cp.mesh.material.color.setHex(e.c);
  }
}
function applySizeCfg(list){
  for (const e of list){
    clientSizeCfg.set(e.n, e.s);
    const cp = clientProps.get(e.n); if (cp) cp.mesh.scale.set(e.s[0], e.s[1], e.s[2]);
  }
}
function applyClientRadio(cp, on, song){
  if (!cp) return;
  const prevSong = cp.radioSong;
  cp.radioOn = !!on; cp.radioSong = song || 0;
  const path = "Assets/Sounds/Props/Radio/Song" + (cp.radioSong + 1) + ".mp3";
  if (on){
    // Stop previous audio when song changed or audio isn't playing yet
    if (cp._radioAudio && (prevSong !== cp.radioSong || cp._radioAudio.paused)){
      try { cp._radioAudio.pause(); cp._radioAudio.src = ""; } catch(e){}
      cp._radioAudio = null;
    }
    if (!cp._radioAudio){
      cp._radioAudio = new Audio(path);
      cp._radioAudio.loop = true; cp._radioAudio.volume = 0.6 * (typeof catGain === "function" ? catGain("music") : 1);
      cp._radioAudio.play().catch(() => {});
    }
  } else if (!on && cp._radioAudio){
    try { cp._radioAudio.pause(); cp._radioAudio.src = ""; } catch(e){}
    cp._radioAudio = null;
  }
}
function applyRadioCfg(list){
  for (const e of list){
    clientRadioCfg.set(e.n, { on:e.on, song:e.song||0 });
    applyClientRadio(clientProps.get(e.n), e.on, e.song);
  }
}

// apply a permission update from the host and immediately enforce it
function applyPerms(p){
  netPerms = p;
  if (!netIsClient()) return;
  if (!permFly() && flyMode){ flyMode = false; velY = 0; logLine("The host disabled flying.", true); }
  if (!permTools()){ if (clientIsGrabbing()) netClientRelease(); if (activeTool >= 0) setTool(-1); }
  else if (activeTool >= 2 && !toolAllowedClient(activeTool)){ setTool(-1); toast("The host restricted that tool"); }
  if (typeof FLASHLIGHT_TOOL !== "undefined" && activeTool === FLASHLIGHT_TOOL && !canUseFlashlight()){ setTool(-1); if (typeof flashlightOn !== "undefined") flashlightOn = false; logLine("The host disabled the flashlight.", true); }
  if (typeof SWORD_TOOL !== "undefined" && activeTool === SWORD_TOOL && typeof canUseSword === "function" && !canUseSword()){ setTool(-1); logLine("The host disabled the sword.", true); }
  // drop a ToolRay mode the host just restricted
  if (typeof toolRayMode !== "undefined" && toolRayMode !== "spawn" && !modeAllowedClient(toolRayMode) && typeof setToolRayMode === "function") setToolRayMode("spawn");
  // combat rules may have changed (immunity scope / world spawn) — let health react
  if (typeof onCombatRulesChanged === "function") onCombatRulesChanged();
}

/* ---- chat ------------------------------------------------------------- */
// called from chat.js for ordinary (non-slash) lines while networked
function netSendChat(text){
  if (netRole === "host"){
    text = ("" + text).slice(0, 200);
    for (const pe of hostPeers) send(pe.ch, { t:"chat", id:0, name:myName, text });
    logLine(myName + ": " + text);   // host's own message — no notification sound
  } else if (netRole === "client") send(clientCh, { t:"chat", text });
}
function clientTick(dt){
  meTimer += dt;
  if (meTimer < SNAP_DT) return;
  meTimer = 0;
  const m = { t:"me", x:rnd(camera.position.x), y:rnd(camera.position.y), z:rnd(camera.position.z), ry:rnd(camera.rotation.y) };
  if (typeof localFlashlightBits === "function") m.fl = localFlashlightBits();
  if (typeof localDeathBit === "function" && localDeathBit()) m.dead = 1;
  if (clientGrabId != null){
    const dir = forwardVec();
    m.g = clientGrabId;
    m.gt = [ rnd(camera.position.x + dir.x*clientHoldDist),
             rnd(camera.position.y + dir.y*clientHoldDist),
             rnd(camera.position.z + dir.z*clientHoldDist) ];
  }
  send(clientCh, m);
}
function netClientCmd(obj){ send(clientCh, obj); }

/* ---- client GravityRay (aim locally, host applies the physics) -------- */
function clientIsGrabbing(){ return clientGrabId != null; }
function netClientGrab(){
  const a = aimedProp(); if (!a || a.p.netId == null) return false;
  clientGrabId = a.p.netId; clientHoldDist = Math.max(3, Math.min(28, a.dist));
  beam.visible = true;
  oneShot(S+"Tools/GravityRay/Open.ogg");
  return true;
}
function netClientRelease(){ if (clientGrabId != null){ clientGrabId = null; beam.visible = false; } }
function netClientPunt(){
  if (clientGrabId == null) return;
  const dir = forwardVec();
  netClientCmd({ t:"punt", netId:clientGrabId, dir:[dir.x, dir.y, dir.z] });
  netClientRelease();
  oneShot(S+"Tools/GravityRay/Close.ogg"); toast("Punt!");
}
function netClientScroll(delta){
  if (clientGrabId == null) return false;
  clientHoldDist = Math.max(3, Math.min(28, clientHoldDist - Math.sign(delta)*1.4));
  return true;
}
// draw the client's beam to the (interpolated) grabbed ghost prop
function clientUpdateBeam(){
  if (clientGrabId == null){ beam.visible = false; return; }
  const cp = clientProps.get(clientGrabId);
  if (!cp){ netClientRelease(); return; }
  const start = new T.Vector3(-0.5,-0.4,-1).applyEuler(camera.rotation).add(camera.position);
  const arr = beam.geometry.attributes.position.array;
  arr[0]=start.x; arr[1]=start.y; arr[2]=start.z;
  arr[3]=cp.mesh.position.x; arr[4]=cp.mesh.position.y; arr[5]=cp.mesh.position.z;
  beam.geometry.attributes.position.needsUpdate = true; beam.visible = true;
}

/* ---- client-side ghost props (render only, interpolated) -------------- */
const clientProps = new Map();      // netId -> { mesh, tx, ty, tz, tq }
const _seen = new Set();
function updateClientProp(id, ti, flags, x, y, z, qx, qy, qz, qw){
  let cp = clientProps.get(id);
  if (!cp){
    cp = makeClientProp(id, ti);
    cp.mesh.position.set(x, y, z);          // first sight: snap, then interpolate afterwards
    cp.mesh.quaternion.set(qx, qy, qz, qw);
    if (clientPaintCfg.has(id)) cp.mesh.material.color.setHex(clientPaintCfg.get(id));   // known paint/size overrides
    if (clientSizeCfg.has(id)){ const s = clientSizeCfg.get(id); cp.mesh.scale.set(s[0], s[1], s[2]); }
    clientProps.set(id, cp);
  }
  cp.tx = x; cp.ty = y; cp.tz = z;
  cp.tq.set(qx, qy, qz, qw);
  const frozen = !!(flags & 1), lit = !!(flags & 2);
  if (ti === LIGHT && cp._emit){          // ghost Light mirrors the host's lit state
    applyClientLight(cp, lit);
  } else {
    cp.mesh.material.emissiveIntensity = 0;
  }
}
function pruneClientProps(seen){
  for (const [id, cp] of clientProps){
    if (seen.has(id)) continue;
    if (cp._emit) unregisterLight(cp._emit);
    if (cp._radioAudio){ try { cp._radioAudio.pause(); cp._radioAudio.src = ""; } catch(e){} cp._radioAudio = null; }
    scene.remove(cp.mesh);
    const i = propMeshes.indexOf(cp.mesh); if (i >= 0) propMeshes.splice(i, 1);
    clientProps.delete(id);
  }
}
function makeClientProp(id, ti){
  const t = TYPES[ti];
  const mesh = new T.Mesh(propGeometry(ti),
    new T.MeshStandardMaterial({ color:t.color, roughness:t.roughness, metalness:t.metalness||0, emissive:new T.Color(0x000000), emissiveIntensity:0 }));
  mesh.castShadow = mesh.receiveShadow = true;
  mesh.userData.prop = { footMat:t.mat, netId:id, _client:true, type:ti };   // enough for aiming + footsteps + resize handles
  scene.add(mesh); propMeshes.push(mesh);
  const cp = { mesh, tx:0, ty:0, tz:0, tq:new T.Quaternion() };
  if (ti === LIGHT){
    const cfg = clientLightCfg.get(id) || {};
    cp.lightColor = cfg.lc != null ? cfg.lc : lightDefaults.lightColor;
    cp.blockColor = cfg.bc != null ? cfg.bc : lightDefaults.blockColor;
    ensureLightPool();
    cp._emit = { mesh, color:cp.lightColor, on:false, range:(cfg.rng != null ? cfg.rng : null), intensity:(cfg.int != null ? cfg.int : null) };   // ghost joins the shared light pool
    registerLight(cp._emit);
    mesh.material.color.setHex(cp.blockColor);
    applyClientLight(cp, false);
  }
  if (ti === RADIO){
    cp.radioOn = false; cp.radioSong = 0; cp._radioAudio = null;
    const rCfg = clientRadioCfg.get(id);
    if (rCfg) applyClientRadio(cp, rCfg.on, rCfg.song);
    mesh.material.transparent = true; mesh.material.opacity = 0; mesh.material.depthWrite = false;
    if (typeof loadGLB === "function"){
      // use the inlined model (same as the host in props.js) so the radio renders
      // identically for clients — a bare URL can fail to resolve in their context
      const _radioUrl = (typeof RADIO_GLB_B64 !== "undefined")
        ? "data:application/octet-stream;base64," + RADIO_GLB_B64
        : "Assets/Models/Radio/Radio.glb";
      loadGLB(_radioUrl).then(glbGroup => {
        if (!clientProps.has(id)) return;
        const bb = new T.Box3().setFromObject(glbGroup);
        const sz = bb.getSize(new T.Vector3()), mx = Math.max(sz.x, sz.y, sz.z);
        if (mx > 0) glbGroup.scale.setScalar(0.8 / mx);
        const bb2 = new T.Box3().setFromObject(glbGroup);
        glbGroup.position.sub(bb2.getCenter(new T.Vector3()));
        mesh.add(glbGroup);
      }).catch(() => {});
    }
  }
  // apply any known wrench collision flag so the player passes through no-collision ghosts
  const _pc = (typeof clientPropCfg !== "undefined") && clientPropCfg.get(id);
  if (_pc) mesh.userData.noCollide = _pc.collides === false;
  return cp;
}
// paint a ghost light on the client (no physics — visuals only)
function applyClientLight(cp, on){
  cp.mesh.material.color.setHex(cp.blockColor);
  cp.mesh.material.emissive.setHex(on ? cp.lightColor : 0x000000);
  cp.mesh.material.emissiveIntensity = on ? 0.95 : 0;
  if (cp._emit){ cp._emit.on = on; cp._emit.color = cp.lightColor; }
}
// host → client light colour table (colours change rarely, so JSON not the binary hot path)
const clientLightCfg = new Map();     // netId -> { lc, bc }
function applyLightCfg(list){
  for (const e of list){
    clientLightCfg.set(e.n, { lc:e.lc, bc:e.bc, rng:e.rng, int:e.int });
    const cp = clientProps.get(e.n);
    if (cp && cp._emit){ cp.lightColor = e.lc; cp.blockColor = e.bc;
      cp._emit.range = e.rng; cp._emit.intensity = e.int;   // per-light range/brightness on the ghost
      applyClientLight(cp, cp._emit.on); }
  }
}
function netRenderProps(dt){
  const k = Math.min(1, dt*22);
  for (const cp of clientProps.values()){
    const m = cp.mesh;
    m.position.x += (cp.tx - m.position.x)*k;
    m.position.y += (cp.ty - m.position.y)*k;
    m.position.z += (cp.tz - m.position.z)*k;
    m.quaternion.slerp(cp.tq, k);
  }
}

/* ---- remote player cubes + name tags (host + client) ------------------ */
const remoteCubes = new Map();      // playerId -> { mesh, tag, tx, ty, tz }
function applyPlayers(players, selfId){
  for (const pl of players){
    if (pl.id === selfId) continue;               // never draw your own body
    let c = remoteCubes.get(pl.id);
    if (!c){ c = makeCube(pl.id, pl.color); remoteCubes.set(pl.id, c); }
    c.tx = pl.x; c.ty = pl.y; c.tz = pl.z; c.tRy = pl.ry || 0; c.live = true;
  }
  // drop cubes for players absent from this snapshot
  for (const [id, c] of remoteCubes){
    if (id === selfId) continue;
    if (!players.some(p => p.id === id)) dropCube(id);
  }
}
function makeFaceTexForImg(color, img){
  const sz = (img && img.naturalWidth) || 128;
  const canvas = document.createElement("canvas");
  canvas.width = sz; canvas.height = sz;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#" + color.toString(16).padStart(6, "0");
  ctx.fillRect(0, 0, sz, sz);
  if (img) ctx.drawImage(img, 0, 0, sz, sz);
  const tex = new T.CanvasTexture(canvas);
  tex.colorSpace = (T.SRGBColorSpace !== undefined) ? T.SRGBColorSpace : tex.colorSpace;
  return tex;
}
const BLINK_DIST_SQ = 30 * 30;   // only blink players within 30 units
function scheduleBlink(c){
  const delay = 20000 + Math.random() * 30000;
  c._blinkTimer = setTimeout(() => {
    if (!remoteCubes.has(c.id)) return;
    const p = c.mesh.position;
    const dx = camera.position.x - p.x, dz = camera.position.z - p.z;
    if (dx*dx + dz*dz < BLINK_DIST_SQ){
      const mat = c.mesh.material[5];
      mat.map = c.faceTexClosed; mat.needsUpdate = true;
      setTimeout(() => {
        if (!remoteCubes.has(c.id)) return;
        mat.map = c.faceTexOpen; mat.needsUpdate = true;
      }, 500);
    }
    scheduleBlink(c);
  }, delay);
}
function makeCube(id, color){
  const body = new T.MeshStandardMaterial({ color, roughness:0.5, emissive:new T.Color(color), emissiveIntensity:0.28 });
  // face decal on the camera-facing side (local -Z = the direction the player looks)
  const faceTexOpen   = makeFaceTexForImg(color, faceOpenImg);
  const faceTexClosed = makeFaceTexForImg(color, faceClosedImg);
  const faceTexKO     = makeFaceTexForImg(color, faceKOImg);
  const face = new T.MeshStandardMaterial({ color:0xffffff, map:faceTexOpen,
                                            roughness:0.5, emissive:new T.Color(color), emissiveIntensity:0.15 });
  // BoxGeometry material order: +X, -X, +Y, -Y, +Z, -Z
  const mats = [body, body, body, body, body, face];
  const mesh = new T.Mesh(new T.BoxGeometry(1.4,1.4,1.4), mats);
  mesh.castShadow = true; scene.add(mesh);
  const tag = makeNameSprite(nameOf(id), color); scene.add(tag);
  const cube = { mesh, tag, id, color, tx:0, ty:3, tz:0, ry:0, tRy:0, faceTexOpen, faceTexClosed, faceTexKO, dead:false, vy:0, bubble:null, _bubbleTimer:null };
  scheduleBlink(cube);
  return cube;
}
// rebuild every cube's floating name tag from the current roster (names arrive after cubes)
function refreshCubeTags(){
  for (const c of remoteCubes.values()){
    const r = netRoster.get(c.id);
    const color = r ? r.color : c.color;
    if (c.tag.material.map) c.tag.material.map.dispose();
    c.tag.material.map = makeNameSprite(nameOf(c.id), color).material.map;
    c.tag.material.needsUpdate = true;
  }
}
/* ---- Chat bubbles ------------------------------------------------------- */
function makeBubbleSprite(text){
  const W = 512, H = 128;
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const x = c.getContext("2d");
  x.font = "bold 26px system-ui,sans-serif";
  // word-wrap at 420px
  const maxW = 420, words = text.split(' ');
  const lines = []; let line = '';
  for (const w of words){
    const test = line ? line + ' ' + w : w;
    if (x.measureText(test).width > maxW && line){ lines.push(line); line = w; }
    else line = test;
  }
  if (line) lines.push(line);
  const lineH = 30, pad = 14;
  const bh = Math.min(lines.length, 3) * lineH + pad * 2;
  const bw = Math.min(W - 20, Math.max(...lines.map(l => x.measureText(l).width)) + pad * 2);
  const bx = (W - bw) / 2, by = (H - bh) / 2;
  // background bubble
  x.fillStyle = "rgba(0,0,0,0.72)";
  x.beginPath();
  if (x.roundRect) x.roundRect(bx, by, bw, bh, 10); else x.rect(bx, by, bw, bh);
  x.fill();
  // tail triangle pointing down
  x.beginPath();
  x.moveTo(W/2 - 8, by + bh); x.lineTo(W/2 + 8, by + bh); x.lineTo(W/2, by + bh + 10);
  x.fillStyle = "rgba(0,0,0,0.72)"; x.fill();
  // text
  x.textAlign = "center"; x.textBaseline = "middle"; x.fillStyle = "#ffffff";
  const visLines = lines.slice(0, 3);
  visLines.forEach((l, i) => x.fillText(l, W/2, by + pad + lineH * i + lineH/2));
  const tex = new T.CanvasTexture(c);
  tex.colorSpace = (T.SRGBColorSpace !== undefined) ? T.SRGBColorSpace : tex.colorSpace;
  const sp = new T.Sprite(new T.SpriteMaterial({ map:tex, transparent:true, depthTest:false, opacity:1 }));
  sp.scale.set(4.2, 1.05, 1); sp.renderOrder = 1002;
  return sp;
}

function showChatBubble(id, text){
  const c = remoteCubes.get(id); if (!c) return;
  // Remove old bubble if any
  if (c.bubble){ if (c.bubble.material.map) c.bubble.material.map.dispose(); c.bubble.material.dispose(); scene.remove(c.bubble); }
  clearTimeout(c._bubbleTimer);
  c.bubble = makeBubbleSprite(text);
  c.bubble.position.copy(c.mesh.position).y += 3.6;
  scene.add(c.bubble);
  // Fade out after 5s over 0.6s
  c._bubbleTimer = setTimeout(() => {
    const sp = c.bubble; if (!sp) return;
    const t0 = performance.now();
    function fade(){ const age = performance.now() - t0; sp.material.opacity = Math.max(0, 1 - age / 600);
      if (sp.material.opacity > 0) requestAnimationFrame(fade);
      else { if (c.bubble === sp){ scene.remove(sp); if (sp.material.map) sp.material.map.dispose(); sp.material.dispose(); c.bubble = null; } }
    }
    requestAnimationFrame(fade);
  }, 5000);
}

function makeNameSprite(text, color){
  const c = document.createElement("canvas"); c.width = 256; c.height = 64;
  const x = c.getContext("2d");
  x.font = "bold 34px system-ui,sans-serif"; x.textAlign = "center"; x.textBaseline = "middle";
  x.lineWidth = 6; x.strokeStyle = "rgba(0,0,0,.85)"; x.strokeText(text, 128, 34);
  x.fillStyle = "#" + color.toString(16).padStart(6,"0"); x.fillText(text, 128, 34);
  const tex = new T.CanvasTexture(c);
  const sp = new T.Sprite(new T.SpriteMaterial({ map:tex, transparent:true, depthTest:false }));
  sp.scale.set(3.2, 0.8, 1); sp.renderOrder = 1000;
  return sp;
}
function dropCube(id){
  const c = remoteCubes.get(id); if (!c) return;
  clearTimeout(c._blinkTimer); clearTimeout(c._bubbleTimer);
  scene.remove(c.mesh); scene.remove(c.tag);
  if (c.tag.material.map) c.tag.material.map.dispose();
  if (c.bubble){ scene.remove(c.bubble); if (c.bubble.material.map) c.bubble.material.map.dispose(); c.bubble.material.dispose(); }
  remoteCubes.delete(id);
}
function netRenderPlayers(dt){
  const k = Math.min(1, dt*12);
  const deadSet = (typeof netDeathStates === "function") ? netDeathStates() : _emptyDeathSet;
  for (const c of remoteCubes.values()){
    const m = c.mesh;
    const isDead = deadSet.has(c.id);
    if (isDead && !c.dead){                          // just died: show KO face, start a physical fall
      c.dead = true; c.vy = 0;
      const mat = m.material[5]; mat.map = c.faceTexKO; mat.needsUpdate = true;
    } else if (!isDead && c.dead){                   // respawned: restore normal face + snapshot follow
      c.dead = false; c.vy = 0;
      const mat = m.material[5]; mat.map = c.faceTexOpen; mat.needsUpdate = true;
    }
    if (c.dead){
      // stop floating — the cube becomes "physical" and drops to the ground, tumbling as it goes
      c.vy -= 24 * dt;                               // gravity (matches player GRAV)
      m.position.y += c.vy * dt;
      if (m.position.y < 1){ m.position.y = 1; c.vy = 0; }   // rest on the floor
      m.rotation.x += dt * 2.4; m.rotation.z += dt * 1.6;    // topple over
    } else {
      m.position.x += (c.tx - m.position.x)*k;
      m.position.y += (c.ty - m.position.y)*k;
      m.position.z += (c.tz - m.position.z)*k;
      // face the player's actual look direction (shortest-path angle lerp), no more spinning
      let d = c.tRy - c.ry;
      d = Math.atan2(Math.sin(d), Math.cos(d));      // wrap to [-π, π]
      c.ry += d * k;
      m.rotation.set(0, c.ry, 0);
    }
    c.tag.position.set(m.position.x, m.position.y + 1.5, m.position.z);
    if (c.bubble) c.bubble.position.set(m.position.x, m.position.y + 3.6, m.position.z);
  }
}

/* ---- per-frame entry point (called from the main loop) ---------------- */
function netTick(dt){
  if (netRole === "host"){ hostTick(dt); netRenderPlayers(dt); }
  else if (netRole === "client"){ clientTick(dt); netRenderProps(dt); netRenderPlayers(dt); }
}

/* ---- shared helpers used by the menu UI ------------------------------- */
function enterSandbox(){ menu.style.display = "none"; renderer.domElement.requestPointerLock(); }
function copyText(str){
  if (navigator.clipboard) navigator.clipboard.writeText(str).then(()=>toast("Copied!")).catch(()=>toast("Select & copy manually"));
  else toast("Select & copy manually");
}

/* ---- full-screen Multiplayer menu (Host / Join / Settings) ------------ */
const mpmenuEl = document.getElementById("mpmenu");
const mpSecEl = document.getElementById("mpsections");
const mpHeadEl = mpmenuEl.querySelector("#mpheader h2");
const mpBodyEl = document.getElementById("mpbody");
const mpBtn = document.getElementById("mpbtn");
let mpmenuOpen = false, mpSection = "host";
let mpFromTitle = false;                 // opened from the title screen (host not yet in the world)

const MP_SECTIONS = [
  { id:"host",     name:"Multiplayer Host" },
  { id:"join",     name:"Multiplayer Join" },
  { id:"settings", name:"Multiplayer Settings" },
];

// live host/single flag so the in-game button and world-io show for the right people
function updateMpButton(){ mpBtn.style.display = netIsHost() ? "block" : "none"; }

function openMpMenu(fromTitle){
  if (mpmenuOpen) return;
  mpmenuOpen = true; mpFromTitle = !!fromTitle;
  mpSection = netIsClient() ? "join" : "host";
  mpmenuEl.classList.add("open");
  renderMpMenu();
  if (locked) document.exitPointerLock();
}
function closeMpMenu(){
  if (!mpmenuOpen) return;
  mpmenuOpen = false;
  mpmenuEl.classList.remove("open");
  uiClose();
  if (!mpFromTitle && netRole !== "single") renderer.domElement.requestPointerLock();
}
uiBtn(document.getElementById("mpclose"), closeMpMenu);

function renderMpMenu(){
  mpSecEl.innerHTML = '<div class="lbl">MULTIPLAYER</div>';
  MP_SECTIONS.forEach(s => {
    const el = document.createElement("div");
    el.className = "tmsec" + (s.id===mpSection?" on":"");
    el.textContent = s.name;
    uiBtn(el, () => { mpSection = s.id; renderMpMenu(); });
    mpSecEl.appendChild(el);
  });
  const sec = MP_SECTIONS.find(s => s.id===mpSection);
  mpHeadEl.textContent = sec ? sec.name.toUpperCase() : "";
  mpBodyEl.innerHTML = "";
  if (mpSection === "host") renderHostSection();
  else if (mpSection === "join") renderJoinSection();
  else renderSettingsSection();
}

function panel(){ const p = document.createElement("div"); p.className = "mppanel"; mpBodyEl.appendChild(p); return p; }
function btn(label, primary, onClick){
  const b = document.createElement("span"); b.className = "mpbtn" + (primary?"":" ghost"); b.textContent = label;
  uiBtn(b, onClick); return b;
}

function renderHostSection(){
  const p = panel();
  p.innerHTML =
    `<h3>Host a game</h3>` +
    `<p>Serverless LAN play — you are the server. Set your name, enter the world, then add players by pasting the code each one sends you and returning the answer.</p>` +
    `<div class="step">YOUR NAME</div>`;
  const nameIn = document.createElement("input"); nameIn.className = "txt"; nameIn.maxLength = 16;
  nameIn.value = myName; nameIn.placeholder = "Host";
  nameIn.addEventListener("input", () => { myName = nameIn.value.slice(0,16) || "Host"; if (netIsHost()) hostSyncRoster(); });
  p.appendChild(nameIn);

  const enterRow = document.createElement("div"); enterRow.className = "mprow";
  if (mpFromTitle) enterRow.appendChild(btn("ENTER WORLD AS HOST", true, () => { becomeHost(); closeMpMenu(); enterSandbox(); }));
  p.appendChild(enterRow);

  const step1 = document.createElement("div"); step1.className = "step"; step1.textContent = "1 · PASTE A JOINER'S CODE"; p.appendChild(step1);
  const offerIn = document.createElement("textarea"); offerIn.placeholder = "Paste the code a joiner sent you…"; p.appendChild(offerIn);
  const step2 = document.createElement("div"); step2.className = "step"; step2.textContent = "2 · SEND THIS ANSWER BACK"; p.appendChild(step2);
  const answerOut = document.createElement("textarea"); answerOut.readOnly = true; answerOut.placeholder = "Your answer appears here…"; p.appendChild(answerOut);

  const row = document.createElement("div"); row.className = "mprow";
  row.appendChild(btn("GENERATE ANSWER", true, async () => {
    if (!offerIn.value.trim()) return toast("Paste the joiner's code first");
    if (netIsFull()) return toast("Game is full (" + MAX_PLAYERS + " players)");
    becomeHost();
    try { answerOut.value = await hostAcceptOffer(offerIn.value); answerOut.select(); toast("Answer ready — send it back"); }
    catch(err){ toast("Bad code"); }
  }));
  row.appendChild(btn("COPY ANSWER", false, () => copyText(answerOut.value)));
  p.appendChild(row);

  // connected players
  const count = netIsHost() ? netRoster.size : 1;
  const rl = document.createElement("div"); rl.className = "step";
  rl.textContent = "PLAYERS ONLINE · " + count + "/" + MAX_PLAYERS + (netIsFull() ? " · FULL" : "");
  p.appendChild(rl);
  const ul = document.createElement("ul"); ul.className = "mproster";
  const roster = netIsHost() ? [...netRoster] : [[0,{name:myName,color:myColor}]];
  for (const [id, r] of roster){
    const li = document.createElement("li");
    li.innerHTML = `<span class="dot" style="background:${css(r.color)}"></span><span style="flex:1">${r.name}${id===0?" (you)":""}</span>`;
    if (netIsHost() && id !== 0){
      const kick = document.createElement("span");
      kick.className = "mpbtn ghost"; kick.style.cssText = "padding:4px 12px;font-size:11px;color:#ff8a8a;border-color:rgba(255,91,91,.5)";
      kick.textContent = "KICK";
      uiBtn(kick, () => { hostKick(id); renderMpMenu(); });
      li.appendChild(kick);
    }
    ul.appendChild(li);
  }
  p.appendChild(ul);
}

function renderJoinSection(){
  const p = panel();
  p.innerHTML =
    `<h3>Join a game</h3>` +
    `<p>Set your name and send your invite code to the host. Paste the answer they return, then connect — you'll drop into their world.</p>` +
    `<div class="step">YOUR NAME</div>`;
  const nameIn = document.createElement("input"); nameIn.className = "txt"; nameIn.maxLength = 16;
  nameIn.value = netIsClient() ? myName : ""; nameIn.placeholder = "Player";
  nameIn.addEventListener("input", () => { myName = nameIn.value.slice(0,16) || "Player"; });
  p.appendChild(nameIn);

  const step1 = document.createElement("div"); step1.className = "step"; step1.textContent = "1 · SEND THIS CODE TO THE HOST"; p.appendChild(step1);
  const offerOut = document.createElement("textarea"); offerOut.readOnly = true; offerOut.placeholder = "Press GENERATE to make your invite code…"; p.appendChild(offerOut);
  const step2 = document.createElement("div"); step2.className = "step"; step2.textContent = "2 · PASTE THE HOST'S ANSWER"; p.appendChild(step2);
  const answerIn = document.createElement("textarea"); answerIn.placeholder = "Paste the answer the host sent back…"; p.appendChild(answerIn);

  const row = document.createElement("div"); row.className = "mprow";
  row.appendChild(btn("GENERATE CODE", true, async () => {
    offerOut.value = "generating…";
    try { offerOut.value = await clientCreateOffer(); offerOut.select(); }
    catch(err){ offerOut.value = "failed to create code"; }
  }));
  row.appendChild(btn("COPY MY CODE", false, () => copyText(offerOut.value)));
  row.appendChild(btn("CONNECT", true, async () => {
    if (!answerIn.value.trim()) return toast("Paste the host's answer first");
    try { await clientUseAnswer(answerIn.value); toast("Connecting…"); }
    catch(err){ toast("Bad answer code"); }
  }));
  p.appendChild(row);
}

const PERM_ROWS = [
  { key:"anything", lab:"Allow anything",  sub:"Master switch — players can do everything the host can" },
  { key:"tools",    lab:"Use tools",       sub:"ToolRay & GravityRay: grab, punt, freeze, delete" },
  { key:"place",    lab:"Place props",     sub:"Spawn new props with the ToolRay (needs Use tools)" },
  { key:"grant",    lab:"Grant tools",     sub:"Allow players to grant themselves tools using the ToolRay" },
  { key:"wiring",   lab:"Use wiring",      sub:"Place wire nodes, buttons, switches and press wired buttons" },
  { key:"flashlight", lab:"Use flashlight", sub:"Equip, toggle and drop the flashlight tool" },
  { key:"sword",    lab:"Use sword",       sub:"Equip and swing the melee sword" },
  { key:"fly",      lab:"Fly",             sub:"Use the /fly command" },
];
function renderSettingsSection(){
  const p = panel();
  p.innerHTML = `<h3>Player permissions</h3><p>These apply live to everyone except you. Toggle them any time — connected players are updated instantly.</p>`;
  PERM_ROWS.forEach(r => {
    const row = document.createElement("div"); row.className = "permrow";
    const left = document.createElement("div");
    left.innerHTML = `<div class="lab">${r.lab}</div><div class="sub">${r.sub}</div>`;
    const master = r.key !== "anything" && netPerms.anything;      // master override forces others on/disabled
    const on = r.key === "anything" ? netPerms.anything : (netPerms.anything || netPerms[r.key]);
    const sw = document.createElement("div"); sw.className = "tsw" + (on?" on":"");
    if (master) sw.style.opacity = "0.5";
    uiBtn(sw, () => {
      if (master) return;                                          // locked on while "Allow anything" is set
      netPerms[r.key] = !netPerms[r.key];
      if (netIsHost()) hostBroadcastPerms(); else applyPerms(netPerms);
      renderMpMenu();
    });
    row.appendChild(left); row.appendChild(sw);
    p.appendChild(row);
  });

  // ---- item + tool allow-lists (blacklist / whitelist) ----
  const commit = () => { if (netIsHost()) hostBroadcastPerms(); else applyPerms(netPerms); renderMpMenu(); };
  renderPolicyBlock(p, "Item access",
    "Restrict which props players may spawn.", "itemPolicy", "itemList",
    TYPES.map((t,i) => ({ i, name:t.name })), commit);
  renderPolicyBlock(p, "Tool access",
    "Restrict which grantable tools players may use.", "toolPolicy", "toolList",
    TOOLS.map((t,i) => ({ i, name:t.name })).filter(e => e.i >= 2), commit);
  if (typeof TOOLRAY_MODES !== "undefined")
    renderPolicyBlock(p, "ToolRay mode access",
      "Restrict which ToolRay modes players may enable (Paint / Configure / Resize).", "modePolicy", "modeList",
      TOOLRAY_MODES.map(m => ({ i:m.id, name:m.name })), commit);
}

// a policy selector (All / Whitelist / Blacklist) plus a toggle grid of entries
function renderPolicyBlock(p, title, sub, polKey, listKey, entries, commit){
  const head = document.createElement("div"); head.className = "step"; head.textContent = title.toUpperCase(); p.appendChild(head);
  const desc = document.createElement("div"); desc.className = "sub"; desc.style.margin = "0 0 8px"; desc.textContent = sub; p.appendChild(desc);
  const locked = netPerms.anything;
  const modeRow = document.createElement("div"); modeRow.className = "tmfilters"; modeRow.style.marginBottom = "10px";
  [["all","All"],["whitelist","Whitelist"],["blacklist","Blacklist"]].forEach(([id,lab]) => {
    const c = document.createElement("div"); c.className = "chip" + (netPerms[polKey]===id?" on":"");
    if (locked) c.style.opacity = "0.5";
    c.textContent = lab;
    uiBtn(c, () => { if (locked) return; netPerms[polKey] = id; commit(); });
    modeRow.appendChild(c);
  });
  p.appendChild(modeRow);
  if (netPerms[polKey] === "all" || locked) return;   // nothing to pick when unrestricted
  const listLabel = netPerms[polKey] === "whitelist" ? "Allowed:" : "Blocked:";
  const ll = document.createElement("div"); ll.className = "sub"; ll.style.margin = "0 0 6px"; ll.textContent = listLabel; p.appendChild(ll);
  const grid = document.createElement("div"); grid.className = "tmfilters";
  entries.forEach(e => {
    const inList = (netPerms[listKey] || []).includes(e.i);
    const c = document.createElement("div"); c.className = "chip" + (inList?" on":"");
    c.textContent = e.name;
    uiBtn(c, () => {
      const list = netPerms[listKey] || (netPerms[listKey] = []);
      const at = list.indexOf(e.i);
      if (at >= 0) list.splice(at, 1); else list.push(e.i);
      commit();
    });
    grid.appendChild(c);
  });
  p.appendChild(grid);
}

// commit to hosting (idempotent) — used the first time the host acts
function becomeHost(){
  if (netRole === "host") return;
  netRole = "host"; myPlayerId = 0; myColor = PLAYER_COLORS[0];
  netRoster.set(0, { name:myName, color:myColor });
  updateMpButton();
}

document.getElementById("mpOpenBtn").addEventListener("click", e => { e.stopPropagation(); uiClick(); openMpMenu(true); });
mpBtn.addEventListener("click", () => { uiClick(); openMpMenu(false); });

// When the tab or iframe is closed, explicitly tell all connected peers we're leaving
// so they don't have to wait for the WebRTC connection to time out.
window.addEventListener("pagehide", () => {
  if (netRole === "host") {
    for (const pe of hostPeers) {
      try { if (pe.ch && pe.ch.readyState === "open") pe.ch.send(JSON.stringify({ t:"hostLeaving" })); } catch(e){}
    }
  } else if (netRole === "client") {
    try { if (clientCh && clientCh.readyState === "open") clientCh.send(JSON.stringify({ t:"leaving" })); } catch(e){}
  }
});
