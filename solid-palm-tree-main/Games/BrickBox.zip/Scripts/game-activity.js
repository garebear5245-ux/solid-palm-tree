// Reports player activity from inside a game frame up to the launcher.
//
// The launcher watches for AFK to save Supabase usage. When the site is
// opened over file:// (or the game is otherwise a different origin), the
// parent page CANNOT read events inside this iframe — every file:// frame
// is a unique security origin. postMessage still crosses that boundary,
// so each game ships this tiny reporter: on any real input it pings the
// parent, which resets the AFK timer. No-op when not embedded.
(function () {
    if (window.parent === window) return; // not in a frame — nothing to report

    var last = 0;
    function post(msg) {
        var now = Date.now();
        if (now - last < 1000) return; // throttle to at most once/second
        last = now;
        try { window.parent.postMessage(msg, '*'); } catch (e) {}
    }

    // Deliberate input — always counts as activity.
    function ping() { post({ __xboxActivity: true }); }

    // Mouse moves carry their position instead of counting on their own.
    // The launcher decides whether the pointer travelled far enough to be
    // real movement; if we pinged here, a single pixel of jitter inside a
    // game would keep the player "present" forever and AFK would never fire.
    function pingMove(e) { post({ __xboxActivity: true, move: true, x: e.clientX, y: e.clientY }); }

    ['keydown', 'keypress', 'mousedown', 'pointerdown', 'touchstart', 'wheel']
        .forEach(function (ev) {
            window.addEventListener(ev, ping, { passive: true, capture: true });
        });
    window.addEventListener('mousemove', pingMove, { passive: true, capture: true });
})();
