"use strict";
/* audio.js — sound helpers, footsteps, thuds, and global volume mixing. */
const S = "Assets/Sounds/";

// Global mixer — Settings drives these 0..1 sliders. Every sound is tagged with a
// category so the sliders (master + sfx/music/ui/explosions) scale it live.
const AUDIO = { master:1, sfx:1, music:1, ui:1, explosions:1 };
// map a category name -> effective 0..1 gain
function catGain(cat){ return AUDIO.master * (AUDIO[cat] != null ? AUDIO[cat] : 1); }

function loopAudio(src){ const a = new Audio(src); a.loop = true; a.volume = 0; a.preload = "auto"; a._tv = 0; a._cat = "sfx"; return a; }
// vol = base 0..1, cat = mixer bucket ("sfx"|"music"|"ui"|"explosions")
function oneShot(src, vol=0.85, cat="sfx"){
  try { const a = new Audio(src); a._base = vol; a._cat = cat; a.volume = Math.max(0, Math.min(1, vol * catGain(cat))); a.play().catch(()=>{}); } catch(e){}
}
const SND = { gravLoop: loopAudio(S+"Tools/GravityRay/hold_loop.ogg") };

// UI feedback sounds
function uiClick(){ oneShot(S+"UI/Click.ogg", 0.6, "ui"); }
function uiClose(){ oneShot(S+"UI/Close.ogg", 0.6, "ui"); }
let lastHoverSnd = 0;
function uiHover(){
  const t = performance.now();
  if (t - lastHoverSnd < 250) return;              // 0.25s cooldown so sweeping doesn't spam
  lastHoverSnd = t;
  oneShot(S+"UI/Hover.ogg", 0.4, "ui");
}

// Half-Life-style footsteps: a random clip per footfall from a per-surface pool
function makePool(paths){ return paths.map(p => { const a = new Audio(p); a.preload = "auto"; return a; }); }
const footPool = {
  concrete: makePool([1,2,3,4].map(i => S+"Footsteps/Concrete/concrete"+i+".ogg")),
  wood:     makePool([1,2,3,4].map(i => S+"Footsteps/Wood/wood"+i+".ogg")),
};
const thudSnd = {
  concrete: new Audio(S+"Footsteps/Thud/ConcreteThud.ogg"),
  wood:     new Audio(S+"Footsteps/Thud/WoodThud.ogg"),
};
function playThud(mat, impact){
  const a = thudSnd[mat] || thudSnd.concrete;
  const base = Math.max(0.4, Math.min(1, 0.4 + (impact-FALL_MIN)*0.04));
  try { a.currentTime = 0; a.volume = base * catGain("sfx"); a.play().catch(()=>{}); } catch(e){}
}
let lastFoot = -1;
function playFootstep(mat){
  const pool = footPool[mat] || footPool.concrete;
  let i = Math.floor(Math.random()*pool.length);
  if (pool.length > 1 && i === lastFoot) i = (i+1) % pool.length;   // avoid repeating the same clip
  lastFoot = i;
  const a = pool[i];
  try { a.currentTime = 0; a.volume = 0.7 * catGain("sfx"); a.play().catch(()=>{}); } catch(e){}
}
function setLoop(a, on, vol=0.6){ a._tv = on ? vol : 0; if (on && a.paused) a.play().catch(()=>{}); }
function fadeAudio(a, dt){
  const g = catGain(a._cat || "sfx");
  a.volume += (a._tv * g - a.volume) * Math.min(1, dt*9);   // smooth fade → smooth stop
  if (a._tv <= 0.001 && a.volume < 0.02 && !a.paused) a.pause();
}
// re-apply the mixer to any long-lived <audio> (radios) after a slider changes
function refreshRadioVolumes(){
  const g = catGain("music");
  for (const p of (typeof props !== "undefined" ? props : [])) if (p._radioAudio) p._radioAudio.volume = 0.6 * g;
  if (typeof clientProps !== "undefined") for (const cp of clientProps.values()) if (cp._radioAudio) cp._radioAudio.volume = 0.6 * g;
}
