"use strict";
/* physics.js — cannon.js world, floor and perimeter walls. */
const world = new CANNON.World();
world.gravity.set(0, -20, 0);
world.broadphase = new CANNON.NaiveBroadphase();
world.solver.iterations = 12;
world.allowSleep = true;

const groundMatC = new CANNON.Material("ground");
const propMat = new CANNON.Material("prop");
world.addContactMaterial(new CANNON.ContactMaterial(groundMatC, propMat, { friction:0.4, restitution:0.25 }));
world.addContactMaterial(new CANNON.ContactMaterial(propMat, propMat, { friction:0.35, restitution:0.2 }));

const FLOOR = 90;
const floorBody = new CANNON.Body({ mass:0, material:groundMatC });
floorBody.collisionFilterGroup = 1; floorBody.collisionFilterMask = -1;   // collide with every group (incl. welded assemblies)
floorBody.addShape(new CANNON.Plane());
floorBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1,0,0), -Math.PI/2);
world.addBody(floorBody);

const tileTex = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const x = c.getContext("2d");
  x.fillStyle = "#6f7a86"; x.fillRect(0,0,128,128);
  x.strokeStyle = "#5a636e"; x.lineWidth = 6; x.strokeRect(0,0,128,128);
  const tex = new T.CanvasTexture(c); tex.wrapS = tex.wrapT = T.RepeatWrapping;
  tex.repeat.set(FLOOR/4, FLOOR/4); return tex;
})();
const floorMesh = new T.Mesh(new T.PlaneGeometry(FLOOR*2, FLOOR*2),
  new T.MeshStandardMaterial({ map:tileTex, roughness:0.95 }));
floorMesh.rotation.x = -Math.PI/2; floorMesh.receiveShadow = true;
scene.add(floorMesh);

const wallMeshes = [];
function wall(x,z,w,d){
  const b = new CANNON.Body({ mass:0, material:groundMatC });
  b.collisionFilterGroup = 1; b.collisionFilterMask = -1;
  b.addShape(new CANNON.Box(new CANNON.Vec3(w/2, 6, d/2)));
  b.position.set(x, 6, z); world.addBody(b);
  const m = new T.Mesh(new T.BoxGeometry(w,12,d),
    new T.MeshStandardMaterial({ color:0x556, roughness:0.9, transparent:true, opacity:0.25 }));
  m.position.set(x,6,z); m.receiveShadow = true; scene.add(m); wallMeshes.push(m);
}
wall(0, -FLOOR, FLOOR*2, 2); wall(0, FLOOR, FLOOR*2, 2);
wall(-FLOOR, 0, 2, FLOOR*2); wall(FLOOR, 0, 2, FLOOR*2);
