"use strict";
/* player.js — first-person walk/fly movement, ground detection, footsteps, head bob. */
const EYE = 3.2, GRAV = 24, JUMP = 10.5;
const STEP_H = 2.1, PLAYER_R = 0.6;   // max ledge you walk straight up (≈ one crate); body half-width
const FALL_MIN = 8;   // must fall at least ~4 crates (2 units each) to make a landing thud
const FALL_SAFE = 12; // falls shorter than this never hurt; beyond it, damage ramps up
const FALL_DMG_PER_UNIT = 4;   // HP lost per unit fallen past FALL_SAFE (~37-unit fall is lethal)
let flyMode = false, velY = 0, grounded = false, wasGrounded = true, groundMat = "concrete";
let bobPhase = 0, bobAmp = 0, stepTimer = 0.5, apexY = EYE;
const bobOffset = new T.Vector3();
camera.position.set(0, EYE, 18);

// props whose collision was turned off (wrench) are pass-through for the player too,
// so they're excluded from the ground/wall raycasts that block and stand on you
function collidableProps(){
  let any = false;
  for (const m of propMeshes) if (m.userData && m.userData.noCollide){ any = true; break; }
  if (!any) return propMeshes;                       // fast path: nothing disabled
  return propMeshes.filter(m => !(m.userData && m.userData.noCollide));
}
function groundTargets(){ return [floorMesh, ...wallMeshes, ...collidableProps()]; }
function solidTargets(){ return [...wallMeshes, ...collidableProps()]; }
function matOf(obj){
  if (obj && obj.userData && obj.userData.prop) return obj.userData.prop.footMat;
  return "concrete";
}
// per-axis horizontal collision: stop movement into props/walls (sliding along them).
// rays are cast only ABOVE the step height, so low ledges are still climbed via the
// ground snap while taller stacks block you instead of launching you onto their top.
function clampMove(axis, delta){
  if (!delta) return delta;
  const feet = camera.position.y - EYE;
  const dir = new T.Vector3(); dir[axis] = Math.sign(delta);
  const targets = solidTargets();
  let limit = Math.abs(delta);
  const head = camera.position.y - 0.1;
  for (let hy = feet + STEP_H + 0.05; hy <= head; hy += 0.6){
    raycaster.set(new T.Vector3(camera.position.x, hy, camera.position.z), dir);
    raycaster.far = PLAYER_R + Math.abs(delta);
    const hit = raycaster.intersectObjects(targets, false)[0];
    if (hit){ const room = Math.max(0, hit.distance - PLAYER_R); if (room < limit) limit = room; }
  }
  raycaster.far = Infinity;             // restore for the shared aim/ground raycaster
  return Math.sign(delta) * limit;
}
function move(dt){
  const yawE = new T.Euler(0, camera.rotation.y, 0, "YXZ");
  const fwd   = new T.Vector3(0,0,-1).applyEuler(flyMode ? camera.rotation : yawE);
  const right = new T.Vector3(1,0,0).applyEuler(flyMode ? camera.rotation : yawE);
  const key = k => (!chatOpen && keys[k]);   // freeze movement input while typing, but keep simulating
  const wish = new T.Vector3();
  if (key("w")) wish.add(fwd);
  if (key("s")) wish.sub(fwd);
  if (key("d")) wish.add(right);
  if (key("a")) wish.sub(right);
  const horiz = wish.lengthSq() > 0;

  if (flyMode){
    const speed = 16 * (key("shift") ? 2.4 : 1);
    if (horiz) wish.normalize().multiplyScalar(speed*dt);
    if (key(" ")) wish.y += speed*dt;
    if (key("control")) wish.y -= speed*dt;
    camera.position.add(wish);
    // (no y floor-clamp here anymore — flying down past the map lets the void mechanic work)
    bobAmp += (0 - bobAmp) * Math.min(1, dt*7);
    wasGrounded = false;                 // so returning to walk mid-air thuds on landing
    apexY = camera.position.y;           // fall is measured from where you leave flight
  } else {
    const running = !!key("shift");
    const speed = 8 * (running ? 1.7 : 1);
    if (horiz){ wish.y = 0; wish.normalize().multiplyScalar(speed*dt); }
    camera.position.x += clampMove("x", wish.x);       // block into walls/stacks, slide along them
    camera.position.z += clampMove("z", wish.z);

    velY -= GRAV*dt; camera.position.y += velY*dt;
    raycaster.set(new T.Vector3(camera.position.x, camera.position.y+0.1, camera.position.z), DOWN);
    const hits = raycaster.intersectObjects(groundTargets(), false);
    grounded = false;
    if (hits.length){
      const gy = hits[0].point.y;
      // stand on ground you've reached, but only step UP within STEP_H — never teleport onto a tall stack
      if (camera.position.y - EYE <= gy && gy - (camera.position.y - EYE) <= STEP_H){
        camera.position.y = gy + EYE; velY = 0; grounded = true; groundMat = matOf(hits[0].object);
      }
    }
    if (grounded){
      if (!wasGrounded){
        const drop = apexY - camera.position.y;             // total height fallen
        if (drop >= FALL_MIN) playThud(groundMat, drop);    // only a real fall thuds
        // fall damage: anything past a safe height hurts, scaled by how far you fell
        if (drop > FALL_SAFE && typeof damageEnabled === "function" && damageEnabled("Fall")
            && typeof applyDamage === "function"){
          applyDamage((drop - FALL_SAFE) * FALL_DMG_PER_UNIT, "fall");
        }
      }
      if (key(" ")){ velY = JUMP; grounded = false; }       // jump keeps us airborne
      else apexY = camera.position.y;                        // standing: reset the baseline
    } else {
      apexY = Math.max(apexY, camera.position.y);            // track the highest point in the air
    }
    wasGrounded = grounded;

    // footfall cadence + smooth head shake, scaled by walk vs run
    const moving = horiz && grounded;
    const targetAmp = moving ? (running ? 0.12 : 0.055) : 0;
    bobAmp += (targetAmp - bobAmp) * Math.min(1, dt*7);
    if (moving){
      bobPhase += dt * (running ? 13 : 8.5);
      stepTimer += dt;
      const iv = running ? 0.33 : 0.5;
      if (stepTimer >= iv){ stepTimer = 0; playFootstep(groundMat); }
    } else {
      stepTimer = 0.5;   // primed so a step fires the instant you start moving
    }
  }
  const b = FLOOR - 2;
  camera.position.x = Math.max(-b, Math.min(b, camera.position.x));
  camera.position.z = Math.max(-b, Math.min(b, camera.position.z));
}
