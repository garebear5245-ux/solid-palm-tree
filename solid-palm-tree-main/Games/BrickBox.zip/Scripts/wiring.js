"use strict";
/* wiring.js — redstone-style node & wire tool, plus tool granting.

   Build a network of nodes joined by wires (LMB), drop a button node (RMB),
   then press the button (RMB on it) to power the whole connected network. Any
   node bound to a "functional" prop — currently the Cannonball — fires that
   prop, so the cannonball detonates. Host-only for now (like welding), because
   only the host runs the physics that actually makes the blast.

   Also owns tool GRANTING: the Wiring tool starts locked and must be granted
   from the ToolRay menu. In multiplayer the host gates that with the
   "grant" permission ("Allow players to grant themselves tools…"). */

// register the new tool in the hotbar
TOOLS.push({ name:"Wiring", desc:"nodes & wires" });
const WIRING_TOOL = TOOLS.length - 1;

/* ---- wiring quick-selection (ToolRay-style palette on the right) ------ */
// what a left-click places; cycle with Q, just like the ToolRay props palette
const WIRE_ITEMS = [
  { name:"Wire Node", desc:"chain & bind" },
  { name:"Button",    desc:"pulse power" },
  { name:"Switch",    desc:"hold power" },
  { name:"Repeater",  desc:"extend + delay" },
];
let selectedWireItem = 0;
function setWireItem(i){
  selectedWireItem = (i + WIRE_ITEMS.length) % WIRE_ITEMS.length;
  if (typeof drawPalette === "function") drawPalette();
}
function wireItemCycle(){ setWireItem(selectedWireItem + 1); }

/* ---- tool granting ---------------------------------------------------- */
// ToolRay + GravityRay are granted by default; Wiring must be granted.
const toolGranted = [true, true, false];
function canGrantTools(){ return !netIsClient() || netPerms.anything || netPerms.grant; }
function canUseWiring(){ return !netIsClient() || netPerms.anything || netPerms.wiring; }

/* ---- client-side ghost wire visuals (received from host via wireState) -- */
const clientWireNodes    = [];   // { mesh, kind, pos, idx, on }
const clientWireLines    = [];   // { line }
const clientWireNodeMeshes = []; // raycast targets for client
let clientWireChain = null;      // index into clientWireNodes for the client's current chain

function applyWireState(data){
  clearClientWiring();
  if (!data || !Array.isArray(data.nodes)) return;
  for (let idx = 0; idx < data.nodes.length; idx++){
    const nd = data.nodes[idx];
    const pos = new T.Vector3(nd.x, nd.y, nd.z);
    const kind = nd.kind, on = !!nd.on;
    const bound = kind === "n" && nd.propNetId != null;   // node on a functional prop → ray
    let col, geo;
    if (kind === "b")      { col = BUTTON_COLOR;    geo = new T.CylinderGeometry(0.34,0.34,0.34,12); }
    else if (kind === "s") { col = on ? SWITCH_ON : SWITCH_OFF; geo = new T.BoxGeometry(0.5,0.5,0.5); }
    else if (kind === "r") { col = REPEATER_COLOR;  geo = new T.SphereGeometry(0.32,14,10); }
    else if (bound)        { col = WIRE_COLOR;      geo = new T.CylinderGeometry(0.04,0.04,1.2,6); }
    else                   { col = WIRE_COLOR;      geo = new T.SphereGeometry(0.3,14,10); }
    const mesh = new T.Mesh(geo, new T.MeshStandardMaterial({
      color:col, emissive:new T.Color(col), emissiveIntensity:0.6, roughness:0.4 }));
    mesh.position.copy(pos); if (bound) mesh.position.y += 0.6; mesh.castShadow = true; scene.add(mesh);
    const node = { mesh, kind, pos, idx, on };
    mesh.userData.wireNode = node;
    clientWireNodes.push(node);
    clientWireNodeMeshes.push(mesh);
  }
  for (const [i, j] of (data.links || [])){
    const a = clientWireNodes[i], b = clientWireNodes[j];
    if (!a || !b) continue;
    const tooLong = a.pos.distanceTo(b.pos) > SEGMENT_MAX;   // out-of-range segment → red
    const line = new T.Line(
      new T.BufferGeometry().setFromPoints([a.pos.clone(), b.pos.clone()]),
      new T.LineBasicMaterial({ color:tooLong ? DEAD_COLOR : WIRE_COLOR, transparent:true, opacity:tooLong ? 0.95 : 0.9 }));
    line.frustumCulled = false; scene.add(line);
    clientWireLines.push({ line });
  }
  if (clientWireChain != null && clientWireChain >= clientWireNodes.length) clientWireChain = null;
}
function clearClientWiring(){
  for (const n of clientWireNodes) scene.remove(n.mesh);
  for (const w of clientWireLines) scene.remove(w.line);
  clientWireNodes.length = 0; clientWireLines.length = 0; clientWireNodeMeshes.length = 0;
  clientWireChain = null;
}

/* ---- wire-state serializer (called by hostBroadcastWireState in net.js) - */
function serializeWireStateForNet(){
  const nodeIdx = new Map();
  wireNodes.forEach((n, i) => nodeIdx.set(n, i));
  const nodes = wireNodes.map(n => ({
    kind: n.button ? "b" : n.sw ? "s" : n.rep ? "r" : "n",
    x: n.pos.x, y: n.pos.y, z: n.pos.z,
    on: n.on,
    propNetId: (n.prop && n.prop.netId != null) ? n.prop.netId : null
  }));
  const links = [];
  for (const w of wireLines){
    const i = nodeIdx.get(w.a), j = nodeIdx.get(w.b);
    if (i != null && j != null && i < j) links.push([i, j]);
  }
  return { nodes, links };
}
function toolIsGranted(i){ return i < 0 || !!toolGranted[i]; }
function grantTool(i){
  if (toolGranted[i]) return true;
  if (!canGrantTools()){ toast("The host hasn't allowed granting tools"); return false; }
  toolGranted[i] = true; toast("Granted: " + TOOLS[i].name);
  if (typeof drawTools === "function") drawTools();
  return true;
}

/* ---- node / wire graph ------------------------------------------------ */
const wireNodes = [];        // { mesh, pos, prop, button, links:Set, _flash }
const wireLines = [];        // { line, a, b, _flash }
const wireNodeMeshes = [];   // raycast targets for aiming at nodes
let wireChain = null;        // last placed/picked node — the next node auto-wires to it

// the continuous powered-node set is expensive to recompute (a BFS over the whole
// graph), so cache it and only recompute when the graph actually changes — topology,
// switch state, or a bound prop moving. markWiringDirty() flags a recompute.
let _wiringDirty = true, _poweredCache = new Set();
function markWiringDirty(){ _wiringDirty = true; }

const WIRE_COLOR = 0x38e0ff, BUTTON_COLOR = 0xff5b5b, POWER_COLOR = 0xffee66;
const SWITCH_OFF = 0x8a5a2a, SWITCH_ON = 0x51e07a;
const REPEATER_COLOR = 0x800000;               // maroon
const DEAD_COLOR = 0xff2a2a;                    // red: out-of-range wire that can't conduct

// power range, Minecraft-redstone style. A single wire segment longer than
// SEGMENT_MAX can never conduct (renders red the moment you place it too far).
// Power also has a cumulative budget CUMULATIVE_MAX that only a Repeater resets —
// and a Repeater re-emits power after a short delay, just like a redstone repeater.
const SEGMENT_MAX = 26, CUMULATIVE_MAX = 60, REPEATER_DELAY = 0.15;
// how close you must be to press a button / flip a switch (units)
const WIRE_INTERACT_RANGE = 9;
const _wireInteractRangeSq = WIRE_INTERACT_RANGE * WIRE_INTERACT_RANGE;
function wireLen(a, b){ return a.pos.distanceTo(b.pos); }

// props that "have functionality similar to the cannon" — return a label, else null
function triggerName(p){
  if (!p) return null;
  if (p.type === CANNONBALL) return "explode";
  if (p.type === LIGHT) return "light";
  if (p.type === RADIO) return "radio";
  return null;
}
function triggerProp(p){
  if (p.type === CANNONBALL){ if (!p._dead){ p._dead = true; queueExplosion(p); } return true; }
  if (p.type === LIGHT){ p.lightOn = !p.lightOn; return true; }   // button press toggles a light's manual state
  if (p.type === RADIO){ if (typeof setRadioOn === "function") setRadioOn(p, !p.radioOn, true); return true; }
  return false;
}

// kind: "button" | "switch" | "repeater" | null (plain node).
// bound = node is attached to a functional prop: render a thin "ray" antenna
// instead of a sphere sitting on the object.
function makeNodeMesh(pos, kind, bound){
  let geo, col;
  if (kind === "button")        { geo = new T.CylinderGeometry(0.34,0.34,0.34,12); col = BUTTON_COLOR; }
  else if (kind === "switch")   { geo = new T.BoxGeometry(0.5,0.5,0.5);            col = SWITCH_OFF; }
  else if (kind === "repeater") { geo = new T.SphereGeometry(0.32,14,10);          col = REPEATER_COLOR; }
  else if (bound)               { geo = new T.CylinderGeometry(0.04,0.04,1.2,6);   col = WIRE_COLOR; }  // upright ray
  else                          { geo = new T.SphereGeometry(0.3,14,10);           col = WIRE_COLOR; }
  const mesh = new T.Mesh(geo, new T.MeshStandardMaterial({ color:col, emissive:new T.Color(col), emissiveIntensity:0.6, roughness:0.4 }));
  mesh.position.copy(pos);
  if (bound && !kind) mesh.position.y += 0.6;   // stand the ray up out of the prop
  mesh.castShadow = true; scene.add(mesh); wireNodeMeshes.push(mesh);
  return mesh;
}
function addNode(pos, opts){
  opts = opts || {};
  const kind = opts.button ? "button" : opts.sw ? "switch" : opts.rep ? "repeater" : null;
  const bound = !!opts.prop && !kind;
  const node = { mesh:makeNodeMesh(pos, kind, bound), pos:pos.clone(), prop:opts.prop||null,
                 button:!!opts.button, sw:!!opts.sw, rep:!!opts.rep, bound, on:false, links:new Set(), _flash:0 };
  node.mesh.userData.wireNode = node;
  wireNodes.push(node);
  if (wireChain) linkNodes(wireChain, node);
  wireChain = node;
  markWiringDirty();
  return node;
}
// tear a node out of the graph: drop its wires, mesh, and any chain reference
function deleteNode(node){
  for (const w of [...wireLines]){
    if (w.a !== node && w.b !== node) continue;
    scene.remove(w.line);
    const i = wireLines.indexOf(w); if (i >= 0) wireLines.splice(i, 1);
  }
  for (const m of node.links) m.links.delete(node);
  node.links.clear();
  scene.remove(node.mesh);
  let i = wireNodeMeshes.indexOf(node.mesh); if (i >= 0) wireNodeMeshes.splice(i, 1);
  i = wireNodes.indexOf(node); if (i >= 0) wireNodes.splice(i, 1);
  if (wireChain === node) wireChain = null;
  markWiringDirty();
}
// remove every node bound to a given prop (called when the prop is deleted/explodes)
function removeNodesForProp(p){
  for (const n of [...wireNodes]) if (n.prop === p) deleteNode(n);
}
function toggleSwitch(n){
  n.on = !n.on;
  n.mesh.material.color.setHex(n.on ? SWITCH_ON : SWITCH_OFF);
  n.mesh.material.emissive.setHex(n.on ? SWITCH_ON : SWITCH_OFF);
  n.mesh.material.emissiveIntensity = n.on ? 1.1 : 0.6;
  buttonClickSound();                                // same click as the button
  markWiringDirty();                                 // switch state feeds the powered set
  toast("Switch " + (n.on ? "on" : "off"));
}
function linkNodes(a, b){
  if (a === b || a.links.has(b)) return;
  a.links.add(b); b.links.add(a);
  const line = new T.Line(new T.BufferGeometry().setFromPoints([a.pos.clone(), b.pos.clone()]),
    new T.LineBasicMaterial({ color:WIRE_COLOR, transparent:true, opacity:0.9 }));
  line.frustumCulled = false; scene.add(line);
  wireLines.push({ line, a, b, _flash:0 });
  markWiringDirty();
}

// where the crosshair meets the world (and the prop there, if any)
function wireAimPoint(){
  raycaster.setFromCamera(CENTER, camera);
  const hits = raycaster.intersectObjects([floorMesh, ...wallMeshes, ...propMeshes], false);
  if (!hits.length) return null;
  const h = hits[0];
  return { point:h.point.clone(), prop:(h.object.userData && h.object.userData.prop) || null };
}
function aimedWireNode(){
  raycaster.setFromCamera(CENTER, camera);
  const meshes = netIsClient() ? clientWireNodeMeshes : wireNodeMeshes;
  const hits = raycaster.intersectObjects(meshes, false);
  return hits.length ? hits[0].object.userData.wireNode : null;
}

/* ---- tool actions ----------------------------------------------------- */
function wiringPrimary(){         // LMB: place whatever's selected in the quick-selection palette
  if (!canUseWiring()){ toast("Wiring is disabled by the host"); return; }
  const item = WIRE_ITEMS[selectedWireItem].name;

  if (netIsClient()){
    if (item === "Button"){
      const a = wireAimPoint(); if (!a) return;
      netClientCmd({ t:"wire", action:"placeButton", x:a.point.x, y:a.point.y, z:a.point.z });
      toast("Button placed — right-click it to power the wires");
    } else if (item === "Switch"){
      const a = wireAimPoint(); if (!a) return;
      netClientCmd({ t:"wire", action:"placeSwitch", x:a.point.x, y:a.point.y, z:a.point.z });
      toast("Switch placed — right-click it to hold power on");
    } else if (item === "Repeater"){
      const a = wireAimPoint(); if (!a) return;
      netClientCmd({ t:"wire", action:"placeRepeater", x:a.point.x, y:a.point.y, z:a.point.z, chainFrom:clientWireChain });
      clientWireChain = null;
      toast("Repeater placed — extends power range");
    } else {
      const hit = aimedWireNode();
      if (hit){
        clientWireChain = hit.idx;
        netClientCmd({ t:"wire", action:"chain", nodeIdx:hit.idx });
        toast(hit.kind === "b" ? "Chaining from button" : "Chaining from node");
        return;
      }
      const a = wireAimPoint(); if (!a) return;
      const propNetId = (a.prop && a.prop.netId != null) ? a.prop.netId : null;
      netClientCmd({ t:"wire", action:"placeNode",
        x:a.point.x, y:a.point.y, z:a.point.z,
        propNetId, chainFrom:clientWireChain });
      clientWireChain = null;
      if (a.prop) toast("Wired to prop");
    }
    oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.5);
    return;
  }

  if (item === "Button"){
    const a = wireAimPoint(); if (!a) return;
    addNode(a.point, { button:true });
    toast("Button placed — right-click it to power the wires");
    if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
    return;
  }
  if (item === "Switch"){
    const a = wireAimPoint(); if (!a) return;
    addNode(a.point, { sw:true });
    toast("Switch placed — right-click it to hold power on");
    if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
    return;
  }
  if (item === "Repeater"){
    const a = wireAimPoint(); if (!a) return;
    addNode(a.point, { rep:true });
    oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.5);
    toast("Repeater placed — extends power range");
    if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
    return;
  }
  // Wire Node: chain onto an existing node, else place a node (binding it to a prop if aimed at one)
  const hit = aimedWireNode();
  if (hit){ wireChain = hit; toast(hit.button ? "Chaining from button" : "Chaining from node"); return; }
  const a = wireAimPoint(); if (!a) return;
  const pos = a.prop ? new T.Vector3(a.prop.body.position.x, a.prop.body.position.y, a.prop.body.position.z) : a.point;
  addNode(pos, { prop:a.prop });
  oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.5);
  if (a.prop) toast(triggerName(a.prop)
    ? ("Wired to " + TYPES[a.prop.type].name + " — functional!")
    : ("Wired to " + TYPES[a.prop.type].name));
  if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
}
function wiringSecondary(){       // RMB: press a button / flip a switch you're aiming at
  pressAimedButton();
}

// only buttons/switches within reach may be actuated
function nodeInReach(node){
  if (!node) return false;
  const p = node.mesh.position;
  const dx = p.x - camera.position.x, dy = p.y - camera.position.y, dz = p.z - camera.position.z;
  return dx*dx + dy*dy + dz*dz <= _wireInteractRangeSq;
}
// right-click a button (pulse) or a switch (toggle) — works no matter which tool is equipped
function pressAimedButton(){
  if (netIsClient()){
    const hit = aimedWireNode();
    if (!hit) return false;
    if (!hit.button && !hit.sw) return false;           // only buttons/switches are pressable
    if (!nodeInReach(hit)){ toast("Too far to reach"); return true; }
    const pos = hit.mesh.position;
    netClientCmd({ t:"wire", action:"press", x:pos.x, y:pos.y, z:pos.z });
    oneShot(S+"Props/Button/Click.ogg", 0.85);   // local audio feedback
    return true;
  }
  const hit = aimedWireNode();
  if (!hit) return false;
  if (!hit.button && !hit.sw) return false;
  if (!nodeInReach(hit)){ toast("Too far to reach"); return true; }
  if (hit.button){ pressButton(hit); if (typeof hostBroadcastWireState === "function") hostBroadcastWireState(); return true; }
  if (hit.sw){ toggleSwitch(hit); if (typeof hostBroadcastWireState === "function") hostBroadcastWireState(); return true; }
  return false;
}
function wiringNewWire(){ wireChain = null; toast("New wire started"); }

// throttled button click — Assets/Sounds/Props/Button/Click.ogg, .35s cooldown
let lastButtonSnd = 0;
function buttonClickSound(){
  const t = performance.now();
  if (t - lastButtonSnd < 350) return;
  lastButtonSnd = t;
  oneShot(S+"Props/Button/Click.ogg", 0.85);
}

// is this single wire segment short enough to ever conduct?
function segmentConducts(a, b){ return wireLen(a, b) <= SEGMENT_MAX; }

// power a pulse outward from a source node, respecting the range budget. Power dies
// when a segment is too long OR the cumulative budget runs out. Repeaters reset the
// budget and re-emit after REPEATER_DELAY, so long runs work with repeaters in between.
// fire a functional prop bound to this node — at most once per whole pulse
function pulseFire(node, ctx){
  const p = node.prop;
  if (!p || props.indexOf(p) < 0 || !triggerName(p)) return;
  if (ctx.firedProps.has(p)) return;                 // already fired this pulse — don't re-toggle
  ctx.firedProps.add(p);
  if (triggerProp(p)) ctx.count++;
}
// One pulse emission from `source`. `ctx` is SHARED across the whole pulse, including
// the delayed re-emissions repeaters schedule, so each repeater re-fires at most once
// (ctx.firedReps) and each functional prop triggers at most once (ctx.firedProps).
// Without these guards, two repeaters wired together ping-pong setTimeouts forever —
// that was the runaway lag + endless radio-toggle clicking.
function propagatePulse(source, budget, ctx){
  const seen = new Set();                             // reachability for THIS emission only
  const stack = [{ n:source, b:budget }];
  seen.add(source); ctx.allSeen.add(source);
  flashNode(source);
  pulseFire(source, ctx);
  while (stack.length){
    const { n, b } = stack.pop();
    for (const m of n.links){
      if (seen.has(m)) continue;
      if (!segmentConducts(n, m)) continue;            // segment too long → power can't cross
      const remaining = b - wireLen(n, m);
      if (remaining < 0) continue;                      // ran out of budget before reaching m
      seen.add(m); ctx.allSeen.add(m);
      flashNode(m);
      pulseFire(m, ctx);
      if (m.rep){
        if (ctx.firedReps.has(m)) continue;            // this repeater already re-emitted this pulse
        ctx.firedReps.add(m);
        const rep = m;
        // repeater: re-emit a full-budget pulse after a short delay, same pulse ctx
        setTimeout(() => {
          propagatePulse(rep, CUMULATIVE_MAX, ctx);
          if (typeof hostBroadcastWireState === "function") hostBroadcastWireState();
        }, REPEATER_DELAY * 1000);
      } else {
        stack.push({ n:m, b:remaining });
      }
    }
  }
}
// power everything connected to this button; fire any functional props on the way
function pressButton(btn){
  buttonClickSound();
  const ctx = { firedReps:new Set(), firedProps:new Set(), allSeen:new Set(), count:0 };
  propagatePulse(btn, CUMULATIVE_MAX, ctx);
  for (const w of wireLines) if (ctx.allSeen.has(w.a) && ctx.allSeen.has(w.b) && segmentConducts(w.a, w.b)) flashLine(w);
  toast(ctx.count ? ("Powered! " + ctx.count + (ctx.count>1?" props triggered":" prop triggered")) : "Powered — nothing functional connected");
}
function flashNode(n){ n._flash = 0.5; n.mesh.material.emissive.setHex(POWER_COLOR); n.mesh.material.emissiveIntensity = 1.5; }
function flashLine(w){ w._flash = 0.5; w.line.material.color.setHex(POWER_COLOR); }

// which nodes are continuously powered by an ON switch, within the range budget.
// Repeaters reset the budget so a chain of them carries power arbitrarily far.
// Also records which segments actually conduct (for red/blue wire colouring).
const _conducting = new Set();      // wireLine objects that carry power this frame
function poweredNodes(){
  const powered = new Set();
  const best = new Map();           // node -> best remaining budget seen so far
  // sources: every ON switch (and repeaters get seeded when power reaches them)
  const queue = [];
  for (const n of wireNodes) if (n.sw && n.on){ best.set(n, CUMULATIVE_MAX); queue.push(n); powered.add(n); }
  while (queue.length){
    const n = queue.shift();
    const b = best.get(n);
    for (const m of n.links){
      if (!segmentConducts(n, m)) continue;
      const rem = (m.rep ? CUMULATIVE_MAX : b - wireLen(n, m));   // repeaters refill the budget
      if (m.rep){
        // reaching a repeater powers it and re-sources at full budget
        if (rem > (best.get(m) || -1)){ best.set(m, rem); powered.add(m); queue.push(m); }
      } else {
        const cross = b - wireLen(n, m);
        if (cross < 0) continue;
        if (cross > (best.get(m) || -1)){ best.set(m, cross); powered.add(m); queue.push(m); }
      }
    }
  }
  return powered;
}
// mark which visible wire segments should look powered vs dead-red, given powered nodes
function recolorWires(powered){
  for (const w of wireLines){
    if (w._flash > 0) continue;                       // a pulse flash owns the colour briefly
    const tooLong = !segmentConducts(w.a, w.b);
    const live = !tooLong && powered.has(w.a) && powered.has(w.b);
    const col = tooLong ? DEAD_COLOR : WIRE_COLOR;
    if (w.line.material.color.getHex() !== col) w.line.material.color.setHex(col);
    w.line.material.opacity = live ? 1.0 : (tooLong ? 0.95 : 0.7);
  }
}
// drive every Light: lit if its own on/off is set, or a switch is holding its wires powered
function updateLights(powered){
  powered = powered || poweredNodes();
  const want = new Map();
  for (const p of props) if (p.type === LIGHT) want.set(p, !!p.lightOn);
  for (const n of wireNodes){
    if (n.prop && n.prop.type === LIGHT && powered.has(n)) want.set(n.prop, true);
  }
  // lit state itself streams to clients via the snapshot flags byte — no broadcast here
  for (const [p, on] of want){ if (p.lit !== on){ p.lit = on; applyLightState(p); } }
}

// drive every Radio: on if manually on OR if a powered switch's wire reaches it
function updateRadios(powered){
  powered = powered || poweredNodes();
  for (const n of wireNodes){
    if (n.prop && n.prop.type === RADIO && powered.has(n) && !n.prop.radioOn){
      if (typeof setRadioOn === "function") setRadioOn(n.prop, true, true);
    }
  }
}

/* ---- per-frame upkeep (called from the main loop) --------------------- */
function baseNodeColor(n){
  return n.button ? BUTTON_COLOR : n.rep ? REPEATER_COLOR
       : n.sw ? (n.on ? SWITCH_ON : SWITCH_OFF) : WIRE_COLOR;
}
function updateWiring(dt){
  let movedBound = false;
  for (const n of wireNodes){
    if (n.prop && props.indexOf(n.prop) >= 0){       // follow a moving bound prop
      const bp = n.prop.body.position;
      if (n.pos.x !== bp.x || n.pos.y !== bp.y || n.pos.z !== bp.z){
        n.pos.set(bp.x, bp.y, bp.z);
        n.mesh.position.copy(n.pos);
        if (n.bound) n.mesh.position.y += 0.6;        // keep the ray standing out of the prop
        movedBound = true;                            // a moved bound node can change conduction
      }
    }
    if (n._flash > 0){ n._flash -= dt;
      if (n._flash <= 0){ const c = baseNodeColor(n); n.mesh.material.emissive.setHex(c); n.mesh.material.emissiveIntensity = n.rep ? 0.7 : 0.6; } }
  }
  // recompute the powered set only when the graph changed — otherwise reuse the cache
  if (_wiringDirty || movedBound){ _poweredCache = poweredNodes(); _wiringDirty = false; }
  updateLights(_poweredCache);
  updateRadios(_poweredCache);
  for (const w of wireLines){
    const arr = w.line.geometry.attributes.position.array;
    arr[0]=w.a.pos.x; arr[1]=w.a.pos.y; arr[2]=w.a.pos.z;
    arr[3]=w.b.pos.x; arr[4]=w.b.pos.y; arr[5]=w.b.pos.z;
    w.line.geometry.attributes.position.needsUpdate = true;
    if (w._flash > 0){ w._flash -= dt; if (w._flash <= 0) w.line.material.color.setHex(WIRE_COLOR); }
  }
  recolorWires(_poweredCache);
}
function clearWiring(){
  for (const n of wireNodes) scene.remove(n.mesh);
  for (const w of wireLines) scene.remove(w.line);
  wireNodes.length = 0; wireLines.length = 0; wireNodeMeshes.length = 0; wireChain = null;
  markWiringDirty();
}

/* ---- save / load (used by world.js map files) ------------------------- */
// snapshot the whole wire graph. propIdx maps a prop -> its index in the saved props array.
function serializeWiring(propIdx){
  const nodeIdx = new Map();
  wireNodes.forEach((n, i) => nodeIdx.set(n, i));
  const nodes = wireNodes.map(n => ({
    k: n.button ? "button" : n.sw ? "switch" : n.rep ? "repeater" : "node",
    pos: [r3w(n.pos.x), r3w(n.pos.y), r3w(n.pos.z)],
    prop: (n.prop && propIdx.has(n.prop)) ? propIdx.get(n.prop) : -1,
    on: !!n.on,
  }));
  const links = [];
  for (const w of wireLines){
    const i = nodeIdx.get(w.a), j = nodeIdx.get(w.b);
    if (i != null && j != null && i < j) links.push([i, j]);   // each undirected wire once
  }
  return { nodes, links };
}
const r3w = v => Math.round(v*1000)/1000;
// rebuild the graph from a saved map. createdProps[i] is the live prop for saved index i.
function loadWiring(data, createdProps){
  clearWiring();
  if (!data || !Array.isArray(data.nodes)) return;
  const made = [];
  for (const nd of data.nodes){
    wireChain = null;   // suppress addNode's auto-chaining — we restore exact links below
    const prop = (nd.prop != null && nd.prop >= 0) ? (createdProps[nd.prop] || null) : null;
    const node = addNode(new T.Vector3(nd.pos[0], nd.pos[1], nd.pos[2]),
                         { button:nd.k === "button", sw:nd.k === "switch", rep:nd.k === "repeater", prop });
    if (nd.k === "switch" && nd.on){
      node.on = true;
      node.mesh.material.color.setHex(SWITCH_ON);
      node.mesh.material.emissive.setHex(SWITCH_ON);
      node.mesh.material.emissiveIntensity = 1.1;
    }
    made.push(node);
  }
  wireChain = null;
  for (const [i, j] of (data.links || [])) if (made[i] && made[j]) linkNodes(made[i], made[j]);
  markWiringDirty();
}

// the tool now exists — refresh the hotbar so it shows up
if (typeof drawTools === "function") drawTools();
