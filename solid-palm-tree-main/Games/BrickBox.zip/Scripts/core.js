"use strict";
/* core.js — renderer, scene, camera, lights. Globals shared with the other scripts. */
const T = THREE;

const scene = new T.Scene();
scene.background = new T.Color(0x8fb8e8);
scene.fog = new T.Fog(0x8fb8e8, 60, 200);

const camera = new T.PerspectiveCamera(70, innerWidth/innerHeight, 0.1, 500);
camera.rotation.order = "YXZ";

const renderer = new T.WebGLRenderer({ antialias:true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = T.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
addEventListener("resize", () => {
  camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

const sun = new T.DirectionalLight(0xfff2d8, 2.0);
sun.position.set(30, 50, 20); sun.castShadow = true;
// larger shadow map + a much wider orthographic frustum so shadows reach the far
// corners of the map instead of being clipped a little way out from the player.
sun.shadow.mapSize.set(3072,3072);
Object.assign(sun.shadow.camera, { near:1, far:600, left:-220, right:220, top:220, bottom:-220 });
sun.shadow.bias = -0.0004;
sun.shadow.normalBias = 0.02;
const hemi = new T.HemisphereLight(0xcfe6ff, 0x3a4560, 1.0);
scene.add(sun, hemi);
// warm fill so day scenes read like real sunlight; time-of-day tints these
const ambient = new T.AmbientLight(0xffffff, 0.15);
scene.add(ambient);
