"use strict";
/* embed.js — launcher chat-invite bridge for BrickBox.

   When this page is opened inside the launcher with a "#embed" hash, the
   launcher drives the WebRTC handshake over postMessage instead of the
   copy-paste code boxes in the Multiplayer menu. The launcher shuttles the
   offer/answer codes between players through its chat; here we just turn
   them into live connections using the same net.js engine.

   This bridge uses the JOINER-OFFERS / HOST-ANSWERS flow (same as net.js's
   menu), so a SINGLE host can accept MANY guests — that's what lets a
   BrickBox lobby hold up to 5 players. Each guest makes its own offer; the
   host answers each one individually.

   Protocol (launcher ↔ game):
     launcher → game : {__ttt, t:'host',   name}          become host, drop into the world
                       {__ttt, t:'join',   name}          guest: make an offer
                       {__ttt, t:'accept', code, guest}   host: answer this guest's offer
                       {__ttt, t:'answer', code}           guest: apply the host's answer
     game → launcher : {__ttt, t:'ready'}                  loaded, send me a command
                       {__ttt, t:'hosted'}                 host is live
                       {__ttt, t:'offer',  code}           guest's offer to relay to the host
                       {__ttt, t:'answer', code, guest}    host's answer for a specific guest
                       {__ttt, t:'connected'}              this guest joined
                       {__ttt, t:'players', count}         host: live player count changed */
(function () {
  if (location.hash.indexOf("embed") === -1) return;

  const up = (t, extra) => { try { window.parent.postMessage(Object.assign({ __ttt: true, t }, extra || {}), "*"); } catch (e) {} };

  // HOST: become the authoritative host and drop into the world. Guests are
  // accepted one at a time via 'accept' commands below.
  function embedHost(name) {
    if (name) myName = ("" + name).slice(0, 16);
    becomeHost();
    hostSyncRoster();                              // apply our chosen name to the roster
    enterSandbox();
    up("hosted");
  }
  async function embedAccept(code, guest) {
    try {
      const answer = await hostAcceptOffer(code);  // wires the peer + returns our answer
      up("answer", { code: answer, guest });
    } catch (e) {
      up("full", { guest });                       // game full (5) or a bad offer
    }
  }

  // GUEST: create an offer through net.js's normal client path, hand it up,
  // then apply the host's answer when it comes back down.
  async function embedJoin(name) {
    if (name) myName = ("" + name).slice(0, 16);
    const code = await clientCreateOffer();        // wires clientCh (onopen → onClientConnected)
    up("offer", { code });
  }
  async function embedAnswer(code) {
    if (clientPc) await clientUseAnswer(code);
  }

  // net.js bridge hooks — report connect/disconnect so the launcher can show N/5 + Full.
  window.onHostPeerOpen  = () => up("players", { count: hostPeers.length + 1 });
  window.onHostPeerClose = () => up("players", { count: hostPeers.length + 1 });
  window.onClientOpen    = () => up("connected");

  // Drop the title screen right away — the launcher owns the flow now.
  function ready() {
    if (typeof menu !== "undefined" && menu) menu.style.display = "none";
    toast("Connecting to game…");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready);
  else ready();

  // Commands coming DOWN from the launcher.
  window.addEventListener("message", async e => {
    const d = e.data;
    if (!d || !d.__ttt) return;
    try {
      if (d.t === "host") embedHost(d.name);
      else if (d.t === "join") await embedJoin(d.name);
      else if (d.t === "accept") await embedAccept(d.code, d.guest);
      else if (d.t === "answer") await embedAnswer(d.code);
    } catch (err) { toast("Connection error — try again"); }
  });

  // Tell the launcher we're loaded and ready for our first command.
  up("ready");
})();
