"use strict";
/* settings.js — title-screen Settings menu (Video / Audio / Controls / Credits),
   reusing the .gmenu chrome from the ToolRay spawn menu. Settings persist to
   localStorage (so they survive a reload) and are mirrored up to the Xbox launcher
   profile via postMessage. */

const SETTINGS_DEFAULTS = {
  fov:70, shadows:true, renderDist:200, shadowDist:220, lightRange:46,
  sensitivity:1.0, invertY:false,
  volMaster:1, volSfx:1, volMusic:1, volUi:1, volExpl:1,
  // combat: which damage sources hurt you (only matter when the host has turned Immunity off)
  dmgFall:true, dmgExplosive:true, dmgVoid:true,
};
const SETTINGS = Object.assign({}, SETTINGS_DEFAULTS);
const SETTINGS_KEY = "brickboxSettings";

const smenuEl = document.getElementById("smenu");
const smSecEl = document.getElementById("smsections");
const smHeadEl = smenuEl.querySelector("#smheader h2");
const smBodyEl = document.getElementById("smbody");
const smCloseEl = document.getElementById("smclose");

const SETTINGS_SECTIONS = [
  { id:"video",    name:"Video Settings" },
  { id:"audio",    name:"Audio Settings" },
  { id:"controls", name:"Controls" },
  { id:"gameplay", name:"Gameplay" },
  { id:"credits",  name:"Credits" },
];
let curSetSection = "video", smenuOpen = false;

/* ---- apply helpers ---------------------------------------------------- */
function applyFov(){ camera.fov = SETTINGS.fov; camera.updateProjectionMatrix(); }
function applyRenderDist(){
  const R = SETTINGS.renderDist;
  scene.fog.near = R * 0.35; scene.fog.far = R;              // push the fog wall out
  camera.far = Math.max(R * 2, 500); camera.updateProjectionMatrix();
}
function applyShadows(){
  renderer.shadowMap.enabled = SETTINGS.shadows;
  sun.castShadow = SETTINGS.shadows;
  renderer.shadowMap.needsUpdate = true;
  scene.traverse(o => { if (o.material){ (Array.isArray(o.material)?o.material:[o.material]).forEach(m => m.needsUpdate = true); } });
}
// how far the sun's shadow reaches — widen the orthographic frustum so shadows
// don't cut off at the far corners of the map.
function applyShadowDist(){
  const d = SETTINGS.shadowDist;
  const cam = sun.shadow.camera;
  cam.left = -d; cam.right = d; cam.top = d; cam.bottom = -d;
  cam.far = Math.max(600, d * 2.5);
  cam.updateProjectionMatrix();
  if (sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map = null; }   // force a fresh shadow map
}
function applyLightRangeSetting(){
  if (typeof LIGHT_RANGE !== "undefined"){ LIGHT_RANGE = SETTINGS.lightRange; if (typeof applyLightRange === "function") applyLightRange(); }
}
function applyAudioSettings(){
  if (typeof AUDIO === "undefined") return;
  AUDIO.master = SETTINGS.volMaster; AUDIO.sfx = SETTINGS.volSfx;
  AUDIO.music = SETTINGS.volMusic; AUDIO.ui = SETTINGS.volUi; AUDIO.explosions = SETTINGS.volExpl;
  if (typeof refreshRadioVolumes === "function") refreshRadioVolumes();
}
function applyAllSettings(){
  applyFov(); applyRenderDist(); applyShadows(); applyShadowDist();
  applyLightRangeSetting(); applyAudioSettings();
}

/* ---- persistence ------------------------------------------------------ */
function saveSettings(){
  try {
    const blob = Object.assign({}, SETTINGS);
    if (typeof PART_LIMIT !== "undefined") blob.partLimit = PART_LIMIT;
    if (typeof currentTime !== "undefined") blob.time = currentTime;
    const json = JSON.stringify(blob);
    localStorage.setItem(SETTINGS_KEY, json);
    // mirror into the Xbox launcher profile (launcher persists this per-profile)
    try { if (window.parent && window.parent !== window) window.parent.postMessage({ __brickboxSettings:true, data:blob }, "*"); } catch(e){}
  } catch(e){}
}
function loadSettings(){
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(SETTINGS_KEY)); } catch(e){}
  if (saved && typeof saved === "object"){
    for (const k in SETTINGS_DEFAULTS) if (saved[k] != null) SETTINGS[k] = saved[k];
    applyAllSettings();
    // world-owned settings apply after every module has loaded (gadgets.js defines applyTimeOfDay)
    setTimeout(() => {
      if (saved.partLimit != null && typeof setPartLimit === "function" && !(typeof netIsClient === "function" && netIsClient())) setPartLimit(saved.partLimit);
      if (saved.time != null && typeof applyTimeOfDay === "function" && !(typeof netIsClient === "function" && netIsClient())) applyTimeOfDay(saved.time);
    }, 0);
  } else {
    applyAllSettings();
  }
}

/* ---- confirm dialog (yes / no) ---------------------------------------- */
function askConfirm(message, onYes){
  const wrap = document.createElement("div");
  wrap.style.cssText = "position:fixed;inset:0;z-index:90;display:flex;align-items:center;justify-content:center;background:rgba(6,9,16,.75);backdrop-filter:blur(4px)";
  const card = document.createElement("div");
  card.style.cssText = "width:min(360px,90%);background:rgba(12,17,27,.97);border:1px solid rgba(255,255,255,.16);border-radius:14px;padding:22px 24px;text-align:center";
  card.innerHTML = `<div style="font-size:15px;font-weight:700;line-height:1.5;margin-bottom:18px">${message}</div>`;
  const row = document.createElement("div"); row.style.cssText = "display:flex;gap:12px;justify-content:center";
  const yes = document.createElement("span"); yes.className = "mpbtn"; yes.textContent = "YES";
  const no  = document.createElement("span"); no.className = "mpbtn ghost"; no.textContent = "NO";
  const close = () => { document.body.removeChild(wrap); };
  uiBtn(yes, () => { close(); onYes(); });
  uiBtn(no, close);
  row.appendChild(yes); row.appendChild(no); card.appendChild(row); wrap.appendChild(card);
  document.body.appendChild(wrap);
}

/* ---- rendering -------------------------------------------------------- */
function renderSettings(){
  smSecEl.innerHTML = '<div class="lbl">SETTINGS</div>';
  SETTINGS_SECTIONS.forEach(s => {
    const el = document.createElement("div");
    el.className = "tmsec" + (s.id===curSetSection?" on":"");
    el.textContent = s.name;
    uiBtn(el, () => { curSetSection = s.id; renderSettings(); });
    smSecEl.appendChild(el);
  });
  const sec = SETTINGS_SECTIONS.find(s => s.id===curSetSection);
  smHeadEl.textContent = sec ? sec.name.toUpperCase() : "";
  smBodyEl.innerHTML = "";
  if (curSetSection === "video") renderVideo();
  else if (curSetSection === "audio") renderAudio();
  else if (curSetSection === "controls") renderControls();
  else if (curSetSection === "gameplay") renderGameplay();
  else renderCredits();
}

function setSlider(label, min, max, step, val, fmt, onInput){
  const row = document.createElement("div"); row.className = "setrow";
  row.innerHTML = `<span class="lab">${label}</span>`;
  const input = document.createElement("input"); input.type = "range";
  input.min = min; input.max = max; input.step = step; input.value = val;
  const valEl = document.createElement("span"); valEl.className = "val"; valEl.textContent = fmt(val);
  input.addEventListener("input", () => { const v = parseFloat(input.value); valEl.textContent = fmt(v); onInput(v); });
  input.addEventListener("change", () => { uiClick(); saveSettings(); });
  row.appendChild(input); row.appendChild(valEl);
  return row;
}
function toggleRow(label, get, onToggle){
  const row = document.createElement("div"); row.className = "setrow";
  row.innerHTML = `<span class="lab">${label}</span>`;
  const sw = document.createElement("div"); sw.className = "tsw" + (get() ? " on" : "");
  uiBtn(sw, () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onToggle(now); saveSettings(); });
  row.appendChild(sw); return row;
}
// a "Reset to defaults" button with a yes/no confirm, resetting the given keys
function resetButton(label, keys, extraApply){
  const wrap = document.createElement("div"); wrap.style.marginTop = "16px";
  const b = document.createElement("span"); b.className = "mpbtn ghost"; b.textContent = label;
  uiBtn(b, () => askConfirm("Reset these settings to their defaults?", () => {
    keys.forEach(k => { if (SETTINGS_DEFAULTS[k] != null) SETTINGS[k] = SETTINGS_DEFAULTS[k]; });
    applyAllSettings(); if (extraApply) extraApply(); saveSettings(); renderSettings();
    toast("Reset to defaults");
  }));
  wrap.appendChild(b); return wrap;
}

function renderVideo(){
  const panel = document.createElement("div"); panel.className = "setpanel";
  panel.appendChild(setSlider("Field of View", 60, 110, 1, SETTINGS.fov, v => v+"°", v => { SETTINGS.fov = v; applyFov(); }));
  panel.appendChild(toggleRow("Shadows", () => SETTINGS.shadows, v => { SETTINGS.shadows = v; applyShadows(); }));
  panel.appendChild(setSlider("Shadow Distance", 120, 400, 20, SETTINGS.shadowDist, v => ""+v, v => { SETTINGS.shadowDist = v; applyShadowDist(); }));
  panel.appendChild(setSlider("Render Distance", 100, 1200, 20, SETTINGS.renderDist, v => ""+v, v => { SETTINGS.renderDist = v; applyRenderDist(); }));
  panel.appendChild(setSlider("Light Brightness / Range", 24, 80, 2, SETTINGS.lightRange, v => ""+v, v => { SETTINGS.lightRange = v; applyLightRangeSetting(); }));
  panel.appendChild(resetButton("RESET VIDEO", ["fov","shadows","shadowDist","renderDist","lightRange"]));
  smBodyEl.appendChild(panel);
}

function renderAudio(){
  const panel = document.createElement("div"); panel.className = "setpanel";
  const pct = v => Math.round(v*100) + "%";
  panel.appendChild(setSlider("Master Volume",     0, 1, 0.05, SETTINGS.volMaster, pct, v => { SETTINGS.volMaster = v; applyAudioSettings(); }));
  panel.appendChild(setSlider("Sound Effects",      0, 1, 0.05, SETTINGS.volSfx,    pct, v => { SETTINGS.volSfx = v; applyAudioSettings(); }));
  panel.appendChild(setSlider("Music (Radios)",     0, 1, 0.05, SETTINGS.volMusic,  pct, v => { SETTINGS.volMusic = v; applyAudioSettings(); }));
  panel.appendChild(setSlider("Explosions",         0, 1, 0.05, SETTINGS.volExpl,   pct, v => { SETTINGS.volExpl = v; applyAudioSettings(); }));
  panel.appendChild(setSlider("Menu / UI",          0, 1, 0.05, SETTINGS.volUi,     pct, v => { SETTINGS.volUi = v; applyAudioSettings(); }));
  panel.appendChild(resetButton("RESET AUDIO", ["volMaster","volSfx","volMusic","volUi","volExpl"]));
  smBodyEl.appendChild(panel);
}

function renderControls(){
  const panel = document.createElement("div"); panel.className = "setpanel";
  panel.appendChild(setSlider("Mouse / Trackpad Sensitivity", 0.2, 3.0, 0.05, SETTINGS.sensitivity,
    v => v.toFixed(2) + "×", v => { SETTINGS.sensitivity = v; }));
  panel.appendChild(toggleRow("Invert Y-Axis", () => SETTINGS.invertY, v => { SETTINGS.invertY = v; }));

  const hint = document.createElement("div"); hint.className = "hint";
  hint.style.cssText = "margin-top:14px;opacity:.65;font-size:11px;line-height:1.6";
  hint.innerHTML =
    "<b>Trackpad tips:</b> two-finger scroll = scroll wheel &nbsp;·&nbsp; " +
    "two-finger tap = right-click &nbsp;·&nbsp; " +
    "raise sensitivity to ~1.5–2× for comfortable play.";
  panel.appendChild(hint);
  panel.appendChild(resetButton("RESET CONTROLS", ["sensitivity","invertY"]));
  smBodyEl.appendChild(panel);
}

function renderGameplay(){
  const panel = document.createElement("div"); panel.className = "setpanel";
  // In multiplayer as a client, damage sources are controlled by the host
  if (typeof netIsClient === "function" && netIsClient()){
    const note = document.createElement("div"); note.className = "hint";
    note.style.cssText = "margin:0 0 12px;opacity:.7;font-size:12px;line-height:1.6";
    note.innerHTML = "Damage settings are controlled by the <b>host</b> in multiplayer.";
    panel.appendChild(note);
    smBodyEl.appendChild(panel);
    return;
  }
  const note = document.createElement("div"); note.className = "hint";
  note.style.cssText = "margin:0 0 12px;opacity:.7;font-size:12px;line-height:1.6";
  note.innerHTML = "These only take effect when the host has turned <b>Immunity</b> off (ToolRay ▸ Combat). " +
                   "While you're immune you can't be hurt regardless of these switches.";
  panel.appendChild(note);
  panel.appendChild(toggleRow("Fall damage",      () => SETTINGS.dmgFall,      v => { SETTINGS.dmgFall = v; }));
  panel.appendChild(toggleRow("Explosive damage", () => SETTINGS.dmgExplosive, v => { SETTINGS.dmgExplosive = v; }));
  panel.appendChild(toggleRow("Void damage",      () => SETTINGS.dmgVoid,      v => { SETTINGS.dmgVoid = v; }));
  panel.appendChild(resetButton("RESET GAMEPLAY", ["dmgFall","dmgExplosive","dmgVoid"]));
  smBodyEl.appendChild(panel);
}

function renderCredits(){
  const panel = document.createElement("div"); panel.className = "setpanel";
  panel.innerHTML =
    `<div class="credit">Explosion sprites by <b>Ansimuz</b><br>` +
    `<a href="https://ansimuz.itch.io/" target="_blank" rel="noopener">https://ansimuz.itch.io/</a></div>`;
  smBodyEl.appendChild(panel);
}

function openSettings(){ if (smenuOpen) return; smenuOpen = true; curSetSection = "video"; smenuEl.classList.add("open"); renderSettings(); }
function closeSettings(){ if (!smenuOpen) return; smenuOpen = false; smenuEl.classList.remove("open"); saveSettings(); uiClose(); }
uiBtn(smCloseEl, closeSettings);
addEventListener("keydown", e => { if (smenuOpen && e.key === "Escape"){ closeSettings(); e.stopPropagation(); } }, true);

const settingsBtn = document.getElementById("settingsBtn");
if (settingsBtn){
  settingsBtn.addEventListener("mouseenter", uiHover);
  settingsBtn.addEventListener("click", e => { e.stopPropagation(); uiClick(); openSettings(); });   // don't trigger the title's pointer-lock
}

// load persisted settings on boot
loadSettings();
