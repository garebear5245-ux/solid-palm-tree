"use strict";
/* effects.js — cannonball explosions: spritesheet animation, distance-based
   sound, radial blast force on nearby props, and a brief screen shake. */

// spritesheets are a single horizontal row of square frames (left -> right)
const EXPL_SHEETS = [
  { img: new Image(), frames: 8 },   // Explosion1.png 384x48
  { img: new Image(), frames: 7 },   // Explosion2.png 336x48
];
// Inlined as data URIs so the textures load under the file:// protocol.
// (file:// treats each file as a unique origin, which taints WebGL textures
//  loaded from separate .png files and blocks them with a SecurityError.)
EXPL_SHEETS[0].img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYAAAAAwCAYAAAAYeq1+AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAACkpJREFUeNrsXT2OHTcMXhmpNkUKAwFcBHCAnCHdXmSPkGLLlClSpnSRI+xFtssZAiSACwMBXKSIW+Vpd2Tr8VESKZGSZh4/IMA6b0bi/H0fSUmU897fGAwGg+H68MpugcFgMFwnvrJbYDAYZuGXH7+vHvPrH3/FY/32b5eeG3/ntIm1z7ExsWmK/TWbc9cAzzMBMBiIuP/ua5gvdY/v/+tpL/6J5WFd/KPWB4PwfK6PThIt2t9LXorwhGt1FgEYDAZtMcmS6unYLqHRJM/K7yzy/PPDP1mh/OHNtz4RJ3861uX6ybUDbT61ybapdA7F/uj9l4QQawd7/jCiwH5L7pMJgGH/3rSU15zFXel7uc0d/8WWJ+8y7fpqWzW7nuoTNgrkd0FeybEUEtUkTw9/rxEXEEiv5a1niJdtP0bShXebhFKblP5MAAxH9JpdX9u356L09lOeHN5+WmkK3XIkGrxegg097ZPFbyPzoi3Ra9YWkELfriQOGlGgCcDK+PhOOjTnf4yvH9rt7/WmKefU+n7S5ej7v4FNOh+qf+7nxUMUTQdRSRSSJ5Us09QN5x1EziORvDTCdUJvOk3dbH+7nvZnUowJwDHgG45banBL0Jv2gtfmLwj+xVZ+SzA1VI9mRDzwFUhUAY753pMQiF6LkDEhmU3+JgDXQ/ylc484y+ELcSt4zWeE3kjkqUd9P0AMpEk0Te3khIZrSxAmQlvpIOqQdzclaoTEz4QVG+xN/53m+WspKemIArtfJgDXR/xDheBExJeDvSdvv8mLHkOI1ft7uib3WPq9TuhO2nttJVFG5OBKxwRBaBQCn7Q59IFDstxEjXsdHhC6qwg/e7CXI0y555ATSxOA6yZ/rdRJ/gPoSPVE0cDSMl0i1eeBj4ygnDSJUgdpU7LZSAZtq0Ke5HuVLJbyOQ8aEmlpqiSFDGvHhf7ggipKWzD9E0VAyv7avy0FlOKOdG988wusO+ionSpQF4FI3tkI4Kc3+ZN//6AqBEKE7wf3J0r4AumcbH+aHn4uxQeFJP6dE7GtHcfpgyskvfa3tGMCIEOuMwdR/cB+mq/t3Ju+rQrB80v72ze0xlNxOIkBUQhUnxP84DrCezQnHyKmkHLqJaHJ3xX7GWDpDanUSRQlavQT3mnOFNIa4fdeR3L+RYSyjgB8fHdOWK8f3OIv6ZIpk2vA/c//npMqRRCCGICIIBGXoaTfSPSu5f3cPvJp7x2XPDNRhev1mHu98BwJx/+fPuPS/ebM5Okh/pL92N/Ud1RWACDp535bSwx6Z9K4xW1c+br6kIjAEbzmLTfs0uvYm5gDYaDYLzIgniNX7rNveFd2bb+cAJTIHzt2DRHwQm1YJLCYCECv+aY8FZTyETsGIfR8pD6JZMRIiOqxw+O4Ka6WMQRumYTc/aN6vxxPPOfhg5o+u7Bfbxooh/zXEQHpqZRuB3YeU9jyImBgihA3hXA0wMJzR7e/XwBayH++CHilNi0SQLzRkKPnzNgJYwLkgWEBEaDOzaaQYnqMdPnoo4LiZWukPzTsT2ftrGY/ZlOfAPSQ/zqRgGG2N3oiezgQvBNvy/ZTFXbG0hk/aTQiQY6gjHQWzFXOKNGHNlay3xaCHeDjmNQ/24uRmq7XJSqXUUf2WiCRb+eSjlWKoLjPH65ohe2wCGgjDTeAPMWihtAvdSGVJLTLUfTaX7PvGgXAK7dt0cws2FhAF7Gk5D2qUFluoVMkc6ozEcQmWaXrsIiilHbJ/Q42ngn9uNL9jP1R7KekiXrtr6FdACTSP2lblgY6EtzmSfvUqy6t8mXn/LUjCNl8rGvpN04JjfcxF5VAEoXz1jkkWvPqOaCS5x6ep/TaC0xgS4LQan9tUN9SQAbDwOgTkPHuBoUFVz5fiGRpS0XYP6X4HHVlrNA1sO2Pf+eirRH2mwAY9Ejibm5QV8rllzz0MHbwSPfmuSVEWsg2lp4WIaG0TWmvvzcC6kVpxWyP2MZ2Yv0gyY3tS2kgafthGyYAht0Cmzn0+HaMJ68QEVzlFFG4vy7Vmy0VbRsZ5XTaPz1KaxeAkLOXGgew/L9BShRAtVHu3H3KsbNmOeXsbCUhruePzQ7qIR/V9wDpV2tf3T3bf40RgMZmHFqhrqatI67n3P4wQ6dU7pno6VPWDaQ7grE+mjv3Yi/cwnEmNpueN6KpXwtrgx9uqgfuC8CMmMjiUSvWNkt8odjuzX4TAMP+vXzdRWOzRRdZa3A7xX6JefycNihll3sBp2um5ChVkG0WubfY/6qrZ4nUjaV/DCsiRgJ5kk3/WxHN5B1Ie1I9nLB61kt5yYH44rXAa1phQ3aq/XElsYYQ9UcAPWMB88hfbU/WA3mkItezzcL5Yj82cLvYGgBDV/TSFTnECKBVBGqlD2A0kFtBjEUNyt852X6YhuPYL1sLqEcE5nv+ksRqUQyawqClLpqKv2naH0UrX/bBYQu2JLxvqfcxEEmYEooNytYGaiFJYAuUtD3o1hWupf1xoc05km0VsfTe7sV+uTEAjgisk/aREAG3Ezt3K2hQHPDpn58ggauKVuP9pO6M5RqEJK62hd5k97PEBntL5BOP7yXRlEip4sUh19bzSgPBq9hPPVZ2EDgl9v1sCdlDrub5zxSERer+IB+1yHvBWMi2JGBRusKm8J/FS7u4GjXqoKRWVrafCr1ZQPsa3G0RAbcDG48rannyd2d7BD+p3DJP2GXs4uPEhAE7//n/IYPQEoOAUlEBlRQ1hbYnsmhtAxMxKumPtD8XbdhKYBrx+UXJUVsE5l1fJPTSOgFA+sgmMw5uEL9CRED4WC/KUUtdT67o2OahZ9M4PQKTlKNwrfbO9KSBN727Cr9jVgLvFTSPcOUHriUCo2q/4IWvQv2dQHYHLudMFYZN2JYQM0gilGsIXrJwLaEbqlBJTCEFURJpNlGLYGnZz4FFAPuOVrxgW8uDs62kUgQoQVpe6f67zasfuqftnvbQ5YgYdQOcXKSlEcG07tdcGhswAbheIVAjflgN9ETczQShTPpXIZwYWj10JKXkpO5lKl61aaaSEUZOxBiDqlPE1yIAA9d7XZq0PqeBJpBwKlpE0fGfRa6vbtAUwohEhW0f2dLODPFqmfWSes+JyIh/F7WxjHRAttV+E4Cj4/XDvj3TON6SqUWPEeBFwTPuHrwys37I4yzPopXO2MmJwemYirCIPTfKZikJgYfjKStdfWEa55CcPyI67P2qqSLWm8LBzk+jmu1ekusR9ZC/DQIbDhvxiNdHCQKCfzAk0cpO1wvCMEDMCiSdtZ+4VWNRFEvi0EKclJXGW56eJKLwmdT2RJYk/tr1tJQsz9nP/R5MAAxDCZvj8cyKaAbX/BcXs223qlEbvIs9H0XxIpExtttXWPVLFbfKfg2k8TpKXyX7Q18c+00ADEMItfCbaz13YdHKhd9O4/pq2xMiXqmTuicStmOlFUANHOk+z8SxJ92Ts58izIhIDLffee9vDAaDwXB9eGW3wGAwGEwADAaDwWACYDAYDIaj438BBgBSNaxWz8cpIgAAAABJRU5ErkJggg==";
EXPL_SHEETS[1].img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVAAAAAwCAMAAABwtdIFAAAAAXNSR0IArs4c6QAAADBQTFRFAAAA/+yRAAAA/zwAWRwK/6YZfTUg/////24w4GEq7WYs5Ycp5Wcw/0ESmDYVpzsX4WTrgwAAABB0Uk5TAP///////////////////8BQi0MAAARASURBVGiB7ZqLjuMgDEUTVUklFIn//9sNYIMJ+JFq6GZ2udK0DbVpe8ZgA1mWqampqalfp/UjG4vXfyoT0MZoAg3qUjChaYhOoFEdDG3wdR1PK+/vev0H6kyGRjQ+SOin74Kets/Y4Wm3mX9Hm/huO3TvAfXeW/mgpfdGp937HZ49vHyCZKANQCvQBMQMJ5tmrovmtAPF/UEwgxSgNUHnqkuJLbJ5nTJQ9ZWwB0EkPh/Fc9nMRJ3bXBB5R3T0GejrHtDSJjjsyPFZOE+g6hAGom4LIkRlnhnmqyAVzdtsZM1N4/RJbWICGmwS0MAUmyUnfxcoeSx9aF9ttD4AuhmSTCKagW5x8Av2EG2vWuZiqHTz94FmOHrcRR3HCfQIUvpd18LzjNGIlRMmawRZHow/A7p5UojaeAaQ27YeAY9MNGaki9gYBaAJJ2abFKNs90w08h5fSkXrtsQfayoWj4PyUYwTUEe5cqYUaC7wxUHPZnfOAWvQwbLjiUpAVytQl4wcDnlpzIeHxBMbXnyIlvVRvi5Eew5Qfw4nCrG5WolGoGF6XM1jPr1wCzuJrqXwp3EmjXl/XcFrQJsV/CiyAc/7/QZAuv2RaAJRDWglISsFotcVDxCVeF6A+l4ZlYT4CNBB4z+EWwK63gAaPc6BH7zMH+WUpISVJ14DUMY6PdMWqWht2Y2aUVOAYozq9hFocVA8HF31u5CfGEO6fs8toZE1922LBLRhNw7oVoDq5mkGLUDlMR+TErnSA5Qk9esi/WJ+bZdXVZ3dz2HpCfi834pdzEUpx79xyKtAaQjXV5V8G6FJfJLv9GDZv/uGAKgcn5DaIcfnLKYArdKQ44kC0KZWZ5dKGV815Qob9xCiX9mnj3ysZehWsnwIUBGouxSrASgz6IEnbfBYiHbNcalawOaWXv/7ZV95aPUUGFnr+rMOjShNZVMBuuEn8UB9WnGWa48L0Q6hCqin8y0XoBko7DAbfurHMhf1UUcgCSslZXuEruQX+OPTfLUs8oToLaCMGqDxyvBzP5GxAkWltVJ4VHh29kbEQrTQy8cfZ9nUHfP1UDcBhaFOz+gGAb19+n2EYX/o+3c9oGwhWnaaUmpHPv059LpUUoFel0pDgX7iY3NyeAKScfJbzDDAw0t6ntTn2ezclemTm0RNX/hHNBDoEgCmAyUXT+sk21w6xU2nJYFkN5ilTT3bdwM944aHD26ScVJ4JpXTTnoIwlqjE13Q/1agps39tQl+/f/gy9mHsBmKtktV2qsL+qiK35f2nA0yAO3cLmK4gyTtL2EFGuFwTlUmKvujwg5Jm4kec8eD6dSz16i50bSteRGgngDlOycBiU8P4anei8NQMN81ZugrqKpDVZ4LrUO/dSTyU2IYDLnl0zJ1VnrO1GkWC850i8TdT7vJ81dFZhLPxAL0R7/KPyGJmk50Am0kIplAp6ampqai/gBGWkMnKP1sWgAAAABJRU5ErkJggg==";
EXPL_SHEETS.forEach(e => e.img.addEventListener("load", () => {
  if (e.img.naturalHeight) e.frames = Math.max(1, Math.round(e.img.naturalWidth / e.img.naturalHeight));
}));

const EXP_NEAR = [1,2].map(i   => S+"Explosion/MediumExplosion"+i+".ogg");
const EXP_FAR  = [1,2,3].map(i => S+"Explosion/FarMediumExplosion"+i+".ogg");
const pick = arr => arr[Math.floor(Math.random()*arr.length)];

const explosions = [];               // live sprite animations
const pendingExplosions = [];        // detonations queued during a physics step
let shake = 0;                        // 0..1 camera shake amount, decays each frame

const BLAST_R = 22, BLAST_FORCE = 190;   // radius (units) and impulse strength
const EXPL_DMG = 85;                      // max HP lost at the very centre of a blast

function queueExplosion(prop){
  pendingExplosions.push(new T.Vector3(prop.body.position.x, prop.body.position.y, prop.body.position.z));
}

/* ---- explosion light flash --------------------------------------------
   A real point light that pops at the blast and fades over ~0.5s. Uses a fixed
   pool created once (like the Light pool) so there's no per-explosion shader
   recompile — runtime we only change intensity/position. */
const EXPL_LIGHT_POOL_MAX = 3;
let explLightPool = null;
const explLightState = [];   // per-slot { t, dur, on }
function ensureExplLightPool(){
  if (explLightPool) return;
  explLightPool = [];
  for (let i = 0; i < EXPL_LIGHT_POOL_MAX; i++){
    const pl = new T.PointLight(0xffb060, 0, 46, 2);
    pl.castShadow = false; scene.add(pl);
    explLightPool.push(pl); explLightState.push({ t:0, dur:0, on:false });
  }
}
function spawnExplosionLight(pos){
  ensureExplLightPool();
  // grab a free slot, else the one closest to finishing
  let idx = 0, bestRem = Infinity;
  for (let i = 0; i < explLightPool.length; i++){
    const s = explLightState[i];
    if (!s.on){ idx = i; bestRem = -1; break; }
    const rem = s.dur - s.t;
    if (rem < bestRem){ bestRem = rem; idx = i; }
  }
  explLightPool[idx].position.copy(pos);
  explLightState[idx].t = 0; explLightState[idx].dur = 0.5; explLightState[idx].on = true;
}
function updateExplosionLights(dt){
  if (!explLightPool) return;
  for (let i = 0; i < explLightPool.length; i++){
    const s = explLightState[i]; if (!s.on) continue;
    s.t += dt;
    const k = 1 - s.t / s.dur;
    if (k <= 0){ s.on = false; explLightPool[i].intensity = 0; continue; }
    explLightPool[i].intensity = 11 * k;   // bright pop that eases to nothing
  }
}

function spawnExplosionSprite(pos){
  const sheet = pick(EXPL_SHEETS);
  const tex = new T.Texture(sheet.img);
  tex.colorSpace = T.SRGBColorSpace;
  tex.needsUpdate = true;
  tex.repeat.set(1/sheet.frames, 1);
  tex.offset.set(0, 0);
  const mat = new T.SpriteMaterial({ map:tex, transparent:true, depthWrite:false });
  const sp = new T.Sprite(mat);
  sp.position.copy(pos);
  sp.scale.set(16, 16, 1);
  sp.renderOrder = 999;
  scene.add(sp);
  explosions.push({ sp, tex, frames:sheet.frames, t:0, dur:0.55 });
}

// audio-visual + local-player part of a blast, with no world physics — the host
// does the full explode() (which also moves props); clients receive a broadcast
// and run this. The player knockback/damage lives here (not in explode) so that
// EVERY player — host and clients alike — computes their own hit locally. Health
// is locally authoritative, so this is what lets non-host players actually die.
function boomFx(pos){
  // sound: near clips up close, far clips further away
  const dist = camera.position.distanceTo(pos);
  const src = dist < 45 ? pick(EXP_NEAR) : pick(EXP_FAR);
  oneShot(src, Math.max(0.25, Math.min(1, 1 - dist/170)), "explosions");
  spawnExplosionSprite(pos);
  spawnExplosionLight(pos);          // real light flash for ~0.5s

  // knock the local player around + hurt them if they're close to the blast
  const pd = camera.position.distanceTo(pos);
  if (pd < BLAST_R){
    const f = 1 - pd/BLAST_R;
    velY += 7*f;
    shake = Math.min(1, shake + f);
    // explosive damage, scaled by proximity to the blast
    if (typeof damageEnabled === "function" && damageEnabled("Explosive") && typeof applyDamage === "function"){
      applyDamage(f * EXPL_DMG, "explosive");
    }
  }
}

function explode(pos){
  boomFx(pos);

  // tell clients to play the same blast — they run no physics, so this
  // detonation only ever happens on the host and must be broadcast
  if (typeof netIsHost === "function" && netIsHost()) hostBroadcastBoom(pos);

  // radial impulse on every nearby prop, stronger the closer it is
  for (const pr of props){
    if (pr._dead) continue;
    if (pr.explodable === false) continue;   // wrench: this prop ignores explosive force
    const bp = pr.body.position;
    const dx = bp.x-pos.x, dy = bp.y-pos.y, dz = bp.z-pos.z;
    const d = Math.hypot(dx,dy,dz);
    if (d > BLAST_R) continue;
    if (pr.frozen) setFrozen(pr, false);          // the blast frees frozen props
    const f = 1 - d/BLAST_R, inv = d > 0.001 ? 1/d : 0;
    const imp = new CANNON.Vec3(
      dx*inv*BLAST_FORCE*f,
      (dy*inv*0.6 + 0.9)*BLAST_FORCE*f,           // bias upward so debris launches
      dz*inv*BLAST_FORCE*f);
    pr.body.wakeUp();
    pr.body.applyImpulse(imp, pr.body.position);   // apply at CoM (world point) = central impulse
    pr.body.angularVelocity.set((Math.random()-.5)*10,(Math.random()-.5)*10,(Math.random()-.5)*10);
  }
  // (player knockback + damage is applied in boomFx, which every player runs locally)
}

function processExplosions(){
  while (pendingExplosions.length) explode(pendingExplosions.pop());
}

function updateExplosions(dt){
  updateExplosionLights(dt);          // fade any active blast lights
  for (let i = explosions.length-1; i >= 0; i--){
    const e = explosions[i];
    e.t += dt;
    const fr = Math.floor(e.t / e.dur * e.frames);
    if (fr >= e.frames){
      scene.remove(e.sp);
      if (e.sp.material.map) e.sp.material.map.dispose();
      e.sp.material.dispose();
      explosions.splice(i, 1);
      continue;
    }
    e.tex.offset.x = fr / e.frames;   // step across the sheet, left -> right
  }
}
