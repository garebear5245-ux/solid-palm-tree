"use strict";
/* input.js — pointer lock, mouse and keyboard handling. */
const keys = Object.create(null);
let locked = false, gravityOn = true;
const menu = document.querySelector("#menu"), dom = renderer.domElement;

dom.addEventListener("click", () => { if (!locked) dom.requestPointerLock(); });
menu.addEventListener("click", () => dom.requestPointerLock());
document.addEventListener("pointerlockchange", () => {
  locked = document.pointerLockElement === dom;
  if (tmenuOpen){ for (const k in keys) keys[k] = false; return; }  // menu unlocked the cursor on purpose
  // the multiplayer menu also frees the cursor on purpose — don't pop the title screen back up
  if (mpmenuOpen){ for (const k in keys) keys[k] = false; return; }
  if (typeof cfgOpen !== "undefined" && cfgOpen){ for (const k in keys) keys[k] = false; return; }  // Wrench config overlay
  menu.style.display = locked ? "none" : "flex";
  if (!locked){ releaseGrab(); closeChat(); for (const k in keys) keys[k] = false; }
});
addEventListener("mousemove", e => {
  if (!locked || chatOpen) return;
  if (typeof moveArrowDragging === "function" && moveArrowDragging()){ moveArrowDragMove(e.movementX, e.movementY); return; }
  if (typeof resizeDragging === "function" && resizeDragging()){ resizeDragMove(e.movementY); return; }  // dragging a resize handle
  const sens = (typeof SETTINGS !== "undefined" ? SETTINGS.sensitivity : 1) * 0.0022;
  const invertY = typeof SETTINGS !== "undefined" && SETTINGS.invertY;
  camera.rotation.y -= e.movementX * sens;
  camera.rotation.x -= e.movementY * sens * (invertY ? -1 : 1);
  const lim = Math.PI/2 - 0.001;
  camera.rotation.x = Math.max(-lim, Math.min(lim, camera.rotation.x));
});
addEventListener("mousedown", e => {
  if (!locked || chatOpen) return;
  if (e.button === 0){
    // Sword equipped: left-click swings
    if (typeof SWORD_TOOL !== "undefined" && activeTool === SWORD_TOOL){ if (typeof swingSword === "function") swingSword(); return; }
    // Flashlight equipped: left-click toggles the beam
    if (typeof FLASHLIGHT_TOOL !== "undefined" && activeTool === FLASHLIGHT_TOOL){ flashlightPrimary(); return; }
    // Empty hand: left-click a nearby dropped flashlight to pick it up
    if (activeTool === -1 && typeof tryPickupFlashlight === "function" && tryPickupFlashlight()) return;
    // Left-clicking a playing Radio turns it off when nothing else is equipped OR in ToolRay spawn mode
    if (activeTool === -1 || activeTool === 0){
      const _mode = (typeof toolRayMode !== "undefined") ? toolRayMode : "spawn";
      if (activeTool === -1 || _mode === "spawn"){
        const _rm = aimedProp();
        if (_rm && _rm.p.type === RADIO && _rm.p.radioOn){
          if (netIsClient()){ if (canUseTools()) netClientCmd({ t:"cmd", cmd:"radioOff", netId:_rm.p.netId }); }
          else setRadioOn(_rm.p, false);
          return;
        }
      }
    }
    if (activeTool === 0){
      toolRayPrimary();          // ToolRay: spawn / paint / configure / resize (per mode)
    }
    else if (activeTool === 1) grab();               // GravityRay grabs
    else if (activeTool === WIRING_TOOL) wiringPrimary();   // Wiring: place/chain a node
  } else if (e.button === 2){
    // right-click always presses a wire button under the crosshair, whatever tool is equipped
    if (typeof pressAimedButton === "function" && pressAimedButton()) return;
    // Right-click on a Radio: play, or skip to next song if already playing
    { const _rr = aimedProp();
      if (_rr && _rr.p.type === RADIO){
        if (netIsClient()){ if (canUseTools()) netClientCmd({ t:"cmd", cmd:"radioInteract", netId:_rr.p.netId }); }
        else radioInteract(_rr.p);
        return;
      }
    }
    if (activeTool === 0){
      if (typeof toolRayMode !== "undefined" && toolRayMode === "move" && typeof moveTarget !== "undefined" && moveTarget && !moveArrowDragging()){ moveRayRotate(); return; }
      openToolMenu();            // ToolRay: right-click opens the spawn menu
    }
    else if (activeTool === 1){ if (held || (netIsClient() && clientIsGrabbing())) punt(); else dryFire(); }
    else if (activeTool === WIRING_TOOL) wiringSecondary();  // Wiring: place a button, or press one
  }
});
addEventListener("mouseup", e => {
  if (e.button !== 0) return;
  if (typeof moveArrowDragging === "function" && moveArrowDragging()){ _endMoveDrag(); return; }
  if (typeof resizeDragging === "function" && resizeDragging()){ endResizeDrag(); return; }   // finish a resize drag
  if (activeTool === 1){
    if (held || (netIsClient() && clientIsGrabbing())) oneShot(S+"Tools/GravityRay/Close.ogg");   // cancelled a grab
    releaseGrab();
  }
});
addEventListener("contextmenu", e => e.preventDefault());
addEventListener("wheel", e => {
  if (!locked || chatOpen) return;
  if (activeTool === 1 && held) holdDist = Math.max(3, Math.min(28, holdDist - Math.sign(e.deltaY)*1.4));
  else if (activeTool === 1 && netIsClient() && clientIsGrabbing()) netClientScroll(e.deltaY);
  else {                                                  // scroll switches tools
    // cycle only through tools that are actually in the hotbar (granted), so
    // an ungranted slot in the middle doesn't stop the scroll dead.
    const vis = (typeof visibleTools === "function") ? visibleTools() : TOOLS.map((_,i)=>i);
    if (!vis.length) return;
    let cur = vis.indexOf(activeTool);
    if (cur < 0) cur = 0;                                  // empty hand -> start at first
    const next = (cur + (e.deltaY>0?1:-1) + vis.length) % vis.length;
    setTool(vis[next]);
  }
}, { passive:true });

addEventListener("keydown", e => {
  // chat capture takes priority (mouse stays locked; we just eat the keys)
  if (chatOpen){
    if (e.key === "Enter"){ runCommand(chatBuf); closeChat(); }
    else if (e.key === "Escape"){ closeChat(); }
    else if (e.key === "Backspace"){ chatBuf = chatBuf.slice(0,-1); renderChat(); }
    else if (e.key.length === 1){ chatBuf += e.key; renderChat(); }
    e.preventDefault(); return;
  }
  // tool menu open: Esc closes it, everything else is swallowed
  if (tmenuOpen){
    if (e.key === "Escape") closeToolMenu();
    e.preventDefault(); return;
  }
  // Wrench config overlay open: Esc closes, keys swallowed (typing in its fields is unaffected)
  if (typeof cfgOpen !== "undefined" && cfgOpen){
    if (e.key === "Escape") closeConfig();
    return;
  }
  // multiplayer menu open: same — Esc closes, keys swallowed (typing in its fields is unaffected)
  if (mpmenuOpen){
    if (e.key === "Escape") closeMpMenu();
    return;
  }
  if (!locked) return;
  if (e.key === "Enter"){ openChat(""); e.preventDefault(); return; }
  if (e.key === "/"){ openChat("/"); e.preventDefault(); return; }

  const k = e.key.toLowerCase();
  keys[k] = true;
  if (k === " " || k === "control") e.preventDefault();
  if (k >= "1" && k <= "9"){ // hotbar: number picks the Nth visible tool (Roblox-style), again to unequip
    const list = (typeof visibleTools === "function") ? visibleTools() : TOOLS.map((_,i)=>i);
    const ti = list[(+k) - 1];
    if (ti != null) setTool(activeTool === ti ? -1 : ti); }
  if (k === "q" && activeTool === 0){
    if (typeof toolRayMode !== "undefined" && toolRayMode === "paint") paintItemCycle();   // paint mode: cycle colour
    else { selectedProp = (selectedProp + 1) % TYPES.length; drawPalette(); }
  }
  if (k === "q" && activeTool === WIRING_TOOL) wireItemCycle();   // cycle the wiring quick-selection
  if (k === "c" && activeTool === WIRING_TOOL) wiringNewWire();   // start a fresh, disconnected wire
  if (k === "e" && activeTool === 0) spawnSelected();   // E always spawns, whatever mode is on
  if (k === "f" && activeTool === 0 && typeof toolRayMode !== "undefined" && toolRayMode === "lock"){ lockRayPrimary(); }
  if (k === "r" && typeof FLASHLIGHT_TOOL !== "undefined" && activeTool === FLASHLIGHT_TOOL){   // drop the flashlight
    if (typeof dropFlashlight === "function") dropFlashlight();
  } else if (k === "r" && activeTool === WIRING_TOOL){        // Wiring: R removes the wire node you're aiming at
    const n = aimedWireNode();
    if (n){ deleteNode(n); toast("Node removed"); }
  } else if (k === "r"){ const a = aimedProp();
    if (a){ if (netIsClient()){ if (canUseTools()) netClientCmd({ t:"cmd", cmd:"delete", netId:a.p.netId }); else toast("Tools are disabled by the host"); }
            else removeProp(a.p); } }
  if (k === "g"){ if (netIsClient()){ toast("Host controls gravity"); }
    else { gravityOn = !gravityOn; world.gravity.set(0, gravityOn?-20:0, 0); if(!gravityOn) for(const p of props) p.body.wakeUp(); toast("Gravity " + (gravityOn?"on":"off")); } }
  if (k === "x"){ if (netIsClient()) toast("Host controls that"); else clearAll(); }
  if (k === "m" && netIsHost()){ openMpMenu(false); }   // open the multiplayer menu (host)

});
addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);
addEventListener("blur", () => { for (const k in keys) keys[k] = false; releaseGrab(); });
