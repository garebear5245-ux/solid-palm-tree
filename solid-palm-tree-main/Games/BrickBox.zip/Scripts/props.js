"use strict";
/* props.js — spawnable props, freezing, and the cannonball detonation trigger. */
const TYPES = [
  { name:"Crate",   color:0x8a6b3d, roughness:0.85, mat:"wood",     cat:"props" },
  { name:"Ball",    color:0xdd5544, roughness:0.3, metalness:0.1, mat:"concrete", cat:"shapes" },
  { name:"Barrel",  color:0x4477aa, roughness:0.5, metalness:0.3, mat:"concrete", cat:"props" },
  { name:"Plank",   color:0xb08a55, roughness:0.9, mat:"wood",     cat:"props" },
  { name:"Cannonball", color:0x444a55, roughness:0.25, metalness:0.7, mat:"concrete", cat:"function" },
  { name:"Cube",    color:0x66bb6a, roughness:0.6, mat:"concrete", cat:"shapes" },
  { name:"Light",   color:0x333333, roughness:0.4, metalness:0.2, mat:"concrete", cat:"function" },
  { name:"Radio",   color:0x222222, roughness:0.5, metalness:0.3, mat:"concrete", cat:"function" },
];

const props = [], propMeshes = [], weldConstraints = [];
const zUp = new CANNON.Quaternion(); zUp.setFromAxisAngle(new CANNON.Vec3(1,0,0), Math.PI/2);
const CANNONBALL = 4, DETONATE_SPEED = 17;   // impact speed needed to blow up
const LIGHT = 6;                              // functional lamp, small block driven by wires
const RADIO = 7;                              // interactive music player with custom GLB model
let nextNetId = 1;                            // shared prop id used to sync over the network

// host/single-player adjustable cap on how many props may exist at once. Raising it
// too far will start to lag the physics + render loops; PART_LIMIT_MAX is a sane ceiling.
let PART_LIMIT = 140;
const PART_LIMIT_MIN = 140, PART_LIMIT_MAX = 600;
function setPartLimit(n){
  PART_LIMIT = Math.max(PART_LIMIT_MIN, Math.min(PART_LIMIT_MAX, Math.round(n)));
  while (props.length > PART_LIMIT) removeProp(props[0]);
}

// default colours + state applied to newly spawned Lights; edited in the ToolRay "Light" menu
const lightDefaults = { lightColor:0xffcc66, blockColor:0x333333, on:false };

/* ---- shared light pool -------------------------------------------------
   Every Light block glows via its emissive material (free — no scene light,
   no shader recompile). Real cast illumination comes from a small FIXED pool
   of point lights created once; each frame the pool follows the nearest lit
   blocks. Adding more Lights never changes the scene's light count, so there
   is no per-spawn shader recompile and no unbounded per-pixel cost. */
const LIGHT_POOL_MAX = 8;
let LIGHT_RANGE = 46;                 // how far a Light reaches (units); tunable in Settings
let LIGHT_INTENSITY = 14;            // brightness of a lit block's cast light
const lightEmitters = new Set();     // { mesh, color, on } — host props and client ghosts alike
let lightPool = null;
function applyLightRange(){ if (lightPool) for (const pl of lightPool){ pl.distance = LIGHT_RANGE; } }
function ensureLightPool(){
  if (lightPool) return;             // one-time cost: 6 lights added → a single recompile, then stable
  lightPool = [];
  for (let i = 0; i < LIGHT_POOL_MAX; i++){
    // longer range + physical-ish falloff so a Light actually illuminates a room
    const pl = new T.PointLight(0xffffff, 0, LIGHT_RANGE, 2);
    pl.castShadow = false;           // shadow-casting point lights are very expensive — skip
    scene.add(pl); lightPool.push(pl);
  }
}
function registerLight(e){ lightEmitters.add(e); }
function unregisterLight(e){ lightEmitters.delete(e); }
const _litScratch = [];
function updateLightPool(){
  if (!lightPool) return;            // no Lights spawned yet → nothing to do
  _litScratch.length = 0;
  for (const e of lightEmitters) if (e.on) _litScratch.push(e);
  const cp = camera.position;        // light the nearest blocks first
  _litScratch.sort((a,b) => a.mesh.position.distanceToSquared(cp) - b.mesh.position.distanceToSquared(cp));
  for (let i = 0; i < lightPool.length; i++){
    const pl = lightPool[i], e = _litScratch[i];
    if (e){ pl.position.copy(e.mesh.position); pl.color.setHex(e.color);
      pl.intensity = (e.intensity != null ? e.intensity : LIGHT_INTENSITY);
      pl.distance  = (e.range != null ? e.range : LIGHT_RANGE); }
    else pl.intensity = 0;
  }
}

// paint a Light's block to match its current lit state (glow is emissive; cast light comes from the pool)
function applyLightState(p){
  if (p.type !== LIGHT) return;
  const on = !!p.lit;
  p.mesh.material.color.setHex(p.blockColor);
  p.mesh.material.emissive.setHex(on ? p.lightColor : 0x000000);
  p.mesh.material.emissiveIntensity = on ? 0.95 : 0;
  if (p._emit){ p._emit.on = on; p._emit.color = p.lightColor; }
}

// geometry per prop type — shared by the host (spawnProp) and network clients (ghost meshes)
function propGeometry(ti){
  if (ti === 0) return new T.BoxGeometry(2,2,2);
  if (ti === 1) return new T.SphereGeometry(1.1,20,16);
  if (ti === 2) return new T.CylinderGeometry(1,1,2.4,20);
  if (ti === 3) return new T.BoxGeometry(6,0.4,1.2);
  if (ti === 4) return new T.SphereGeometry(0.9,20,16);
  if (ti === LIGHT) return new T.BoxGeometry(0.8,0.8,0.8);
  if (ti === RADIO) return new T.BoxGeometry(0.65,0.8,0.2);   // physics hitbox; GLB replaces visuals
  return new T.BoxGeometry(1.2,1.2,1.2);
}

const RADIO_LIMIT = 50;                       // hard cap on how many Radios may exist at once
function radioCount(){ let n = 0; for (const p of props) if (p.type === RADIO) n++; return n; }
function spawnProp(ti, pos, cfg){
  // cap Radios — too many playing at once is a performance + audio nightmare
  if (ti === RADIO && radioCount() >= RADIO_LIMIT){
    if (typeof toastWarn === "function") toastWarn("Too many Radios on map, delete some");
    return null;
  }
  const t = TYPES[ti];
  let shape, mass;
  const geo = propGeometry(ti);
  if (ti === 0)      { shape = new CANNON.Box(new CANNON.Vec3(1,1,1)); mass = 6; }
  else if (ti === 1) { shape = new CANNON.Sphere(1.1); mass = 3; }
  else if (ti === 2) { shape = new CANNON.Cylinder(1,1,2.4,16); mass = 8; }
  else if (ti === 3) { shape = new CANNON.Box(new CANNON.Vec3(3,0.2,0.6)); mass = 4; }
  else if (ti === 4) { shape = new CANNON.Sphere(0.9); mass = 26; }
  else if (ti === LIGHT){ shape = new CANNON.Box(new CANNON.Vec3(0.4,0.4,0.4)); mass = 2; }
  else if (ti === RADIO){ shape = new CANNON.Box(new CANNON.Vec3(0.325,0.4,0.1)); mass = 3; }
  else               { shape = new CANNON.Box(new CANNON.Vec3(0.6,0.6,0.6)); mass = 2; }

  const mesh = new T.Mesh(geo, new T.MeshStandardMaterial({ color:t.color, roughness:t.roughness, metalness:t.metalness||0 }));
  mesh.castShadow = mesh.receiveShadow = true;
  scene.add(mesh); propMeshes.push(mesh);

  const body = new CANNON.Body({ mass, material:propMat, position:new CANNON.Vec3(pos.x,pos.y,pos.z) });
  body.collisionFilterGroup = 1; body.collisionFilterMask = -1;   // collide with every group; welds only mask out their own assembly
  if (ti === 2) body.addShape(shape, new CANNON.Vec3(), zUp); else body.addShape(shape);
  body.linearDamping = 0.05; body.angularDamping = 0.08;
  world.addBody(body);

  const p = { mesh, body, origMass:mass, frozen:false, type:ti, footMat:t.mat, _dead:false, netId:nextNetId++,
              explodable:true, collides:true };   // wrench-configurable flags
  body._prop = p;
  mesh.userData.prop = p; props.push(p);

  // Small/light props (esp. the Radio) can micro-jitter on the ground because the
  // solver never quite settles them. Let them fall asleep quickly and damp harder so
  // a resting radio sits dead still instead of shivering.
  if (ti === RADIO || ti === LIGHT){
    body.allowSleep = true;
    body.sleepSpeedLimit = 0.6;    // treat very slow motion as "stopped"
    body.sleepTimeLimit = 0.4;     // and sleep after a short while
    body.linearDamping = 0.4; body.angularDamping = 0.6;
  }

  // a Light carries its own colours + on/off state and an attached point light
  if (ti === LIGHT){
    cfg = cfg || {};
    p.lightColor = cfg.lightColor != null ? cfg.lightColor : lightDefaults.lightColor;
    p.blockColor = cfg.blockColor != null ? cfg.blockColor : lightDefaults.blockColor;
    p.lightOn = cfg.on != null ? !!cfg.on : !!lightDefaults.on;   // manual on/off property
    p.lit = p.lightOn;                                            // final rendered state (also driven by wires)
    // per-light range + brightness (Configure ▸ light). null = follow the global
    // Settings slider; a set value overrides it just for this light.
    p.lightRange = cfg.range != null ? cfg.range : null;
    p.lightIntensity = cfg.intensity != null ? cfg.intensity : null;
    ensureLightPool();
    p._emit = { mesh, color:p.lightColor, on:p.lit, range:p.lightRange, intensity:p.lightIntensity };   // joins the shared light pool
    registerLight(p._emit);
    applyLightState(p);
    if (typeof netIsHost === "function" && netIsHost()) hostBroadcastLights();
  }

  // a Radio has interactive audio state and loads a GLB for its visual mesh
  if (ti === RADIO){
    p.radioOn = false; p.radioSong = 0; p._radioLastToggle = 0; p._radioAudio = null;
    p.mesh.material.transparent = true; p.mesh.material.opacity = 0; p.mesh.material.depthWrite = false;
    if (typeof loadGLB === "function"){
      const _radioUrl = (typeof RADIO_GLB_B64 !== "undefined")
        ? "data:application/octet-stream;base64," + RADIO_GLB_B64
        : "Assets/Models/Radio/Radio.glb";
      loadGLB(_radioUrl).then(glbGroup => {
        if (p._dead) return;
        const bb = new T.Box3().setFromObject(glbGroup);
        const sz = bb.getSize(new T.Vector3()), mx = Math.max(sz.x, sz.y, sz.z);
        if (mx > 0) glbGroup.scale.setScalar(0.8 / mx);
        const bb2 = new T.Box3().setFromObject(glbGroup);
        glbGroup.position.sub(bb2.getCenter(new T.Vector3()));
        p.mesh.add(glbGroup);
      }).catch(e => console.warn("Radio GLB:", e));
    }
    if (typeof netIsHost === "function" && netIsHost()) hostBroadcastRadios();
  }

  // a cannonball that strikes anything hard enough detonates
  if (ti === CANNONBALL){
    body.addEventListener("collide", e => {
      if (p._dead || !e.contact) return;
      const v = Math.abs(e.contact.getImpactVelocityAlongNormal());
      if (v > DETONATE_SPEED){ p._dead = true; queueExplosion(p); }   // deferred out of the physics step
    });
  }

  if (props.length > PART_LIMIT) removeProp(props[0]);
  return p;
}

/* ---- Radio audio helpers ---------------------------------------------- */
function _startRadioAudio(p){
  if (p._radioAudio){ try { p._radioAudio.pause(); } catch(e){} }
  p._radioAudio = new Audio("Assets/Sounds/Props/Radio/Song" + (p.radioSong + 1) + ".mp3");
  p._radioAudio.loop = true; p._radioAudio.volume = 0.6 * (typeof catGain === "function" ? catGain("music") : 1);
  p._radioAudio.play().catch(() => {});
}
function _stopRadioAudio(p){
  if (!p._radioAudio) return;
  try { p._radioAudio.pause(); p._radioAudio.src = ""; } catch(e){}
  p._radioAudio = null;
}
// skipCooldown=true bypasses the 0.5 s debounce (used from wiring and net commands)
function setRadioOn(p, on, skipCooldown){
  if (!p || p.type !== RADIO) return;
  const now = performance.now();
  if (!skipCooldown && now - p._radioLastToggle < 500) return;
  p._radioLastToggle = now;
  if (p.radioOn === !!on) return;
  p.radioOn = !!on;
  oneShot("Assets/Sounds/Props/Radio/Toggle.ogg", 0.75);
  if (p.radioOn) _startRadioAudio(p); else _stopRadioAudio(p);
  if (typeof netIsHost === "function" && netIsHost()) hostBroadcastRadios();
}
// right-click interaction: off→play, on→skip (restart, only 1 song currently)
function radioInteract(p){
  if (!p || p.type !== RADIO) return;
  const now = performance.now();
  if (now - p._radioLastToggle < 500) return;
  p._radioLastToggle = now;
  if (!p.radioOn){
    p.radioOn = true;
    oneShot("Assets/Sounds/Props/Radio/Toggle.ogg", 0.75);
    _startRadioAudio(p);
  } else {
    p.radioSong = (p.radioSong + 1) % Math.max(1, 1);   // wraps — extend when more songs added
    _stopRadioAudio(p);
    _startRadioAudio(p);
    oneShot("Assets/Sounds/Props/Radio/Toggle.ogg", 0.75);
  }
  if (typeof netIsHost === "function" && netIsHost()) hostBroadcastRadios();
}

/* ---- welding -----------------------------------------------------------
   Welds form a graph: each prop keeps p.weldLinks = [{other, c}] and every
   link is a LockConstraint. Bodies in one welded assembly are put on a shared
   collision group and masked so they DON'T collide with each other — that is
   what stops multi-welds from exploding — while still colliding with the world
   and other assemblies. On weld the second prop is snapped flush against the
   first so they physically touch instead of hanging apart. */
let _clearing = false;
// half-size of a prop's mesh on each local axis (from its geometry bounding box)
function propHalf(p){
  const g = p.mesh.geometry; if (!g.boundingBox) g.computeBoundingBox();
  const bb = g.boundingBox;
  return new T.Vector3((bb.max.x-bb.min.x)/2, (bb.max.y-bb.min.y)/2, (bb.max.z-bb.min.z)/2);
}

function weldProps(a, b, snap){
  if (!a || !b || a === b) return false;
  if (a.weldLinks && a.weldLinks.some(l => l.other === b)) return false;   // already welded
  if (a.frozen) setFrozen(a, false);
  if (b.frozen) setFrozen(b, false);

  // snap b flush against a along the line between them, matching a's orientation.
  // skipped (snap === false) when loading a saved map so exact positions are kept.
  if (snap !== false){
    const ap = a.body.position, bp = b.body.position;
    const q = new T.Quaternion(a.body.quaternion.x, a.body.quaternion.y, a.body.quaternion.z, a.body.quaternion.w);
    const local = new T.Vector3(bp.x-ap.x, bp.y-ap.y, bp.z-ap.z).applyQuaternion(q.clone().invert());
    if (local.lengthSq() < 1e-6) local.set(1, 0, 0);
    const axis = new T.Vector3();
    const ax = Math.abs(local.x), ay = Math.abs(local.y), az = Math.abs(local.z);
    if (ax >= ay && ax >= az)      axis.x = Math.sign(local.x) || 1;
    else if (ay >= az)             axis.y = Math.sign(local.y) || 1;
    else                           axis.z = Math.sign(local.z) || 1;
    const ha = propHalf(a), hb = propHalf(b);
    const proj = (h) => Math.abs(axis.x)*h.x + Math.abs(axis.y)*h.y + Math.abs(axis.z)*h.z;
    const gap = proj(ha) + proj(hb);
    const actualDist = local.length();
    // Skip snap if already close enough — prevents props going inside each other
    if (actualDist < gap + 0.4){
      // Already touching or nearly so: weld in place without moving anything
    } else {
      const worldDir = axis.clone().applyQuaternion(q);
      b.body.quaternion.copy(a.body.quaternion);
      b.body.position.set(ap.x + worldDir.x*gap, ap.y + worldDir.y*gap, ap.z + worldDir.z*gap);
    }
  }
  a.body.velocity.set(0,0,0); a.body.angularVelocity.set(0,0,0);
  b.body.velocity.set(0,0,0); b.body.angularVelocity.set(0,0,0);
  a.body.wakeUp(); b.body.wakeUp();

  const c = new CANNON.LockConstraint(a.body, b.body, { maxForce: 1e7 });
  c.collideConnected = false;
  world.addConstraint(c);
  (a.weldLinks || (a.weldLinks = [])).push({ other:b, c });
  (b.weldLinks || (b.weldLinks = [])).push({ other:a, c });
  weldConstraints.push({ c, a, b });
  recomputeWeldGroups();
  return true;
}

// assign each connected weld-assembly its own collision group; solo props reset to default
function recomputeWeldGroups(){
  for (const p of props){ p.body.collisionFilterGroup = 1; p.body.collisionFilterMask = -1; }
  const seen = new Set(); let comp = 0;
  for (const p of props){
    if (seen.has(p) || !(p.weldLinks && p.weldLinks.length)) continue;
    const stack = [p], group = []; seen.add(p);
    while (stack.length){
      const q = stack.pop(); group.push(q);
      for (const l of q.weldLinks) if (!seen.has(l.other)){ seen.add(l.other); stack.push(l.other); }
    }
    const bit = 1 << (2 + (comp++ % 20));
    for (const q of group){ q.body.collisionFilterGroup = bit; q.body.collisionFilterMask = (-1) & ~bit; }
  }
}

// remove a single weld link between a and b (no cascade). returns true if one existed
function severWeld(a, b){
  const l = a.weldLinks && a.weldLinks.find(x => x.other === b);
  if (!l) return false;
  world.removeConstraint(l.c);
  a.weldLinks = a.weldLinks.filter(x => x.other !== b);
  if (b.weldLinks) b.weldLinks = b.weldLinks.filter(x => x.other !== a);
  const i = weldConstraints.findIndex(w => w.c === l.c); if (i >= 0) weldConstraints.splice(i, 1);
  return true;
}

// break a weld and let the failure travel outward: each adjacent weld snaps 1s later
function breakWeld(a, b){
  if (!severWeld(a, b)) return;
  recomputeWeldGroups();
  cascadeBreak(a); cascadeBreak(b);
}
function cascadeBreak(node){
  if (!node.weldLinks) return;
  for (const l of [...node.weldLinks]){
    const other = l.other;
    setTimeout(() => {
      if (!node._dead && node.weldLinks && node.weldLinks.some(x => x.other === other)) breakWeld(node, other);
    }, 1000);
  }
}

function removeProp(p){
  // any wire nodes bound to this prop die with it — so a cannonball that
  // explodes (or any deleted prop) takes its attaching nodes with it
  if (typeof removeNodesForProp === "function") removeNodesForProp(p);
  if (p._radioAudio) _stopRadioAudio(p);
  if (p._emit) { unregisterLight(p._emit); p._emit = null; }
  // deleting a welded prop severs its links and cascades the failure through the assembly
  const neighbors = (p.weldLinks || []).map(l => l.other);
  for (const n of neighbors) severWeld(p, n);
  p.weldLinks = [];
  if (neighbors.length && !_clearing){ recomputeWeldGroups(); for (const n of neighbors) cascadeBreak(n); }

  scene.remove(p.mesh); world.removeBody(p.body);
  let i = props.indexOf(p); if (i>=0) props.splice(i,1);
  i = propMeshes.indexOf(p.mesh); if (i>=0) propMeshes.splice(i,1);
  if (held === p) releaseGrab();
  if (typeof weldFirst !== "undefined" && weldFirst === p) weldFirst = null;
}
function clearAll(){ _clearing = true; while (props.length) removeProp(props[props.length-1]); _clearing = false;
  if (typeof clearWiring === "function") clearWiring();
  if (typeof clearFlashDrops === "function") clearFlashDrops();
  toast("Cleared"); }

// wrench: toggle whether a prop physically collides with anything. collisionResponse=false
// turns it into a pass-through ghost while it still renders normally.
function applyPropCollision(p){
  p.body.collisionResponse = p.collides !== false;
  // mark the mesh so the player's raycasts skip it too (see collidableProps in player.js)
  p.mesh.userData.noCollide = p.collides === false;
}
// wrench: apply a batch of configurable flags (explodable / collides / locked)
function doConfigProp(p, m){
  if (!p) return;
  if (m.explodable != null) p.explodable = !!m.explodable;
  if (m.collides != null){ p.collides = !!m.collides; applyPropCollision(p); }
  if (m.lock != null) setFrozen(p, !!m.lock);
  if (typeof hostBroadcastPropCfg === "function") hostBroadcastPropCfg();
}

function setFrozen(p, f){
  p.frozen = f;
  if (f){
    p.body.type = CANNON.Body.STATIC; p.body.mass = 0;
    p.body.velocity.set(0,0,0); p.body.angularVelocity.set(0,0,0);
    p.body.updateMassProperties();
  } else {
    p.body.type = CANNON.Body.DYNAMIC; p.body.mass = p.origMass;
    p.body.updateMassProperties(); p.body.wakeUp();
    p.mesh.material.emissiveIntensity = 0;
  }
  if (p.type === LIGHT) applyLightState(p);   // a light's glow wins over the frozen tint
}
