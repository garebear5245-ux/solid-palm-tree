"use strict";
/* chat.js — the in-game chat line, slash commands, chat filter, and rate limiting. */
let chatOpen = false, chatBuf = "";

/* ---- Chat filter -------------------------------------------------------- */
// Normalized bad-word list. All entries are lowercase, no spaces.
const _BAD = ["fuck","shit","bitch","cunt","nigger","nigga","fag","faggot","asshole","bastard","whore","slut","dick","cock","pussy","piss","twat","wanker","retard","kike","spic","chink","gook","tranny"];

// Single-char leet substitutions
const _LEET = { '@':'a','4':'a','3':'e','!':'i','1':'i','|':'i','0':'o','6':'b','8':'b','9':'g','$':'s','5':'s','7':'t','+':'t','€':'e','(':'c','<':'c' };

function _normStr(s){
  return s.toLowerCase()
    .replace(/ph/g,'f')      // phuck → fuck
    .replace(/vv/g,'w')      // vvhore → whore
    // zero-width and invisible chars
    .replace(/[​-‏‪-‮﻿]/g,'')
    // single-char leet (1 = i, 3 = e, 4 = a, etc.)
    .replace(/[@4!|1068957$+€(<3]/g, c => _LEET[c] || c)
    // common Unicode homoglyphs (Cyrillic а, е, о, р, с, х etc.)
    .replace(/[аАа]/g,'a').replace(/[еЕ]/g,'e').replace(/[іІ]/g,'i').replace(/[оО]/g,'o').replace(/[рР]/g,'r').replace(/[сС]/g,'s').replace(/[уУ]/g,'u').replace(/[хХ]/g,'h')
    // collapse repeated chars ("fuuuck" → "fuck")
    .replace(/(.)\1+/g,'$1');
}

function _containsBad(cleaned){
  for (const w of _BAD) if (cleaned.includes(w)) return true;
  return false;
}

function filterMessage(text){
  // Normalize entire message
  const norm = _normStr(text);

  // Strategy 1: per-word — strip all non-alpha from each token (catches f.u.c.k, fu*k, etc.)
  const tokens = norm.split(/\s+/);
  for (const tok of tokens){
    if (_containsBad(tok.replace(/[^a-z]/g, ''))) return _censor(text);
  }

  // Strategy 2: strip ALL non-alpha from the full string (catches "f u c k" spaced across the msg)
  if (_containsBad(norm.replace(/[^a-z]/g, ''))) return _censor(text);

  // Strategy 3: run of consecutive single-character tokens → collapse and check
  // e.g. "f u c k you" → tokens ["f","u","c","k","you"] → run "fuck"
  let run = '', prevSingle = false;
  for (const tok of tokens){
    const letters = tok.replace(/[^a-z]/g,'');
    if (letters.length === 1){
      run += letters;
      prevSingle = true;
    } else {
      if (prevSingle && run.length >= 3 && _containsBad(run)){ return _censor(text); }
      run = ''; prevSingle = false;
    }
  }
  if (prevSingle && run.length >= 3 && _containsBad(run)) return _censor(text);

  return text;   // clean
}

function _censor(text){
  // Replace every non-space character with '#'
  return text.replace(/[^\s]/g, '#');
}

/* ---- Rate limiting (1 message per second) ------------------------------- */
let _lastChatSent = 0;
const CHAT_COOLDOWN = 1000;

function _sendChatNow(text){
  text = filterMessage(text);
  if (netRole !== "single") netSendChat(text);
  else logLine("You: " + text);
}

function enqueueChatSend(text){
  const now = Date.now();
  const wait = Math.max(0, CHAT_COOLDOWN - (now - _lastChatSent));
  _lastChatSent = Math.max(_lastChatSent, now) + CHAT_COOLDOWN;
  if (wait === 0) _sendChatNow(text);
  else setTimeout(() => _sendChatNow(text), wait);
}
const chatEl = document.getElementById("chat");
const chatlog = document.getElementById("chatlog"), chatline = document.getElementById("chatline");
const CHAT_MAX = 50;   // keep the last 50 lines of history

// While chat is open the whole history stays visible; otherwise lines fade after a few seconds.
function armFade(d){
  clearTimeout(d._fade);
  if (chatOpen){ d.style.transition = ""; d.style.opacity = "0.95"; return; }
  d.style.transition = ""; d.style.opacity = "0.95";
  d._fade = setTimeout(() => { d.style.transition = "opacity 1s"; d.style.opacity = "0"; }, 6000);
}
function logHostLeft(newHostName){
  const d = document.createElement("div");
  d.style.cssText = "color:#ff4040;font-size:1.4em;font-weight:bold;text-align:center;padding:8px 0 5px;line-height:1.3;text-shadow:0 0 14px rgba(255,60,60,.55)";
  d.textContent = "Host left — " + newHostName + " is now host.";
  chatlog.appendChild(d);
  while (chatlog.children.length > CHAT_MAX){ const g = chatlog.firstChild; clearTimeout(g._fade); chatlog.removeChild(g); }
  armFade(d);
  chatlog.scrollTop = chatlog.scrollHeight;
}
function logChatMessage(name, text, playerId){
  logLine(name + ": " + text);
  oneShot(S+"Player/ChatNotification.ogg", 0.65);
  if (playerId != null && typeof showChatBubble === "function") showChatBubble(playerId, text);
}
function _scrollToBottom(){
  // scrollIntoView is reliable even when scrollHeight hasn't updated yet
  const last = chatlog.lastElementChild;
  if (last) last.scrollIntoView({ block:"end", behavior:"instant" });
}
function logLine(text, sys){
  const d = document.createElement("div"); if (sys) d.className = "sys"; d.textContent = text;
  chatlog.appendChild(d);
  while (chatlog.children.length > CHAT_MAX){ const g = chatlog.firstChild; clearTimeout(g._fade); chatlog.removeChild(g); }
  armFade(d);
  _scrollToBottom();
}
function openChat(prefill){
  chatOpen = true; chatBuf = prefill || ""; chatline.style.display = "block";
  chatEl.classList.add("open");                                   // reveal the full history + scroll
  for (const d of chatlog.children){ clearTimeout(d._fade); d.style.transition = ""; d.style.opacity = "0.95"; }
  _scrollToBottom();
  renderChat();
}
function closeChat(){
  chatOpen = false; chatline.style.display = "none";
  chatEl.classList.remove("open");
  for (const d of chatlog.children) armFade(d);                   // let history fade back out
}
function renderChat(){ chatline.innerHTML = "&gt; " + chatBuf.replace(/&/g,"&amp;").replace(/</g,"&lt;") + '<span class="cur">▏</span>'; }
function runCommand(raw){
  const line = raw.trim(); if (!line) return;
  // anything not prefixed with "/" is just ordinary chat, not a command
  if (line[0] !== "/"){
    enqueueChatSend(line);
    return;
  }
  logLine(line);
  const parts = line.slice(1).toLowerCase().split(/\s+/);
  const cmd = parts[0], arg = parts[1];
  if (cmd === "fly"){
    if (!canFly()){ logLine("Flying is disabled by the host.", true); return; }
    flyMode = arg === "on" ? true : arg === "off" ? false : !flyMode;
    velY = 0;
    logLine("Fly mode " + (flyMode ? "ON" : "OFF"), true);
  } else if (cmd === "gravity"){
    gravityOn = arg === "on" ? true : arg === "off" ? false : !gravityOn;
    world.gravity.set(0, gravityOn ? -20 : 0, 0);
    if (!gravityOn) for (const p of props) p.body.wakeUp();
    logLine("World gravity " + (gravityOn ? "ON" : "OFF"), true);
  } else if (cmd === "clear"){ clearAll(); logLine("Cleared all props", true); }
  else if (cmd === "mp" || cmd === "multiplayer"){
    // open the BrickBox multiplayer menu; jump straight to a section if asked
    openMpMenu(netRole === "single");
    if (arg === "host" || arg === "join" || arg === "settings"){ mpSection = arg; renderMpMenu(); }
    logLine("Opening BrickBox multiplayer…", true);
  } else if (cmd === "host"){
    openMpMenu(netRole === "single"); mpSection = "host"; renderMpMenu();
    logLine("Host a BrickBox game — share your answer code.", true);
  } else if (cmd === "join"){
    openMpMenu(netRole === "single"); mpSection = "join"; renderMpMenu();
    logLine("Join a BrickBox game — send your invite code to the host.", true);
  }
  else if (cmd === "help"){ logLine("Commands: /fly [on|off], /gravity [on|off], /clear, /mp [host|join], /host, /join — type without / to chat", true); }
  else logLine('Unknown command "' + cmd + '" — try /help', true);
}
