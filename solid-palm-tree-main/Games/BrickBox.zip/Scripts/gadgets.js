"use strict";
/* gadgets.js — three ToolRay MODES (not separate tools), toggled like Welding:
     Paint     — click a prop to recolour it
     Configure — click a prop to edit its properties (Lights for now)
     Resize    — Roblox-style translucent handles you drag to resize a prop
   The mode lives on the ToolRay: while a mode is on, ToolRay left-click does that
   mode's action instead of spawning. Prop mutations are host-authoritative;
   clients send a command and the host applies + broadcasts the result. */

let toolRayMode = "spawn";   // "spawn" | "paint" | "configure" | "resize" | "move" | "lock"
const TOOLRAY_MODES = [
  { id:"paint",     name:"Paint mode",     desc:"recolour" },
  { id:"configure", name:"Configure mode", desc:"edit props" },
  { id:"resize",    name:"Resize mode",    desc:"drag handles" },
  { id:"move",      name:"Move mode",      desc:"move & rotate" },
  { id:"lock",      name:"Lock mode",      desc:"lock & unlock" },
  { id:"clone",     name:"Clone mode",     desc:"copy a prop" },
];
function setToolRayMode(id){
  if (toolRayMode === id) id = "spawn";                        // click the active mode again to turn it off
  if (id !== "spawn" && netIsClient() && typeof modeAllowedClient === "function" && !modeAllowedClient(id)){
    toast("The host restricted " + id + " mode"); return;
  }
  clearMoveRay();
  toolRayMode = id;
  clearResizeHandles();
  if (typeof drawTools === "function") drawTools();
  if (typeof drawPalette === "function") drawPalette();
}

/* ---- Time of day (ToolRay › Time) ------------------------------------
   Presets retint the sun, sky and fog. Host-authoritative: the host (or a
   single player) sets it and it streams to every client. */
const TIME_PRESETS = [
  { id:"sunrise",  name:"Sunrise",  sky:0xffb98a, fog:0xffc9a0, sun:0xffd0a0, si:1.6, pos:[60,14,10],  hemiSky:0xffd9b3, hemiGr:0x4a3b45, hi:0.8, amb:0.18 },
  { id:"morning",  name:"Morning",  sky:0x9fd0f0, fog:0xbfe0f5, sun:0xfff2d8, si:2.0, pos:[40,40,20],  hemiSky:0xcfe6ff, hemiGr:0x3a4560, hi:1.0, amb:0.15 },
  { id:"noon",     name:"Noon",     sky:0x8fb8e8, fog:0x8fb8e8, sun:0xffffff, si:2.4, pos:[10,60,8],   hemiSky:0xdfefff, hemiGr:0x40506a, hi:1.1, amb:0.18 },
  { id:"sunset",   name:"Sunset",   sky:0xff8a5c, fog:0xff9c6e, sun:0xff9a5a, si:1.7, pos:[-60,12,-8], hemiSky:0xffb98a, hemiGr:0x3a2f45, hi:0.75, amb:0.16 },
  { id:"night",    name:"Night",    sky:0x1a2740, fog:0x1a2740, sun:0x6f86c4, si:0.5, pos:[-30,40,-20],hemiSky:0x33446a, hemiGr:0x10151f, hi:0.45, amb:0.1 },
  { id:"midnight", name:"Midnight", sky:0x0a0f1c, fog:0x0a0f1c, sun:0x4152a0, si:0.28,pos:[-10,55,-10],hemiSky:0x22304d, hemiGr:0x080b12, hi:0.35, amb:0.08 },
];
let currentTime = "noon";
function applyTimeOfDay(id){
  const t = TIME_PRESETS.find(p => p.id === id) || TIME_PRESETS[2];
  currentTime = t.id;
  scene.background.setHex(t.sky);
  scene.fog.color.setHex(t.fog);
  sun.position.set(t.pos[0], t.pos[1], t.pos[2]);
  sun.color.setHex(t.sun); sun.intensity = t.si;
  if (typeof hemi !== "undefined"){ hemi.color.setHex(t.hemiSky); hemi.groundColor.setHex(t.hemiGr); hemi.intensity = t.hi; }
  if (typeof ambient !== "undefined") ambient.intensity = t.amb;
}
function setTimeOfDay(id, broadcast){
  if (netIsClient()){ netClientCmd({ t:"cmd", cmd:"time", id }); return; }  // ask host (host re-broadcasts)
  applyTimeOfDay(id);
  if (broadcast !== false && typeof hostBroadcastTime === "function") hostBroadcastTime();
  if (typeof saveSettings === "function") saveSettings();
}

/* ---- Paint ------------------------------------------------------------ */
const PAINT_COLORS = [0xff5b5b,0xffa53f,0xffe23f,0x51e07a,0x38e0ff,0x4a8cff,0xc06cff,0xffffff,0x222222,0x8a6b3d];
let paintIndex = 0;
function paintColorHex(){ return PAINT_COLORS[paintIndex]; }
function paintItemCycle(){ paintIndex = (paintIndex + 1) % PAINT_COLORS.length; if (typeof drawPalette === "function") drawPalette(); }
function paintPrimary(){
  const a = aimedProp(); if (!a){ toast("Aim at an object to paint it"); return; }
  const col = paintColorHex();
  if (netIsClient()){
    if (!canUseTools()){ toast("Tools are disabled by the host"); return; }
    netClientCmd({ t:"cmd", cmd:"paint", netId:a.p.netId, color:col });
  } else doPaint(a.p, col);
  oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.5);
}
function doPaint(p, color){
  if (p.type === LIGHT){ p.blockColor = color; applyLightState(p); if (typeof hostBroadcastLights === "function") hostBroadcastLights(); return; }
  p.paintColor = color; p.mesh.material.color.setHex(color);
  if (typeof hostBroadcastPaints === "function") hostBroadcastPaints();
}

/* ---- Configure (Wrench-style) ---------------------------------------- */
function wrenchPrimary(){
  const a = aimedProp(); if (!a){ toast("Aim at an object to configure it"); return; }
  openConfig(a.p);
}
// generic wrench flags — read the live value for a prop (host prop or client ghost)
function propCfgValues(p){
  if (!netIsClient()) return { explodable:p.explodable !== false, collides:p.collides !== false, lock:!!p.frozen };
  const c = (typeof clientPropCfg !== "undefined") && clientPropCfg.get(p.netId);
  return { explodable:c ? c.explodable !== false : true, collides:c ? c.collides !== false : true, lock:c ? !!c.lock : false };
}
function cfgPushProp(p, patch){
  if (netIsClient()) netClientCmd(Object.assign({ t:"cmd", cmd:"configProp", netId:p.netId }, patch));
  else doConfigProp(p, patch);
}
function doConfigLight(p, m){
  if (p.type !== LIGHT) return;
  if (m.lightColor != null) p.lightColor = m.lightColor;
  if (m.blockColor != null) p.blockColor = m.blockColor;
  if (m.on != null) p.lightOn = !!m.on;
  if (m.range != null){ p.lightRange = m.range; if (p._emit) p._emit.range = m.range; }
  if (m.intensity != null){ p.lightIntensity = m.intensity; if (p._emit) p._emit.intensity = m.intensity; }
  applyLightState(p);
  if (typeof hostBroadcastLights === "function") hostBroadcastLights();
}

let cfgOpen = false, cfgTarget = null;
const cfgWrap = document.getElementById("cfg");
const cfgBody = document.getElementById("cfgbody");
function cfgHex(n){ return "#" + (n>>>0 & 0xffffff).toString(16).padStart(6,"0"); }
function lightValues(p){
  if (!netIsClient()) return { lightColor:p.lightColor, blockColor:p.blockColor, on:!!p.lightOn, range:p.lightRange, intensity:p.lightIntensity };
  const c = (typeof clientLightCfg !== "undefined") && clientLightCfg.get(p.netId);
  return { lightColor:(c?c.lc:lightDefaults.lightColor), blockColor:(c?c.bc:lightDefaults.blockColor), on:false,
           range:(c?c.rng:null), intensity:(c?c.int:null) };
}
function cfgPush(p, patch){
  if (netIsClient()) netClientCmd(Object.assign({ t:"cmd", cmd:"config", netId:p.netId }, patch));
  else doConfigLight(p, patch);
}
function openConfig(p){
  cfgTarget = p; cfgOpen = true;
  cfgBody.innerHTML = "";
  const mkToggle = (label, on, onToggle) => {
    const row = document.createElement("div"); row.className = "cfgrow";
    row.innerHTML = `<span>${label}</span>`;
    const sw = document.createElement("div"); sw.className = "tsw" + (on ? " on" : "");
    uiBtn(sw, () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onToggle(now); });
    row.appendChild(sw); cfgBody.appendChild(row);
  };
  const mkSlider = (label, min, max, step, val, onInput) => {
    const row = document.createElement("div"); row.className = "cfgrow";
    row.innerHTML = `<span>${label}</span>`;
    const input = document.createElement("input"); input.type = "range";
    input.min = min; input.max = max; input.step = step; input.value = val;
    input.style.cssText = "flex:1;margin-left:10px";
    const valEl = document.createElement("span"); valEl.textContent = Math.round(val); valEl.style.cssText = "min-width:32px;text-align:right;opacity:.8";
    input.addEventListener("input", () => { const v = parseFloat(input.value); valEl.textContent = Math.round(v); onInput(v); });
    row.appendChild(input); row.appendChild(valEl); cfgBody.appendChild(row);
  };

  // Light-specific colour + on rows
  if (p.type === LIGHT){
    const v = lightValues(p);
    const mkColor = (label, key, cur) => {
      const row = document.createElement("div"); row.className = "cfgrow";
      row.innerHTML = `<span>${label}</span>`;
      const inp = document.createElement("input"); inp.type = "color"; inp.value = cfgHex(cur);
      inp.addEventListener("input", () => cfgPush(p, { [key]: parseInt(inp.value.slice(1), 16) }));
      row.appendChild(inp); cfgBody.appendChild(row);
    };
    mkColor("Light colour", "lightColor", v.lightColor);
    mkColor("Block colour", "blockColor", v.blockColor);
    mkToggle("On", v.on, now => cfgPush(p, { on:now }));
    const curRange = v.range != null ? v.range : (typeof LIGHT_RANGE !== "undefined" ? LIGHT_RANGE : 46);
    const curInt   = v.intensity != null ? v.intensity : (typeof LIGHT_INTENSITY !== "undefined" ? LIGHT_INTENSITY : 14);
    mkSlider("Range", 8, 120, 2, curRange, val => cfgPush(p, { range:val }));
    mkSlider("Brightness", 2, 40, 1, curInt, val => cfgPush(p, { intensity:val }));
  }

  // Generic wrench flags for every prop
  const g = propCfgValues(p);
  const sep = document.createElement("div"); sep.style.cssText = "height:1px;background:rgba(255,255,255,.1);margin:8px 0";
  if (p.type === LIGHT) cfgBody.appendChild(sep);
  mkToggle("Affected by explosives", g.explodable, now => cfgPushProp(p, { explodable:now }));
  mkToggle("Collision", g.collides, now => cfgPushProp(p, { collides:now }));
  mkToggle("Locked", g.lock, now => cfgPushProp(p, { lock:now }));

  cfgWrap.classList.add("open");
  if (locked) document.exitPointerLock();
}
function closeConfig(){
  if (!cfgOpen) return;
  cfgOpen = false; cfgTarget = null;
  cfgWrap.classList.remove("open");
  if (typeof uiClose === "function") uiClose();
  renderer.domElement.requestPointerLock();
}
uiBtn(document.getElementById("cfgclose"), closeConfig);

/* ---- Resize (draggable handles, Roblox-style) ------------------------ */
const RESIZE_MIN = 0.3, RESIZE_MAX = 4;
// unscaled local half-extents per prop type (mirrors spawnProp's shapes)
const BASE_HALF = { 0:[1,1,1], 1:[1.1,1.1,1.1], 2:[1,1.2,1], 3:[3,0.2,0.6], 4:[0.9,0.9,0.9], 5:[0.6,0.6,0.6] };
BASE_HALF[LIGHT] = [0.4,0.4,0.4];
// the live mesh + scale for a resize target — a host prop, or a client's ghost prop
function rzMesh(p){
  if (p && p._client){ const cp = (typeof clientProps !== "undefined") && clientProps.get(p.netId); return cp ? cp.mesh : null; }
  return p ? p.mesh : null;
}
function rzScale(p){
  if (p && p._client){ const m = rzMesh(p); return m ? { x:m.scale.x, y:m.scale.y, z:m.scale.z } : { x:1, y:1, z:1 }; }
  return { x:p.sx||1, y:p.sy||1, z:p.sz||1 };
}
function rzValid(p){
  if (!p) return false;
  if (p._client) return (typeof clientProps !== "undefined") && clientProps.has(p.netId);
  return props.indexOf(p) >= 0;
}
function propHalfLocal(p){
  const b = BASE_HALF[p.type] || [0.6,0.6,0.6];
  const s = rzScale(p);
  return { x:b[0]*s.x, y:b[1]*s.y, z:b[2]*s.z };
}
// rebuild the Cannon shape + mesh scale for the prop's current per-axis scale
function bodyShapeFor(p){
  const sx = p.sx||1, sy = p.sy||1, sz = p.sz||1, ti = p.type;
  if (ti === 1) return { shape:new CANNON.Sphere(1.1*(sx+sy+sz)/3) };
  if (ti === 4) return { shape:new CANNON.Sphere(0.9*(sx+sy+sz)/3) };
  if (ti === 2) return { shape:new CANNON.Cylinder(1*(sx+sz)/2, 1*(sx+sz)/2, 2.4*sy, 16), cyl:true };
  if (ti === 0) return { shape:new CANNON.Box(new CANNON.Vec3(1*sx, 1*sy, 1*sz)) };
  if (ti === 3) return { shape:new CANNON.Box(new CANNON.Vec3(3*sx, 0.2*sy, 0.6*sz)) };
  if (ti === LIGHT) return { shape:new CANNON.Box(new CANNON.Vec3(0.4*sx, 0.4*sy, 0.4*sz)) };
  return { shape:new CANNON.Box(new CANNON.Vec3(0.6*sx, 0.6*sy, 0.6*sz)) };
}
function applyPropScale(p){
  const sx = p.sx||1, sy = p.sy||1, sz = p.sz||1;
  p.mesh.scale.set(sx, sy, sz);
  const b = p.body, bs = bodyShapeFor(p);
  b.shapes.length = 0; b.shapeOffsets.length = 0; b.shapeOrientations.length = 0;
  if (bs.cyl) b.addShape(bs.shape, new CANNON.Vec3(), zUp); else b.addShape(bs.shape);
  if (!p.frozen) b.mass = p.origMass * sx*sy*sz;
  b.updateMassProperties(); b.updateBoundingRadius(); b.aabbNeedsUpdate = true; b.wakeUp();
}
// uniform resize (network cmd + map load), keeps the per-axis system consistent
function doResize(p, factor){
  p.sx = Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, (p.sx||1)*factor));
  p.sy = Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, (p.sy||1)*factor));
  p.sz = Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, (p.sz||1)*factor));
  applyPropScale(p);
  if (typeof hostBroadcastSizes === "function") hostBroadcastSizes();
}
// shift a prop's centre so a one-sided resize keeps the OPPOSITE face fixed:
// move the body by the change in half-extent along the dragged local axis.
function anchorResizeFace(p, axisIdx, sign, beforeScale, afterScale){
  const bh = (BASE_HALF[p.type] || [0.6,0.6,0.6])[axisIdx];
  const deltaHalf = bh * (afterScale - beforeScale);
  if (!deltaHalf) return;
  const av = new T.Vector3(axisIdx===0?1:0, axisIdx===1?1:0, axisIdx===2?1:0)
    .applyQuaternion(p.mesh.quaternion).multiplyScalar(sign * deltaHalf);
  p.body.position.x += av.x; p.body.position.y += av.y; p.body.position.z += av.z;
  p.mesh.position.copy(p.body.position);
}
// absolute per-axis resize — host applies a client's handle-drag result. `face`
// (optional [axisIdx, sign]) anchors the opposite face so only the dragged side grows.
function doResizeAxis(p, s, face){
  const cl = v => Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, v || 1));
  const ns = [cl(s[0]), cl(s[1]), cl(s[2])];
  if (face){
    const axisIdx = face[0], sign = face[1];
    const before = [p.sx||1, p.sy||1, p.sz||1][axisIdx];
    p.sx = ns[0]; p.sy = ns[1]; p.sz = ns[2]; applyPropScale(p);
    anchorResizeFace(p, axisIdx, sign, before, ns[axisIdx]);
  } else {
    p.sx = ns[0]; p.sy = ns[1]; p.sz = ns[2]; applyPropScale(p);
  }
  if (typeof hostBroadcastSizes === "function") hostBroadcastSizes();
}

// six translucent handles, one per face — LOCAL to this client (never synced/drawn to others)
const resizeHandles = [], resizeHandleMeshes = [];
let resizeTarget = null, resizeDrag = null;   // resizeDrag = { p, axis, sign }
function ensureHandles(){
  if (resizeHandles.length) return;
  for (let i = 0; i < 6; i++){
    const m = new T.Mesh(new T.SphereGeometry(0.32,14,10),
      new T.MeshBasicMaterial({ color:0x7cf6c9, transparent:true, opacity:0.45, depthTest:false }));
    m.renderOrder = 1001; m.visible = false; m.userData.handleIdx = i;
    scene.add(m); resizeHandles.push(m); resizeHandleMeshes.push(m);
  }
}
function hideHandles(){ for (const m of resizeHandles) m.visible = false; if (!resizeDrag) resizeTarget = null; }
function clearResizeHandles(){ resizeDrag = null; hideHandles(); resizeTarget = null; }
// called every frame from the main loop
function updateResizeHandles(){
  if (activeTool !== 0 || toolRayMode !== "resize"){ hideHandles(); return; }
  if (netIsClient() && typeof canUseTools === "function" && !canUseTools()){ hideHandles(); return; }
  ensureHandles();
  let p = resizeDrag ? resizeDrag.p : (aimedProp() ? aimedProp().p : null);
  const mesh = rzMesh(p);
  if (!p || !mesh || !rzValid(p)){ hideHandles(); return; }
  resizeTarget = p;
  const h = propHalfLocal(p), q = mesh.quaternion, c = mesh.position;
  const dirs = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  for (let i = 0; i < 6; i++){
    const d = dirs[i];
    const off = new T.Vector3(d[0]*h.x, d[1]*h.y, d[2]*h.z).applyQuaternion(q);
    resizeHandles[i].position.copy(c).add(off);
    resizeHandles[i].visible = true;
    resizeHandles[i].material.opacity = (resizeDrag && resizeDrag.handleIdx === i) ? 0.9 : 0.45;
  }
}
// begin dragging a handle the crosshair is over
function startResizeDrag(){
  if (netIsClient() && typeof canUseTools === "function" && !canUseTools()){ toast("Tools are disabled by the host"); return; }
  if (!resizeHandleMeshes.length || !resizeTarget){ toast("Aim at a prop, then grab a handle"); return; }
  raycaster.setFromCamera(CENTER, camera);
  const hits = raycaster.intersectObjects(resizeHandleMeshes.filter(m => m.visible), false);
  if (!hits.length){ toast("Aim at one of the resize handles"); return; }
  const idx = hits[0].object.userData.handleIdx;
  resizeDrag = { p:resizeTarget, axis:(idx >> 1), sign:(idx % 2 === 0 ? 1 : -1), handleIdx:idx };
}
function resizeDragMove(dy){
  if (!resizeDrag) return;
  const p = resizeDrag.p;
  // client: scale the local ghost for instant feedback, stream the result to the host
  if (p._client){
    const mesh = rzMesh(p); if (!mesh){ resizeDrag = null; return; }
    const ax = resizeDrag.axis === 0 ? "x" : resizeDrag.axis === 1 ? "y" : "z";
    const cur = mesh.scale[ax] || 1;
    const next = Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, cur * (1 + (-dy) * 0.006)));
    if (next === cur) return;
    mesh.scale[ax] = next;
    const now = performance.now();
    if (now - (resizeDrag._lastSend || 0) > 60){    // throttle the wire
      resizeDrag._lastSend = now;
      netClientCmd({ t:"cmd", cmd:"resizeAxis", netId:p.netId, s:[mesh.scale.x, mesh.scale.y, mesh.scale.z], face:[resizeDrag.axis, resizeDrag.sign] });
    }
    return;
  }
  const key = resizeDrag.axis === 0 ? "sx" : resizeDrag.axis === 1 ? "sy" : "sz";
  const cur = p[key] || 1;
  const next = Math.max(RESIZE_MIN, Math.min(RESIZE_MAX, cur * (1 + (-dy) * 0.006)));   // mouse up grows
  if (next === cur) return;
  p[key] = next; applyPropScale(p);
  anchorResizeFace(p, resizeDrag.axis, resizeDrag.sign, cur, next);   // grow only the dragged face
}
function endResizeDrag(){
  if (!resizeDrag) return;
  const p = resizeDrag.p;
  if (p._client){
    const mesh = rzMesh(p);
    if (mesh) netClientCmd({ t:"cmd", cmd:"resizeAxis", netId:p.netId, s:[mesh.scale.x, mesh.scale.y, mesh.scale.z], face:[resizeDrag.axis, resizeDrag.sign] });
  } else if (typeof hostBroadcastSizes === "function") hostBroadcastSizes();
  resizeDrag = null;
}
function resizeDragging(){ return !!resizeDrag; }

// hotbar refresh (in case a mode badge needs drawing)
if (typeof drawTools === "function") drawTools();

/* ---- MoveRay (Roblox Studio-style axis arrow gizmo) ------------------- */
// Six arrows appear on the faces of the aimed prop (X=red, Y=green, Z=blue).
// Press+hold an arrow to drag the prop along that world axis; release to drop.
// Right-click rotates the prop 45° on the world Y axis.
const _MOVE_AXIS_COLORS = [0xff3333, 0xff3333, 0x33cc33, 0x33cc33, 0x4488ff, 0x4488ff];
const _MOVE_DIRS = [
  new T.Vector3(1,0,0), new T.Vector3(-1,0,0),
  new T.Vector3(0,1,0), new T.Vector3(0,-1,0),
  new T.Vector3(0,0,1), new T.Vector3(0,0,-1),
];
const _moveArrows = [];       // 6 T.Group (shaft + cone tip) in scene
const _moveArrowMeshes = [];  // 12 T.Mesh for raycasting
let moveTarget = null;        // prop (host) | { netId, _client:true } (client) | null
let _moveSelected = false;    // true = prop was clicked; arrows persist even when looking away
let _moveDrag = null;         // { arrowIdx, dir } while mouse held on arrow
let _moveOrigFrozen = false;
let _moveLastSend = 0;

function _buildMoveArrows(){
  if (_moveArrows.length) return;
  const shGeo = new T.CylinderGeometry(0.055, 0.055, 1.2, 8);
  const tiGeo = new T.ConeGeometry(0.14, 0.42, 8);
  for (let i = 0; i < 6; i++){
    const col = _MOVE_AXIS_COLORS[i];
    const sm = new T.MeshBasicMaterial({ color:col, depthTest:false, transparent:true, opacity:0.88 });
    const tm = new T.MeshBasicMaterial({ color:col, depthTest:false, transparent:true, opacity:0.88 });
    const shaft = new T.Mesh(shGeo, sm); shaft.position.y = 0.6; shaft.userData.arrowIdx = i;
    const tip   = new T.Mesh(tiGeo, tm); tip.position.y   = 1.41; tip.userData.arrowIdx = i;
    const grp = new T.Group(); grp.renderOrder = 1002; grp.visible = false;
    grp.add(shaft); grp.add(tip); scene.add(grp);
    _moveArrows.push(grp);
    _moveArrowMeshes.push(shaft, tip);
  }
}
function _hideMoveArrows(){ for (const g of _moveArrows) g.visible = false; }

function _getMoveMesh(){
  if (!moveTarget) return null;
  if (moveTarget._client){
    const cp = (typeof clientProps !== "undefined") && clientProps.get(moveTarget.netId);
    return cp ? cp.mesh : null;
  }
  return moveTarget.mesh;
}

function _placeArrows(){
  const mesh = _getMoveMesh(); if (!mesh){ _hideMoveArrows(); return; }
  _buildMoveArrows();
  if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
  const bb = mesh.geometry.boundingBox;
  const hs = new T.Vector3(
    (bb.max.x - bb.min.x) / 2 * mesh.scale.x,
    (bb.max.y - bb.min.y) / 2 * mesh.scale.y,
    (bb.max.z - bb.min.z) / 2 * mesh.scale.z
  );
  const q = mesh.quaternion, c = mesh.position, qi = q.clone().invert();
  for (let i = 0; i < 6; i++){
    const wDir = _MOVE_DIRS[i];
    const lDir = wDir.clone().applyQuaternion(qi);
    const extent = Math.abs(lDir.x)*hs.x + Math.abs(lDir.y)*hs.y + Math.abs(lDir.z)*hs.z;
    _moveArrows[i].position.copy(c).addScaledVector(wDir, extent + 0.15);
    _moveArrows[i].quaternion.setFromUnitVectors(new T.Vector3(0,1,0), wDir);
    _moveArrows[i].visible = true;
    const hi = _moveDrag && _moveDrag.arrowIdx === i;
    for (const child of _moveArrows[i].children) child.material.opacity = hi ? 1.0 : 0.88;
  }
}

function _setMoveTarget(p){
  _moveOrigFrozen = p.frozen;
  moveTarget = netIsClient() ? { netId:p.netId, _client:true } : p;
}

function _startMoveDrag(idx){
  if (_moveDrag) _endMoveDrag();
  if (moveTarget._client){
    netClientCmd({ t:"cmd", cmd:"moveStart", netId:moveTarget.netId });
  } else {
    if (moveTarget.frozen) setFrozen(moveTarget, false);
    moveTarget.body.type = CANNON.Body.STATIC;
    moveTarget.body.velocity.set(0,0,0); moveTarget.body.angularVelocity.set(0,0,0);
  }
  _moveDrag = { arrowIdx:idx, dir:_MOVE_DIRS[idx].clone() };
  _moveLastSend = 0;
  oneShot(S+"Tools/GravityRay/Open.ogg", 0.5);
}

function _endMoveDrag(){
  if (!_moveDrag) return;
  if (moveTarget){
    if (moveTarget._client){
      const cp = (typeof clientProps !== "undefined") && clientProps.get(moveTarget.netId);
      const pos = cp ? cp.mesh.position : { x:0,y:0,z:0 };
      const qr  = cp ? cp.mesh.quaternion : { x:0,y:0,z:0,w:1 };
      netClientCmd({ t:"cmd", cmd:"moveEnd", netId:moveTarget.netId, frozen:_moveOrigFrozen,
        x:pos.x, y:pos.y, z:pos.z, qx:qr.x, qy:qr.y, qz:qr.z, qw:qr.w });
    } else {
      if (_moveOrigFrozen){ setFrozen(moveTarget, true); }
      else { moveTarget.body.type = CANNON.Body.DYNAMIC; moveTarget.body.mass = moveTarget.origMass;
             moveTarget.body.updateMassProperties(); moveTarget.body.wakeUp(); }
      if (moveTarget.mesh) moveTarget.mesh.material.emissiveIntensity = 0;
    }
  }
  _moveDrag = null;
  oneShot(S+"Tools/GravityRay/Close.ogg", 0.45);
}

function moveArrowDragging(){ return !!_moveDrag; }

function moveArrowDragMove(mx, my){
  if (!_moveDrag || !moveTarget) return;
  const mesh = _getMoveMesh(); if (!mesh) return;
  const dir = _moveDrag.dir;
  // Project world axis onto screen to get drag direction
  const p1 = mesh.position.clone().project(camera);
  const p2 = mesh.position.clone().add(dir).project(camera);
  const sx = p2.x - p1.x, sy = p2.y - p1.y, sl = Math.sqrt(sx*sx + sy*sy);
  if (sl < 0.001) return;  // axis pointed straight at camera
  // NDC y is up, screen y is down → negate my
  const dot = mx * (sx/sl) - my * (sy/sl);
  // Scale pixel movement to world units using FOV + distance
  const dist = Math.max(1, camera.position.distanceTo(mesh.position));
  const wpp = 2 * Math.tan((camera.fov * Math.PI / 180) / 2) * dist / renderer.domElement.height;
  const move = dot * wpp;

  if (moveTarget._client){
    const cp = (typeof clientProps !== "undefined") && clientProps.get(moveTarget.netId);
    if (!cp) return;
    cp.mesh.position.addScaledVector(dir, move);
    cp.tx = cp.mesh.position.x; cp.ty = cp.mesh.position.y; cp.tz = cp.mesh.position.z;
    const now = performance.now();
    if (now - _moveLastSend > 60){
      _moveLastSend = now;
      netClientCmd({ t:"cmd", cmd:"movePos", netId:moveTarget.netId,
        x:cp.mesh.position.x, y:cp.mesh.position.y, z:cp.mesh.position.z });
    }
  } else {
    moveTarget.body.position.x += dir.x * move;
    moveTarget.body.position.y += dir.y * move;
    moveTarget.body.position.z += dir.z * move;
    moveTarget.mesh.position.copy(moveTarget.body.position);
    moveTarget.mesh.material.emissive = new T.Color(0xffe066);
    moveTarget.mesh.material.emissiveIntensity = 0.18;
  }
}

function moveRayPrimary(){
  if (netIsClient() && typeof canUseTools === "function" && !canUseTools()){ toast("Tools are disabled by the host"); return; }
  _buildMoveArrows();
  // Check if crosshair is over an arrow first
  raycaster.setFromCamera(CENTER, camera);
  const visArrows = _moveArrowMeshes.filter(m => m.parent.visible);
  if (visArrows.length){
    const hits = raycaster.intersectObjects(visArrows, false);
    if (hits.length){ _startMoveDrag(hits[0].object.userData.arrowIdx); return; }
  }
  // Not on arrow: click a prop to select it, click empty to deselect
  const a = aimedProp();
  if (a){
    _setMoveTarget(a.p);
    _moveSelected = true;
  } else {
    // Clicked empty space — deselect
    moveTarget = null;
    _moveSelected = false;
    _hideMoveArrows();
  }
}

function clearMoveRay(){
  _endMoveDrag();
  moveTarget = null;
  _moveSelected = false;
  _hideMoveArrows();
}

function moveRayRotate(){
  if (!moveTarget) return;
  const rot = new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0), Math.PI/4);
  if (moveTarget._client){
    const cp = (typeof clientProps !== "undefined") && clientProps.get(moveTarget.netId);
    if (!cp) return;
    cp.mesh.quaternion.premultiply(rot); cp.tq.copy(cp.mesh.quaternion);
    netClientCmd({ t:"cmd", cmd:"movePos", netId:moveTarget.netId,
      qx:cp.mesh.quaternion.x, qy:cp.mesh.quaternion.y, qz:cp.mesh.quaternion.z, qw:cp.mesh.quaternion.w });
  } else {
    moveTarget.mesh.quaternion.premultiply(rot);
    moveTarget.body.quaternion.set(
      moveTarget.mesh.quaternion.x, moveTarget.mesh.quaternion.y,
      moveTarget.mesh.quaternion.z, moveTarget.mesh.quaternion.w);
  }
  oneShot(S+"Tools/GravityRay/Open.ogg", 0.35);
}

function updateMoveRay(){
  if (activeTool !== 0 || toolRayMode !== "move"){ if (_moveArrows.length) _hideMoveArrows(); return; }
  if (netIsClient() && typeof canUseTools === "function" && !canUseTools()){ _hideMoveArrows(); return; }
  if (_moveDrag){ _placeArrows(); return; }  // dragging: keep arrows on prop
  // If a prop is selected (clicked), keep showing its arrows regardless of where camera points
  if (_moveSelected && moveTarget){
    _placeArrows();
    return;
  }
  // Otherwise preview arrows on whatever prop the crosshair is over
  const a = aimedProp();
  if (a){ _setMoveTarget(a.p); _placeArrows(); }
  else { moveTarget = null; _hideMoveArrows(); }
}

/* ---- Clone ------------------------------------------------------------ */
// drop a copy of the aimed prop directly on top of it, carrying over paint, scale,
// light colours and radio type. Host-authoritative; clients ask the host to clone.
function clonePrimary(){
  const a = aimedProp(); if (!a){ toast("Aim at a prop to clone it"); return; }
  const p = a.p;
  if (netIsClient()){
    if (!canPlace()){ toast("Placing props is disabled by the host"); return; }
    netClientCmd({ t:"cmd", cmd:"clone", netId:p.netId });
    oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.6);
    return;
  }
  doClone(p);
  oneShot(S+"Tools/ToolRay/ToolRay.ogg", 0.6);
  toast("Cloned!");
}
// host-side clone: spawn an identical prop lifted just above the original
function doClone(p){
  if (!p || props.indexOf(p) < 0) return null;
  const half = (typeof propHalfLocal === "function") ? propHalfLocal(p).y : 1;
  const bp = p.body.position;
  const cfg = (p.type === LIGHT) ? { lightColor:p.lightColor, blockColor:p.blockColor, on:p.lightOn } : undefined;
  const c = spawnProp(p.type, { x:bp.x, y:bp.y + half*2 + 0.6, z:bp.z }, cfg);
  if (!c) return null;
  c.body.quaternion.copy(p.body.quaternion);
  if (p.paintColor != null && typeof doPaint === "function") doPaint(c, p.paintColor);
  if (((p.sx||1)!==1 || (p.sy||1)!==1 || (p.sz||1)!==1) && typeof applyPropScale === "function"){
    c.sx = p.sx; c.sy = p.sy; c.sz = p.sz; applyPropScale(c);
  }
  c.explodable = p.explodable; c.collides = p.collides;
  if (typeof applyPropCollision === "function") applyPropCollision(c);
  // carry over the locked/frozen state so a copy of a locked prop is also locked
  if (p.frozen && typeof setFrozen === "function") setFrozen(c, true);
  return c;
}

/* ---- LockRay ---------------------------------------------------------- */
function lockRayPrimary(){
  if (netIsClient() && typeof canUseTools === "function" && !canUseTools()){ toast("Tools are disabled by the host"); return; }
  const a = aimedProp(); if (!a){ toast("Aim at a prop to lock/unlock it"); return; }
  const locking = !a.p.frozen;
  if (netIsClient()){
    netClientCmd({ t:"cmd", cmd:"lockProp", netId:a.p.netId, lock:locking });
    toast(locking ? "Locked" : "Unlocked");
  } else {
    setFrozen(a.p, locking);
    toast(locking ? "Locked" : "Unlocked");
    oneShot(S + (locking ? "Tools/LockRay/Lock.ogg" : "Tools/LockRay/Unlock.ogg"));
  }
}
