"use strict";
/* main.js — starter scene and the render/update loop. Loaded last. */
(function seed(){
  for (let i=0;i<6;i++) spawnProp(0, { x:-6+i%3*3, y:1.2+((i/3|0)*2.2), z:-6 });
  spawnProp(2, { x:5, y:2, z:-4 });
  spawnProp(1, { x:8, y:6, z:-6 });
  spawnProp(3, { x:-8, y:1, z:2 });
})();
logLine("Welcome! Press Enter and type /fly to toggle flight.", true);

let last = performance.now();
function frame(now){
  requestAnimationFrame(frame);
  const dt = Math.min((now-last)/1000, 0.033); last = now;

  camera.position.sub(bobOffset);                   // restore the logical eye before simulating
  if (locked) move(dt);            // keep simulating (gravity!) even while chatting — move() ignores keys when chat is open
  else bobAmp += (0 - bobAmp) * Math.min(1, dt*7);

  updateHeld();
  setLoop(SND.gravLoop, held !== null, 0.7);        // GravityRay hold loop while grabbing
  fadeAudio(SND.gravLoop, dt);

  if (!netIsClient()) world.step(1/60, dt, 3);   // clients don't simulate; the host is authoritative

  // detonate any cannonballs that hit hard this step, then remove them
  if (pendingExplosions.length){
    for (let i = props.length-1; i >= 0; i--) if (props[i]._dead) removeProp(props[i]);
    processExplosions();
  }
  updateExplosions(dt);
  updateWiring(dt);                                 // move wire nodes with their props, decay power flashes

  for (const p of props){ p.mesh.position.copy(p.body.position); p.mesh.quaternion.copy(p.body.quaternion); }
  netTick(dt);                                   // sync players/props over the network
  if (typeof updateHealth === "function") updateHealth(dt);   // combat: damage, death, respawn, HP bar
  if (typeof updateRemoteFlashlights === "function" && typeof netFlashStates === "function") updateRemoteFlashlights(netFlashStates());
  if (typeof updateSword === "function") updateSword(dt);                                    // sword viewmodel + slash
  if (typeof updateRemoteSwords === "function" && typeof netFlashStates === "function") updateRemoteSwords(netFlashStates(), dt);
  updateLightPool();                             // aim the shared light pool at the nearest lit blocks (after meshes moved)
  if (typeof updateResizeHandles === "function") updateResizeHandles();   // position ResizeRay handles on the aimed prop
  if (typeof updateMoveRay === "function") updateMoveRay();               // MoveRay: position held prop on plane

  // super-smooth walk/run camera shake, plus any explosion kick, as a render-only offset
  const rightV = new T.Vector3(1,0,0).applyEuler(camera.rotation);
  bobOffset.copy(rightV).multiplyScalar(Math.cos(bobPhase*0.5) * bobAmp * 0.6);
  bobOffset.y += Math.sin(bobPhase) * bobAmp;
  if (shake > 0.001){
    bobOffset.x += (Math.random()-0.5) * shake * 0.6;
    bobOffset.y += (Math.random()-0.5) * shake * 0.6;
    bobOffset.z += (Math.random()-0.5) * shake * 0.6;
    shake = Math.max(0, shake - dt*3);              // decays over ~1/3 second
  }
  camera.position.add(bobOffset);
  // position the first-person flashlight AFTER the bob offset is applied, so the
  // held model tracks the bobbed eye instead of appearing to float against it
  if (typeof updateFlashlight === "function") updateFlashlight(dt);

  hud.innerHTML =
    `Mode: <b>${flyMode?"Fly":"Walk"}</b> &nbsp; Tool: <b>${activeTool<0?"None":TOOLS[activeTool].name}</b>` +
    (activeTool===0 ? `<br>Prop: <b>${TYPES[selectedProp].name}</b>` :
     activeTool===WIRING_TOOL ? `<br>Place: <b>${WIRE_ITEMS[selectedWireItem].name}</b> · <b>Q</b> cycle · <b>L</b>-click place · <b>R</b>-click power · <b>R</b> delete · <b>C</b> new wire` :
     (held?`<br><b>grabbing…</b> scroll to pull/push`:"")) +
    `<br>Props: <b>${props.length}</b>/${PART_LIMIT} &nbsp; Gravity: <b>${gravityOn?"on":"off"}</b>` +
    (netRole!=="single" ? `<br>Net: <b>${netRole}</b>` : "");

  renderer.render(scene, camera);
}
requestAnimationFrame(frame);
