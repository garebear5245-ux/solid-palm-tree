"use strict";
/* world.js — save the current sandbox to a JSON file and load one back.
   Available to the host and to single-player (clients don't own the world).
   In multiplayer, loading on the host re-populates props that then stream to
   every client through the normal snapshot path. */

const mapFileEl = document.getElementById("mapFile");
const r3 = v => Math.round(v*1000)/1000;

function saveMap(){
  if (netIsClient()){ toast("Only the host can save the map"); return; }
  const idx = new Map(); props.forEach((p, i) => idx.set(p, i));
  const data = {
    v: 1,
    props: props.map(p => {
      const o = {
        t: p.type,
        pos: [r3(p.body.position.x), r3(p.body.position.y), r3(p.body.position.z)],
        quat: [r3(p.body.quaternion.x), r3(p.body.quaternion.y), r3(p.body.quaternion.z), r3(p.body.quaternion.w)],
        frozen: !!p.frozen,
      };
      if (p.type === LIGHT) o.light = { lc:p.lightColor, bc:p.blockColor, on:!!p.lightOn };
      if (p.paintColor != null) o.paint = p.paintColor;
      if ((p.sx||1)!==1 || (p.sy||1)!==1 || (p.sz||1)!==1) o.scale = [p.sx||1, p.sy||1, p.sz||1];
      return o;
    }),
    welds: [],
  };
  for (const w of weldConstraints){
    const i = idx.get(w.a), j = idx.get(w.b);
    if (i != null && j != null) data.welds.push([i, j]);
  }
  // wiring: nodes, buttons/switches, their bound props, and the wires between them
  if (typeof serializeWiring === "function") data.wiring = serializeWiring(idx);
  const blob = new Blob([JSON.stringify(data)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "sandbox-map.json"; a.click();
  URL.revokeObjectURL(url);
  toast("Map saved (" + data.props.length + " props)");
}

function loadMap(data){
  if (!data || !Array.isArray(data.props)) throw new Error("bad map");
  clearAll();
  const created = [];
  for (const pr of data.props){
    const ti = pr.t|0;
    const cfg = (ti === LIGHT && pr.light) ? { lightColor:pr.light.lc, blockColor:pr.light.bc, on:pr.light.on } : undefined;
    const p = spawnProp(ti, { x:pr.pos[0], y:pr.pos[1], z:pr.pos[2] }, cfg);
    if (pr.quat) p.body.quaternion.set(pr.quat[0], pr.quat[1], pr.quat[2], pr.quat[3]);
    if (pr.paint != null && typeof doPaint === "function") doPaint(p, pr.paint);
    if (pr.scale != null && typeof applyPropScale === "function"){
      if (Array.isArray(pr.scale)){ p.sx = pr.scale[0]; p.sy = pr.scale[1]; p.sz = pr.scale[2]; }
      else { p.sx = p.sy = p.sz = pr.scale; }   // tolerate old scalar saves
      applyPropScale(p);
    }
    p.body.velocity.set(0,0,0); p.body.angularVelocity.set(0,0,0);
    created.push(p);
  }
  for (const [i, j] of (data.welds || [])){
    if (created[i] && created[j]) weldProps(created[i], created[j], false);   // keep exact positions
  }
  // freeze last — welding unfreezes, so this wins
  data.props.forEach((pr, k) => { if (pr.frozen && created[k]) setFrozen(created[k], true); });
  // rebuild the wire graph (nodes rebind to their props by saved index)
  if (typeof loadWiring === "function") loadWiring(data.wiring, created);
  toast("Map loaded (" + created.length + " props)");
}

function importMap(){
  if (netIsClient()){ toast("Only the host can load a map"); return; }
  mapFileEl.value = "";       // allow re-picking the same file
  mapFileEl.click();
}
mapFileEl.addEventListener("change", () => {
  const f = mapFileEl.files[0]; if (!f) return;
  const reader = new FileReader();
  reader.onload = () => { try { loadMap(JSON.parse(reader.result)); } catch(e){ toast("Couldn't read that map file"); } };
  reader.readAsText(f);
});
