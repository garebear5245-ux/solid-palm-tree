"use strict";
/* ui.js — tool hotbar, ToolRay prop palette, toast, crosshair sizing. */
const toolsEl = document.getElementById("tools"), paletteEl = document.getElementById("palette");
const hud = document.getElementById("hud"), toastEl = document.getElementById("toast");

function setTool(i){
  if (i >= 2 && typeof canUseToolIdx === "function" && !canUseToolIdx(i)){
    toast("The host restricted " + TOOLS[i].name);
    return;
  }
  if (typeof FLASHLIGHT_TOOL !== "undefined" && i === FLASHLIGHT_TOOL && typeof canUseFlashlight === "function" && !canUseFlashlight()){
    toast("The host disabled the flashlight"); return;
  }
  if (typeof SWORD_TOOL !== "undefined" && i === SWORD_TOOL && typeof canUseSword === "function" && !canUseSword()){
    toast("The host disabled the sword"); return;
  }
  if (typeof toolIsGranted === "function" && !toolIsGranted(i)){
    toast(TOOLS[i].name + " isn't granted — right-click the ToolRay to grant it");
    return;
  }
  activeTool = i; releaseGrab(); if (typeof clearMoveRay === "function") clearMoveRay(); drawTools(); drawPalette();
}
// the tools currently in your hotbar, in display order (granted tools only) —
// Roblox-style: the slot number is the position in this list, not the tool's index.
function visibleTools(){
  const list = [];
  TOOLS.forEach((t,i) => { if (typeof toolIsGranted !== "function" || toolIsGranted(i)) list.push(i); });
  return list;
}
function drawTools(){
  toolsEl.innerHTML = "";
  visibleTools().forEach((i, pos) => {
    const t = TOOLS[i];
    const el = document.createElement("div");
    el.className = "tool" + (i===activeTool?" on":"");
    // ToolRay (the "ToolGun") shows a badge while welding is on or a mode is active
    let badge = "";
    if (i===0 && weldEnabled) badge = `<div class="weldtip">WELD ENABLED</div>`;
    else if (i===0 && typeof toolRayMode !== "undefined" && toolRayMode !== "spawn")
      badge = `<div class="weldtip">${toolRayMode.toUpperCase()} MODE</div>`;
    el.innerHTML = `<span class="k">${pos+1}</span>${t.name}<span class="d">${t.desc}</span>${badge}`;
    toolsEl.appendChild(el);
  });
}
function css(c){ return "#" + c.toString(16).padStart(6,"0"); }
function drawPalette(){
  const isWiring = (typeof WIRING_TOOL !== "undefined" && activeTool === WIRING_TOOL);
  paletteEl.style.display = (activeTool === 0 || isWiring) ? "block" : "none";
  if (isWiring){ drawWirePalette(); return; }
  if (activeTool !== 0) return;
  const mode = (typeof toolRayMode !== "undefined") ? toolRayMode : "spawn";
  if (mode === "paint"){ drawPaintPalette(); return; }
  if (mode === "configure"){ paletteEl.innerHTML = "<h3>TOOLRAY · CONFIGURE</h3><div class='hint'>Click an object to configure it — explosives, collision, lock (and light colours).</div>"; return; }
  if (mode === "clone"){ paletteEl.innerHTML = "<h3>TOOLRAY · CLONE</h3><div class='hint'>Click a prop to drop a copy on top of it.</div>"; return; }
  if (mode === "resize"){ paletteEl.innerHTML = "<h3>TOOLRAY · RESIZE</h3><div class='hint'>Aim at a prop, then drag a glowing handle to resize it.</div>"; return; }
  if (mode === "move"){ paletteEl.innerHTML = "<h3>TOOLRAY · MOVE</h3><div class='hint'>Aim at a prop — arrows appear on its faces. Hold+drag an arrow to slide along that axis. Right-click to rotate 45°.</div>"; return; }
  if (mode === "lock"){ paletteEl.innerHTML = "<h3>TOOLRAY · LOCK</h3><div class='hint'>Click a prop to lock it in place. Click again to unlock. F also works.</div>"; return; }
  paletteEl.innerHTML = "<h3>TOOLRAY · PROPS</h3>";
  TYPES.forEach((t,i) => {
    if (typeof canUseItem === "function" && !canUseItem(i)) return;   // host-restricted item
    const el = document.createElement("div");
    el.className = "pit" + (i===selectedProp?" on":"");
    el.innerHTML = `<span class="sw" style="background:${css(t.color)}"></span>${t.name}`;
    paletteEl.appendChild(el);
  });
  const h = document.createElement("div"); h.className = "hint";
  h.textContent = "Q change · E/click spawn · Right-click menu";
  paletteEl.appendChild(h);
}
// PaintRay colour palette (Q cycles, matches the ToolRay layout)
function drawPaintPalette(){
  paletteEl.innerHTML = "<h3>PAINTRAY</h3>";
  PAINT_COLORS.forEach((c,i) => {
    const el = document.createElement("div");
    el.className = "pit" + (i===paintIndex?" on":"");
    el.innerHTML = `<span class="sw" style="background:${css(c)}"></span>${css(c)}`;
    paletteEl.appendChild(el);
  });
  const h = document.createElement("div"); h.className = "hint";
  h.textContent = "Q change colour · click to paint";
  paletteEl.appendChild(h);
}
// wiring quick-selection, styled to match the ToolRay props palette
const WIRE_SWATCH = ["#38e0ff", "#ff5b5b", "#51e07a", "#800000"];   // node, button, switch, repeater
function drawWirePalette(){
  paletteEl.innerHTML = "<h3>WIRING</h3>";
  WIRE_ITEMS.forEach((t,i) => {
    const el = document.createElement("div");
    el.className = "pit" + (i===selectedWireItem?" on":"");
    el.innerHTML = `<span class="sw" style="background:${WIRE_SWATCH[i]||"#7cf6c9"}"></span>${t.name}`;
    paletteEl.appendChild(el);
  });
  const h = document.createElement("div"); h.className = "hint";
  h.textContent = "Q change · click place · Right-click power · C new wire";
  paletteEl.appendChild(h);
}
drawTools(); drawPalette();

let toastTimer;
function toast(m){ toastEl.textContent = m; toastEl.style.opacity = 1; toastEl.style.color = ""; clearTimeout(toastTimer); toastTimer = setTimeout(()=>toastEl.style.opacity=0, 1300); }
// a red warning toast (e.g. hitting a spawn cap); colour resets after it fades
let _warnResetTimer;
function toastWarn(m){
  toast(m);
  toastEl.style.color = "#ff5b5b";
  clearTimeout(_warnResetTimer);
  _warnResetTimer = setTimeout(() => { toastEl.style.color = ""; }, 1500);
}

/* ---- ToolRay spawn menu ---------------------------------------------- */
const tmenuEl = document.getElementById("tmenu");
const tmSecEl = document.getElementById("tmsections");
const tmHeadEl = tmenuEl.querySelector("#tmheader h2");
const tmBodyEl = document.getElementById("tmbody");
const tmCloseEl = document.getElementById("tmclose");

const MENU_SECTIONS = [ { id:"props", name:"Props" }, { id:"tools", name:"Tools" }, { id:"welding", name:"Welding" }, { id:"light", name:"Light" }, { id:"time", name:"Time" }, { id:"combat", name:"Combat" }, { id:"world", name:"World" } ];
const PROP_FILTERS = [ ["all","All"], ["function","Function"], ["shapes","Shapes"], ["props","Props"] ];
let tmenuOpen = false, curSection = "props", propFilter = "all";

// wire hover + click feedback sounds onto any menu control
function uiBtn(el, onClick){
  el.addEventListener("mouseenter", uiHover);
  el.addEventListener("click", () => { uiClick(); onClick(); });
  return el;
}

function renderToolMenu(){
  // left: scrollable section list
  tmSecEl.innerHTML = '<div class="lbl">SECTIONS</div>';
  MENU_SECTIONS.forEach(s => {
    if ((s.id === "world" || s.id === "time" || s.id === "combat") && netIsClient()) return;   // clients don't own the world / time / combat rules
    const el = document.createElement("div");
    el.className = "tmsec" + (s.id===curSection?" on":"");
    el.textContent = s.name;
    uiBtn(el, () => { curSection = s.id; renderToolMenu(); });
    tmSecEl.appendChild(el);
  });
  // top header
  const sec = MENU_SECTIONS.find(s => s.id===curSection);
  tmHeadEl.textContent = sec ? sec.name.toUpperCase() : "";
  // body
  tmBodyEl.innerHTML = "";
  if (curSection === "props") renderPropsBody();
  else if (curSection === "tools") renderToolsBody();
  else if (curSection === "welding") renderWeldingBody();
  else if (curSection === "light") renderLightBody();
  else if (curSection === "time") renderTimeBody();
  else if (curSection === "combat") renderCombatBody();
  else if (curSection === "world") renderWorldBody();
  if (curSection === "props") renderModesPanel();   // ToolRay mode toggles, docked left of the props menu
}

// the three ToolRay modes as Welding-style toggles, docked on the LEFT (props menu is docked right)
function renderModesPanel(){
  if (typeof TOOLRAY_MODES === "undefined") return;
  const box = document.createElement("div"); box.className = "tmmodes";
  box.innerHTML = '<div class="lbl">TOOLRAY MODES</div>';
  TOOLRAY_MODES.forEach(m => {
    const row = document.createElement("div"); row.className = "moderow";
    row.innerHTML = `<span>${m.name}</span>`;
    const blocked = typeof modeAllowedClient === "function" && netIsClient() && !modeAllowedClient(m.id);
    const on = (typeof toolRayMode !== "undefined") && toolRayMode === m.id;
    const sw = document.createElement("div"); sw.className = "tsw" + (on ? " on" : "");
    if (blocked) sw.style.opacity = "0.5";
    uiBtn(sw, () => {
      if (blocked){ toast("The host restricted " + m.id + " mode"); return; }
      setToolRayMode(m.id);
      renderToolMenu();
    });
    row.appendChild(sw); box.appendChild(row);
  });
  tmBodyEl.appendChild(box);
}

// grant/equip tools. Granting is gated in multiplayer by the "grant" permission.
function renderToolsBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  const gated = (typeof canGrantTools === "function" && !canGrantTools());
  panel.innerHTML = "<p>Grant yourself a tool, then equip it." +
    (gated ? " <b>The host hasn't allowed granting tools.</b>" : "") + "</p>";
  TOOLS.forEach((t,i) => {
    const row = document.createElement("div"); row.className = "tmrow";
    row.innerHTML = `<span>${t.name} <span style="opacity:.55">· ${t.desc}</span></span>`;
    const granted = toolGranted[i];
    const blocked = i >= 2 && typeof canUseToolIdx === "function" && !canUseToolIdx(i);
    const b = document.createElement("span");
    b.className = "mpbtn" + (granted ? "" : " ghost");
    b.textContent = blocked ? "BLOCKED" : granted ? (i===activeTool ? "EQUIPPED" : "EQUIP") : "GRANT";
    if (blocked || (!granted && gated)) b.style.opacity = "0.5";
    uiBtn(b, () => {
      if (blocked){ toast("The host restricted " + t.name); return; }
      if (!granted){ if (!grantTool(i)) return; }
      else { setTool(i); closeToolMenu(); return; }
      renderToolMenu();
    });
    row.appendChild(b); panel.appendChild(row);
  });
  tmBodyEl.appendChild(panel);
}

// ToolRay › Time — retint the world (host / single-player only)
function renderTimeBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  panel.innerHTML = "<p>Set the time of day. This retints the sun, sky and fog for everyone in the world.</p>";
  const grid = document.createElement("div"); grid.className = "tmfilters";
  (typeof TIME_PRESETS !== "undefined" ? TIME_PRESETS : []).forEach(t => {
    const c = document.createElement("div");
    c.className = "chip" + ((typeof currentTime !== "undefined" && currentTime === t.id) ? " on" : "");
    c.textContent = t.name;
    uiBtn(c, () => { setTimeOfDay(t.id); renderToolMenu(); });
    grid.appendChild(c);
  });
  panel.appendChild(grid);
  tmBodyEl.appendChild(panel);
}

// ToolRay › Combat — host/single-player: who is immune, and the world spawn point
function renderCombatBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  panel.innerHTML = "<p>Control damage in your world. <b>Immunity</b> decides who can't be hurt. " +
    "By default <b>everyone</b> is immune (no damage). Pick <b>No one</b> to make every player — including you — " +
    "mortal, or turn it off for specific players. Anyone not immune gets a health bar and takes " +
    "fall / explosive / void damage. Each source can be switched off in <b>Settings ▸ Gameplay</b>.</p>";

  const commit = () => {
    if (typeof netIsHost === "function" && netIsHost() && typeof hostBroadcastPerms === "function") hostBroadcastPerms();
    if (typeof onCombatRulesChanged === "function") onCombatRulesChanged();
    renderToolMenu();
  };

  // scope selector: Everyone / No one / Host only / Specific people
  const head = document.createElement("div"); head.className = "step"; head.textContent = "IMMUNITY"; panel.appendChild(head);
  const modeRow = document.createElement("div"); modeRow.className = "tmfilters"; modeRow.style.marginBottom = "10px";
  [["all","Everyone"],["none","No one"],["host","Host only"],["some","Specific people"]].forEach(([id,lab]) => {
    const c = document.createElement("div"); c.className = "chip" + (netPerms.immunityMode===id?" on":"");
    c.textContent = lab;
    uiBtn(c, () => { netPerms.immunityMode = id; commit(); });
    modeRow.appendChild(c);
  });
  panel.appendChild(modeRow);

  // when "Specific people": pick which connected players are immune
  if (netPerms.immunityMode === "some"){
    const ll = document.createElement("div"); ll.className = "sub"; ll.style.margin = "0 0 6px"; ll.textContent = "Immune players:"; panel.appendChild(ll);
    const grid = document.createElement("div"); grid.className = "tmfilters";
    const roster = (typeof netRoster !== "undefined" && netRoster.size) ? [...netRoster] : [[0,{name:myName||"You"}]];
    roster.forEach(([id, r]) => {
      const inList = (netPerms.immunityList || []).includes(id);
      const c = document.createElement("div"); c.className = "chip" + (inList?" on":"");
      c.textContent = (r && r.name ? r.name : ("Player " + id)) + (id===0 ? " (host)" : "");
      uiBtn(c, () => {
        const list = netPerms.immunityList || (netPerms.immunityList = []);
        const at = list.indexOf(id);
        if (at >= 0) list.splice(at, 1); else list.push(id);
        commit();
      });
      grid.appendChild(c);
    });
    panel.appendChild(grid);
  }

  // friendly fire — whether the sword can hurt other players
  const ffHead = document.createElement("div"); ffHead.className = "step"; ffHead.textContent = "FRIENDLY FIRE"; ffHead.style.marginTop = "16px"; panel.appendChild(ffHead);
  const ffDesc = document.createElement("div"); ffDesc.className = "sub"; ffDesc.style.margin = "0 0 8px";
  ffDesc.textContent = "When off, sword hits deal no damage to other players (and play no hit sound).";
  panel.appendChild(ffDesc);
  const ffRow = document.createElement("div"); ffRow.className = "setrow"; ffRow.style.cssText = "display:flex;align-items:center;gap:10px";
  ffRow.innerHTML = `<span class="lab" style="flex:1">Players can damage each other</span>`;
  const ffSw = document.createElement("div"); ffSw.className = "tsw" + (netPerms.friendlyFire ? " on" : "");
  uiBtn(ffSw, () => { netPerms.friendlyFire = !netPerms.friendlyFire; ffSw.classList.toggle("on", netPerms.friendlyFire); commit(); });
  ffRow.appendChild(ffSw); panel.appendChild(ffRow);

  // world spawn — respawn point for anyone who dies
  const sh = document.createElement("div"); sh.className = "step"; sh.textContent = "WORLD SPAWN"; sh.style.marginTop = "16px"; panel.appendChild(sh);
  const sd = document.createElement("div"); sd.className = "sub"; sd.style.margin = "0 0 8px";
  sd.textContent = "Where players respawn 3 seconds after they die. Stand where you want it, then set it.";
  panel.appendChild(sd);
  const row = document.createElement("div"); row.className = "mprow";
  const setBtn = document.createElement("span"); setBtn.className = "mpbtn"; setBtn.textContent = "SET WORLD SPAWN HERE";
  uiBtn(setBtn, () => { if (typeof setWorldSpawn === "function") setWorldSpawn(); });
  row.appendChild(setBtn); panel.appendChild(row);

  tmBodyEl.appendChild(panel);
}

function renderWorldBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  panel.innerHTML = "<p>Save the current sandbox — every prop with its position, paint, size and freeze state, plus all welds and wiring (nodes, buttons, switches &amp; wires) — to a file you can load again later. In multiplayer, loading a map repopulates the world for all connected players.</p>";

  // host/single-player part limit — raising it too far will start to lag the sim
  if (typeof PART_LIMIT !== "undefined"){
    const lim = document.createElement("div"); lim.className = "setrow"; lim.style.borderBottom = "0";
    lim.innerHTML = `<span class="lab">Part limit</span>`;
    const input = document.createElement("input"); input.type = "range";
    input.min = PART_LIMIT_MIN; input.max = PART_LIMIT_MAX; input.step = 10; input.value = PART_LIMIT;
    const valEl = document.createElement("span"); valEl.className = "val"; valEl.textContent = PART_LIMIT + (PART_LIMIT >= 400 ? " ⚠" : "");
    input.addEventListener("input", () => { const v = parseInt(input.value, 10); valEl.textContent = v + (v >= 400 ? " ⚠" : ""); setPartLimit(v); if (typeof saveSettings === "function") saveSettings(); });
    input.addEventListener("change", uiClick);
    lim.appendChild(input); lim.appendChild(valEl); panel.appendChild(lim);
    const hint = document.createElement("div"); hint.className = "sub"; hint.style.cssText = "opacity:.55;font-size:11px;margin:2px 0 12px";
    hint.textContent = "Higher = more props at once, but very high values will lag the physics.";
    panel.appendChild(hint);
  }

  const row = document.createElement("div"); row.className = "mprow";
  const save = document.createElement("span"); save.className = "mpbtn"; save.textContent = "SAVE MAP";
  uiBtn(save, () => saveMap());
  const load = document.createElement("span"); load.className = "mpbtn ghost"; load.textContent = "LOAD MAP";
  uiBtn(load, () => importMap());
  row.appendChild(save); row.appendChild(load);
  panel.appendChild(row);
  tmBodyEl.appendChild(panel);
}

function renderPropsBody(){
  const panel = document.createElement("div"); panel.className = "tmprops";
  const filters = document.createElement("div"); filters.className = "tmfilters";
  PROP_FILTERS.forEach(([id,label]) => {
    const c = document.createElement("div");
    c.className = "chip" + (propFilter===id?" on":"");
    c.textContent = label;
    uiBtn(c, () => { propFilter = id; renderToolMenu(); });
    filters.appendChild(c);
  });
  const grid = document.createElement("div"); grid.className = "tmgrid";
  TYPES.forEach((t,i) => {
    if (propFilter !== "all" && t.cat !== propFilter) return;
    if (typeof canUseItem === "function" && !canUseItem(i)) return;   // host-restricted item
    const card = document.createElement("div");
    card.className = "tmcard" + (i===selectedProp?" on":"");
    card.innerHTML = `<span class="sw" style="background:${css(t.color)}"></span>${t.name}<span class="tag">${t.cat}</span>`;
    uiBtn(card, () => { selectedProp = i; drawPalette(); renderToolMenu(); });
    grid.appendChild(card);
  });
  panel.appendChild(filters); panel.appendChild(grid);
  tmBodyEl.appendChild(panel);
}

function renderWeldingBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  panel.innerHTML = "<p>When welding is enabled, use the ToolRay on one prop, then a second, to lock them rigidly together. The ToolGun shows a red <b>WELD ENABLED</b> marker while it's on.</p>";
  const row = document.createElement("div"); row.className = "tmrow";
  row.innerHTML = "<span>Enable welding</span>";
  const sw = document.createElement("div"); sw.className = "tsw" + (weldEnabled?" on":"");
  uiBtn(sw, () => {
    weldEnabled = !weldEnabled;
    if (!weldEnabled && weldFirst){ setWeldHighlight(weldFirst, false); weldFirst = null; }
    drawTools(); renderToolMenu();
  });
  row.appendChild(sw); panel.appendChild(row);
  tmBodyEl.appendChild(panel);
}

// Light settings: the 3 properties of the Light block — light colour, block colour, on/off.
// Editing here sets the defaults for newly spawned lights and re-tints every existing light.
function hex6(n){ return "#" + (n>>>0 & 0xffffff).toString(16).padStart(6,"0"); }
function applyLightSettingsToAll(){
  for (const p of props) if (p.type === LIGHT){
    p.lightColor = lightDefaults.lightColor;
    p.blockColor = lightDefaults.blockColor;
    applyLightState(p);
  }
  if (typeof hostBroadcastLights === "function") hostBroadcastLights();
}
function renderLightBody(){
  const panel = document.createElement("div"); panel.className = "tmpanel";
  panel.innerHTML = "<p>The <b>Light</b> is a small functional block. Wire it to a <b>Switch</b> to hold it on, or a <b>Button</b> to toggle it. These settings apply to newly spawned lights and re-tint the ones already placed.</p>";

  const mkColorRow = (label, key) => {
    const row = document.createElement("div"); row.className = "tmrow"; row.style.marginBottom = "12px";
    row.innerHTML = `<span>${label}</span>`;
    const inp = document.createElement("input"); inp.type = "color"; inp.value = hex6(lightDefaults[key]);
    inp.style.cssText = "width:46px;height:28px;border:0;background:none;cursor:pointer";
    inp.addEventListener("input", () => { lightDefaults[key] = parseInt(inp.value.slice(1), 16); applyLightSettingsToAll(); });
    row.appendChild(inp); panel.appendChild(row);
  };
  mkColorRow("Light colour", "lightColor");
  mkColorRow("Block colour", "blockColor");

  const row = document.createElement("div"); row.className = "tmrow";
  row.innerHTML = "<span>On by default</span>";
  const sw = document.createElement("div"); sw.className = "tsw" + (lightDefaults.on ? " on" : "");
  uiBtn(sw, () => {
    lightDefaults.on = !lightDefaults.on;
    for (const p of props) if (p.type === LIGHT){ p.lightOn = lightDefaults.on; }   // let wiring recompute lit
    renderToolMenu();
  });
  row.appendChild(sw); panel.appendChild(row);
  tmBodyEl.appendChild(panel);
}

function openToolMenu(){
  if (tmenuOpen) return;
  tmenuOpen = true;
  tmenuEl.classList.add("open");
  renderToolMenu();
  document.exitPointerLock();          // free the cursor to click the menu
}
function closeToolMenu(){
  if (!tmenuOpen) return;
  tmenuOpen = false;
  tmenuEl.classList.remove("open");
  uiClose();
  renderer.domElement.requestPointerLock();   // recapture the mouse for play
}
uiBtn(tmCloseEl, closeToolMenu);

/* crosshair: enforce a visible minimum size, fall back to a drawn cross if missing */
const crossImg = document.getElementById("cross");
crossImg.addEventListener("load", () => {
  const n = crossImg.naturalWidth || 0;
  crossImg.style.width = (n < 28 ? 32 : Math.min(n, 64)) + "px";   // scale up small crosshairs
});
crossImg.addEventListener("error", () => { crossImg.style.display = "none"; document.getElementById("crossfb").style.display = "block"; });
