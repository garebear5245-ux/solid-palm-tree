"use strict";
/* health.js — opt-in combat: local player health, damage from falls / explosions /
   the void, death with a 3-second respawn, and the bottom-right health bar.

   Health is LOCALLY authoritative: each client computes its own damage and just
   broadcasts a death flag (localDeathBit) that other clients render as a KO cube
   (see net.js). Immunity is a host rule carried in netPerms (playerIsImmune).

   Loaded after net.js so netPerms / playerIsImmune / myPlayerId exist. */

const MAX_HEALTH = 100;
let myHealth = MAX_HEALTH;
let amDead = false;
let _respawnAt = 0;               // performance.now() ms at which we respawn
const VOID_Y = -25;               // fall below this and the void claims you
const DEFAULT_SPAWN = { x:0, y:3.2, z:18 };   // matches the camera seed in player.js

/* ---- combat rule lookups --------------------------------------------- */
// am I (the local player) currently immune under the host's rules?
function amImmune(){
  if (typeof playerIsImmune !== "function") return true;
  const id = (typeof myPlayerId !== "undefined") ? myPlayerId : 0;
  return playerIsImmune(id);
}
// is a given damage source switched on in Settings (and am I damageable at all)?
function damageEnabled(source){
  if (amImmune()) return false;
  // In multiplayer as a client the host controls combat rules, so ignore local damage-source toggles
  if (typeof netIsClient === "function" && netIsClient()) return true;
  if (typeof SETTINGS === "undefined") return true;
  const v = SETTINGS["dmg" + source];
  return v !== false;
}
// the point we respawn at — host-set world spawn, else the default
function getWorldSpawn(){
  const s = (typeof netPerms !== "undefined") ? netPerms.worldSpawn : null;
  return (s && typeof s.x === "number") ? s : DEFAULT_SPAWN;
}

/* ---- damage / death / respawn ---------------------------------------- */
function applyDamage(amount, cause){
  if (amDead || amImmune() || !(amount > 0)) return;
  myHealth = Math.max(0, myHealth - amount);
  if (typeof shake !== "undefined") shake = Math.min(1, shake + 0.25);   // reuse the screen-shake feedback
  if (myHealth <= 0) die(cause);
  else updateHealthBar();                                                // reflect the hit immediately
}
function die(cause){
  if (amDead) return;
  amDead = true;
  myHealth = 0;
  _respawnAt = performance.now() + 3000;
  if (typeof velY !== "undefined") velY = 0;
  if (typeof oneShot === "function") oneShot("Assets/Sounds/Player/KO.ogg", 0.85, "sfx");
  if (typeof toast === "function") toast("You died");
  if (typeof logLine === "function") logLine("You were knocked out — respawning…", true);
  updateHealthBar();
}
function respawn(){
  amDead = false;
  myHealth = MAX_HEALTH;
  const sp = getWorldSpawn();
  if (typeof camera !== "undefined"){ camera.position.set(sp.x, sp.y, sp.z); }
  if (typeof velY !== "undefined") velY = 0;
  updateHealthBar();
}

// set the world spawn to the local player's position (host / single-player authority)
function setWorldSpawn(){
  if (typeof netIsClient === "function" && netIsClient()){ toast("Only the host can set the world spawn"); return; }
  const p = camera.position;
  netPerms.worldSpawn = { x:p.x, y:p.y, z:p.z };
  if (typeof netIsHost === "function" && netIsHost() && typeof hostBroadcastPerms === "function") hostBroadcastPerms();
  if (typeof toast === "function") toast("World spawn set here");
}

// called from net.js applyPerms when combat rules change: if the new rules make us
// immune, cancel any in-progress damage/death so toggling immunity on is always safe
function onCombatRulesChanged(){
  if (amImmune()){
    if (amDead){ amDead = false; _respawnAt = 0; }
    myHealth = MAX_HEALTH;
  }
  updateHealthBar();
}

/* ---- network hook ----------------------------------------------------- */
function localDeathBit(){ return amDead ? 1 : 0; }

/* ---- per-frame update ------------------------------------------------- */
function updateHealth(dt){
  // void: falling below the world. Immune players (or void-damage-off) are rescued
  // to spawn so nobody falls forever now that the fly floor-clamp is gone.
  if (typeof camera !== "undefined" && camera.position.y < VOID_Y){
    if (damageEnabled("Void")) die("void");
    else { camera.position.set(getWorldSpawn().x, getWorldSpawn().y, getWorldSpawn().z); if (typeof velY !== "undefined") velY = 0; }
  }
  // respawn timer
  if (amDead && performance.now() >= _respawnAt) respawn();
  updateHealthBar();
}

/* ---- HUD -------------------------------------------------------------- */
const healthBarEl = document.getElementById("healthbar");
const healthFillEl = document.getElementById("healthfill");
const healthNumEl = document.getElementById("healthnum");
const deathOverlayEl = document.getElementById("deathoverlay");
function updateHealthBar(){
  if (!healthBarEl) return;
  const show = !amImmune();                       // only visible when you can actually be hurt
  healthBarEl.style.display = show ? "flex" : "none";
  if (show){
    const pct = Math.max(0, Math.min(1, myHealth / MAX_HEALTH));
    healthFillEl.style.width = (pct * 100) + "%";
    // green -> orange -> red as health drops
    const hue = Math.round(pct * 120);
    healthFillEl.style.background = `hsl(${hue},80%,45%)`;
    if (healthNumEl) healthNumEl.textContent = Math.ceil(myHealth);
  }
  if (deathOverlayEl){
    if (amDead){
      deathOverlayEl.style.display = "flex";
      const secs = Math.max(0, Math.ceil((_respawnAt - performance.now()) / 1000));
      deathOverlayEl.innerHTML = `<div class="deadbig">YOU DIED</div><div class="deadsub">Respawning in ${secs}s…</div>`;
    } else {
      deathOverlayEl.style.display = "none";
    }
  }
}
updateHealthBar();
