registerGameMeta({ name: "Paint", type: "app" });
