registerGameMeta({ name: "Eaglercraft", type: "game" });
