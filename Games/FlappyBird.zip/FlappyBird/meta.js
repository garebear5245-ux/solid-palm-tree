registerGameMeta({ name: "Flappy Bird", type: "game" });
