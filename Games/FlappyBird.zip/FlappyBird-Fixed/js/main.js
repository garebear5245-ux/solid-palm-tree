var debugmode = false;

var states = Object.freeze({
   SplashScreen: 0,
   GameScreen: 1,
   ScoreScreen: 2
});

var currentstate;

var gravity = 0.25;
var velocity = 0;
var position = 180;
var rotation = 0;
var jump = -4.6;
var flyArea = $("#flyarea").height();

var score = 0;
var highscore = 0;

var pipeheight = 90;
var pipewidth = 52;
var pipes = new Array();

var replayclickable = false;

//sounds
var volume = 30;
var soundJump = new buzz.sound("assets/sounds/sfx_wing.ogg");
var soundScore = new buzz.sound("assets/sounds/sfx_point.ogg");
var soundHit = new buzz.sound("assets/sounds/sfx_hit.ogg");
var soundDie = new buzz.sound("assets/sounds/sfx_die.ogg");
var soundSwoosh = new buzz.sound("assets/sounds/sfx_swooshing.ogg");
var soundPipe = new buzz.sound("assets/sounds/sfx_pipe.ogg"); //Mario-style "fall through pipe"
buzz.all().setVolume(volume);

//loops
var loopGameloop;
var loopPipeloop;

//Cached DOM references and jQuery wrappers. The 60fps gameloop used to re-run
//these selectors every frame; caching them once removes that per-frame cost
//without changing any values.
var elemPlayer, $player, $land, $ceiling, $gamecontainer, $flyarea;
function cacheDom()
{
   elemPlayer = document.getElementById('player');
   $player = $("#player");
   $land = $("#land");
   $ceiling = $("#ceiling");
   $gamecontainer = $("#gamecontainer");
   $flyarea = $("#flyarea");
}

//The ground line and ceiling line are fixed on screen during a game (they only
//change when the window is resized/rescaled). Reading them via .offset() every
//frame forced a layout reflow 60 times a second; instead we compute them once
//and refresh them whenever the layout actually changes. Values are identical.
var landTop = 0;
var ceilingBottom = 0;
function refreshBounds()
{
   if(!$land)
      return;
   landTop = $land.offset().top;
   ceilingBottom = $ceiling.offset().top + $ceiling.height();
}

//Scale the fixed-size game world to fit any window, preserving aspect ratio (black bars).
var DESIGN_WIDTH = 480;
var DESIGN_HEIGHT = 640;
var gameScale = 1;
function scaleGame()
{
   gameScale = Math.min(window.innerWidth / DESIGN_WIDTH, window.innerHeight / DESIGN_HEIGHT);
   ($gamecontainer || $("#gamecontainer")).css('transform', 'translate(-50%, -50%) scale(' + gameScale + ')');
   refreshBounds();
}
$(window).on('resize orientationchange', scaleGame);

$(document).ready(function() {
   cacheDom();
   scaleGame();

   if(window.location.search == "?debug")
      debugmode = true;
   if(window.location.search == "?easy")
      pipeheight = 200;

   //get the highscore
   var savedscore = localStorage.getItem("highscore");
   if(savedscore != null)
      highscore = parseInt(savedscore);

   //start with the splash screen
   showSplash();
});

function getCookie(cname)
{
   var name = cname + "=";
   var ca = document.cookie.split(';');
   for(var i=0; i<ca.length; i++)
   {
      var c = ca[i].trim();
      if (c.indexOf(name)==0) return c.substring(name.length,c.length);
   }
   return "";
}

function setCookie(cname,cvalue,exdays)
{
   var d = new Date();
   d.setTime(d.getTime()+(exdays*24*60*60*1000));
   var expires = "expires="+d.toGMTString();
   document.cookie = cname + "=" + cvalue + "; " + expires;
}

function showSplash()
{
   currentstate = states.SplashScreen;

   //defensively clear the score screen so a fresh game always starts clean,
   //regardless of how we got back here
   $("#scoreboard").css("display", "none");
   replayclickable = false;

   //set the defaults (again)
   velocity = 0;
   position = 180;
   rotation = 0;
   score = 0;

   //clear the death fall/bounce animation so its fill:forwards transform can't
   //override the reset below
   if(elemPlayer)
      elemPlayer.classList.remove('birdfall', 'birdbounce');

   //update the player in preparation for the next game
   $("#player").css({ y: 0, x: 0 });
   updatePlayer($("#player"));

   //idle bob while waiting on the Get Ready screen (removed on start)
   if(elemPlayer)
      elemPlayer.classList.add('bob');

   soundSwoosh.stop();
   soundSwoosh.play();

   //clear out all the pipes if there are any
   $(".pipe").remove();
   pipes = new Array();

   //make everything animated again
   $(".animated").css('animation-play-state', 'running');
   $(".animated").css('-webkit-animation-play-state', 'running');

   //fade in the splash
   $("#splash").transition({ opacity: 1 }, 2000, 'ease');
}

function startGame()
{
   currentstate = states.GameScreen;

   //stop the idle bob so it doesn't fight the in-game transform
   if(elemPlayer)
      elemPlayer.classList.remove('bob');

   //fade out the splash
   $("#splash").stop();
   $("#splash").transition({ opacity: 0 }, 500, 'ease');

   //update the big score
   setBigScore();

   //debug mode?
   if(debugmode)
   {
      //show the bounding boxes
      $(".boundingbox").show();
   }

   //make sure the cached ground/ceiling lines reflect current layout
   refreshBounds();

   //start up our loops
   var updaterate = 1000.0 / 60.0 ; //60 times a second
   loopGameloop = setInterval(gameloop, updaterate);
   loopPipeloop = setInterval(updatePipes, 1400);

   //jump from the start!
   playerJump();
}

function updatePlayer(player)
{
   //rotation
   rotation = Math.min((velocity / 10) * 90, 90);

   //apply rotation and position
   $(player).css({ rotate: rotation, top: position });
}

function gameloop() {
   var player = $player;

   //update the player speed/position
   velocity += gravity;
   position += velocity;

   //update the player
   updatePlayer(player);

   //create the bounding box
   var box = elemPlayer.getBoundingClientRect();
   //getBoundingClientRect/offset values are in on-screen (scaled) space, so scale the design-unit constants to match
   var origwidth = 34.0 * gameScale;
   var origheight = 24.0 * gameScale;

   var boxwidth = origwidth - (Math.sin(Math.abs(rotation) / 90) * 8);
   var boxheight = (origheight + box.height) / 2;
   var boxleft = ((box.width - boxwidth) / 2) + box.left;
   var boxtop = ((box.height - boxheight) / 2) + box.top;
   var boxright = boxleft + boxwidth;
   var boxbottom = boxtop + boxheight;

   //if we're in debug mode, draw the bounding box
   if(debugmode)
   {
      var boundingbox = $("#playerbox");
      boundingbox.css('left', boxleft);
      boundingbox.css('top', boxtop);
      boundingbox.css('height', boxheight);
      boundingbox.css('width', boxwidth);
   }

   //did we hit the ground?
   if(box.bottom >= landTop)
   {
      postAchievement('flappybird_faceplant');
      playerDead();
      return;
   }

   //have they tried to escape through the ceiling? :o
   if(boxtop <= ceilingBottom)
      position = 0;

   //we can't go any further without a pipe
   if(pipes[0] == null)
      return;

   //determine the bounding box of the next pipes inner area
   var nextpipe = pipes[0];
   var nextpipeupper = nextpipe.upper || (nextpipe.upper = nextpipe.children(".pipe_upper"));
   //the upper pipe's height is fixed once created, so use the cached value
   var upperheight = (nextpipe.upperheight != null) ? nextpipe.upperheight : (nextpipe.upperheight = nextpipeupper.height());

   var pipetop = nextpipeupper.offset().top + (upperheight * gameScale);
   var pipeleft = nextpipeupper.offset().left - 2; // for some reason it starts at the inner pipes offset, not the outer pipes.
   var piperight = pipeleft + (pipewidth * gameScale);
   var pipebottom = pipetop + (pipeheight * gameScale);

   if(debugmode)
   {
      var boundingbox = $("#pipebox");
      boundingbox.css('left', pipeleft);
      boundingbox.css('top', pipetop);
      boundingbox.css('height', pipeheight);
      boundingbox.css('width', pipewidth);
   }

   //have we gotten inside the pipe yet?
   if(boxright > pipeleft)
   {
      //we're within the pipe, have we passed between upper and lower pipes?
      if(boxtop > pipetop && boxbottom < pipebottom)
      {
         //yeah! we're within bounds

      }
      else
      {
         //no! we touched the pipe
         playerDead();
         return;
      }
   }


   //have we passed the imminent danger?
   if(boxleft > piperight)
   {
      //yes, remove it
      pipes.splice(0, 1);

      //and score a point
      playerScore();
   }
}

//Handle space bar, up arrow and W. Holding a key fires keydown repeatedly (OS
//key repeat), which would make the bird flap continuously. Ignore those repeats
//so one flap requires one press; e.repeat covers modern browsers and the
//keysHeld guard covers older ones that don't set it.
var keysHeld = {};
$(document).keydown(function(e){
   if(e.keyCode == 32 || e.keyCode == 38 || e.keyCode == 87)
   {
      if(e.repeat || keysHeld[e.keyCode])
         return;
      keysHeld[e.keyCode] = true;
      if(currentstate == states.ScoreScreen)
         doReplay();
      else
         screenClick();
   }
});
$(document).keyup(function(e){
   keysHeld[e.keyCode] = false;
});

//Handle flap input. The original bound EITHER touchstart OR mousedown based on
//"ontouchstart" in window. On touchscreen Chromebooks that reports true, so the
//trackpad (which emits mouse events, not touch) could never flap. Pointer events
//cover mouse, trackpad, touch and pen with a single binding and fire once per
//input, so there's no double-flap. Fall back to touch+mouse on old browsers.
if(window.PointerEvent)
{
   $(document).on("pointerdown", screenClick);
}
else if("ontouchstart" in window)
{
   $(document).on("touchstart", screenClick);
}
else
{
   $(document).on("mousedown", screenClick);
}

function screenClick()
{
   if(currentstate == states.GameScreen)
   {
      playerJump();
   }
   else if(currentstate == states.SplashScreen)
   {
      startGame();
   }
}

function playerJump()
{
   velocity = jump;
   //play jump sound
   soundJump.stop();
   soundJump.play();
}

function setBigScore(erase)
{
   var elemscore = $("#bigscore");
   elemscore.empty();

   if(erase)
      return;

   var digits = score.toString().split('');
   for(var i = 0; i < digits.length; i++)
      elemscore.append("<img src='assets/font_big_" + digits[i] + ".png' alt='" + digits[i] + "'>");
}

function setSmallScore()
{
   var elemscore = $("#currentscore");
   elemscore.empty();

   var digits = score.toString().split('');
   for(var i = 0; i < digits.length; i++)
      elemscore.append("<img src='assets/font_small_" + digits[i] + ".png' alt='" + digits[i] + "'>");
}

function setHighScore()
{
   var elemscore = $("#highscore");
   elemscore.empty();

   var digits = highscore.toString().split('');
   for(var i = 0; i < digits.length; i++)
      elemscore.append("<img src='assets/font_small_" + digits[i] + ".png' alt='" + digits[i] + "'>");
}

function setMedal()
{
   var elemmedal = $("#medal");
   elemmedal.empty();

   if(score < 10)
      //signal that no medal has been won
      return false;

   if(score >= 10)
      medal = "bronze";
   if(score >= 20)
      medal = "silver";
   if(score >= 30)
      medal = "gold";
   if(score >= 40)
      medal = "platinum";

   elemmedal.append('<img src="assets/medal_' + medal +'.png" alt="' + medal +'">');

   //signal that a medal has been won
   return true;
}

function playerDead()
{
   //slight screen shake on impact. Re-adding the class each death re-triggers
   //the one-shot animation; it removes itself on animationend so the transform
   //is always cleared and it can never get stuck mid-shake.
   var gamescreen = document.getElementById('gamescreen');
   if(gamescreen)
   {
      gamescreen.classList.remove('shake');
      //force reflow so the animation restarts even on back-to-back deaths
      void gamescreen.offsetWidth;
      gamescreen.classList.add('shake');
      gamescreen.addEventListener('animationend', function handler() {
         gamescreen.classList.remove('shake');
         gamescreen.removeEventListener('animationend', handler);
      });
   }

   //white impact flash (like the original). One-shot; removes itself so it can
   //re-fire on the next death.
   var flash = document.getElementById('flash');
   if(flash)
   {
      flash.classList.remove('flash-on');
      void flash.offsetWidth; //force reflow so the animation restarts every death
      flash.classList.add('flash-on');
      flash.addEventListener('animationend', function fl() {
         flash.classList.remove('flash-on');
         flash.removeEventListener('animationend', fl);
      });
   }

   //stop animating everything! (except the bird itself — it's now running the
   //death fall/bounce CSS animation, and pausing .animated would freeze it)
   $(".animated").not(elemPlayer).css('animation-play-state', 'paused');
   $(".animated").not(elemPlayer).css('-webkit-animation-play-state', 'paused');

   //Work out what surface the bird will land on, then fall to it and bounce.
   //The bird drops straight down; the surface is the ground UNLESS the bird went
   //into a gap and is above a bottom pipe (measured from the frozen pipes, since
   //.animated is now paused). All measurements are in on-screen (scaled) space
   //and converted to design units for the transform.
   var box = elemPlayer.getBoundingClientRect();
   var birdcenterx = (box.left + box.right) / 2;
   var landingScreen = landTop; //ground by default (cached top of #land, screen px)
   var landedPipeCenterx = null, landedPipeHalfw = 0; //set if we land on a pipe
   for(var i = 0; i < pipes.length; i++)
   {
      var lowerEl = pipes[i].children(".pipe_lower")[0];
      if(!lowerEl)
         continue;
      var lr = lowerEl.getBoundingClientRect();
      //bird's centre must be within this pipe's column (i.e. it went into the
      //gap, not just brushed the front face) and be above the pipe's top
      if(birdcenterx > lr.left && birdcenterx < lr.right && box.bottom <= lr.top && lr.top < landingScreen)
      {
         landingScreen = lr.top; //land on the top of the bottom pipe instead
         landedPipeCenterx = (lr.left + lr.right) / 2;
         landedPipeHalfw = (lr.right - lr.left) / 2;
      }
   }

   //Mario warp-pipe easter egg: if the bird would land on a pipe AND it's near
   //the pipe's middle, there's a 50% chance it instead drops straight through
   //(it already renders behind the pipes, z-index 10) down to the ground, with
   //the pipe sound. "Near the middle" = within the central half of the pipe.
   if(landedPipeCenterx !== null &&
      Math.abs(birdcenterx - landedPipeCenterx) < landedPipeHalfw * 0.5 &&
      Math.random() < 0.5)
   {
      landingScreen = landTop; //fall through to the ground
      try { soundPipe.stop(); soundPipe.play(); } catch(e) { /* audio may be blocked */ }
   }

   //fall distance to that surface, in design units (translate happens inside the
   //scaled container, so divide the on-screen gap by the current scale)
   var movey = Math.max(0, (landingScreen - box.bottom) / gameScale);

   //resting landing position, plus the two decaying upward bounce peaks (negative
   //offset = up). Precomputed so the keyframes need no calc().
   elemPlayer.style.setProperty('--floor', movey + 'px');
   elemPlayer.style.setProperty('--peak1', (movey - 42) + 'px');
   elemPlayer.style.setProperty('--peak2', (movey - 16) + 'px');
   elemPlayer.style.setProperty('--birdrot', rotation + 'deg');
   //scale the fall time to the drop so a tiny floor tap and a long plunge both
   //look natural (clamped so it's never sluggish or instantaneous). Tuned slower
   //than before - a big drop used to finish in ~0.6s, which looked way too fast.
   var falldur = Math.min(1.15, Math.max(0.18, movey / 430));
   elemPlayer.style.setProperty('--falldur', falldur + 's');

   //phase 1: fall. On its animationend, phase 2: bounce (the birdbounce rule is
   //declared after birdfall, so adding it wins the animation and starts the
   //bounce exactly where the fall ended).
   elemPlayer.classList.remove('birdfall', 'birdbounce');
   void elemPlayer.offsetWidth; //force reflow so the animation always restarts
   elemPlayer.classList.add('birdfall');
   elemPlayer.addEventListener('animationend', function fallDone(e) {
      if(e.animationName !== 'birdfall')
         return;
      elemPlayer.removeEventListener('animationend', fallDone);
      elemPlayer.classList.add('birdbounce');
   });

   //it's time to change states. as of now we're considered ScoreScreen to disable left click/flying
   currentstate = states.ScoreScreen;

   //destroy our gameloops
   clearInterval(loopGameloop);
   clearInterval(loopPipeloop);
   loopGameloop = null;
   loopPipeloop = null;

   //Show the score screen exactly once. The original code chained showScore()
   //off the sound's "ended" event, which never fires on devices where the .ogg
   //codec is missing, audio is blocked, or the output is muted (common on
   //Chromebooks). That left the game frozen on a dead bird with no working
   //restart. A guaranteed fallback timer now always reveals the score screen,
   //so restart works regardless of whether the audio events ever fire.
   var scoreShown = false;
   function revealScore()
   {
      if(scoreShown)
         return;
      scoreShown = true;
      showScore();
   }

   //hard guarantee: reveal the score screen even if no audio event ever fires
   var scoreFallback = setTimeout(revealScore, 1500);

   //mobile browsers don't support buzz bindOnce event
   if(isIncompatible.any())
   {
      //skip right to showing score
      clearTimeout(scoreFallback);
      revealScore();
   }
   else
   {
      //play the hit sound (then the dead sound) and then show score. If the
      //"ended" events fire we reveal a touch sooner; if they don't, the
      //fallback timer above still reveals the score screen.
      try
      {
         soundHit.play().bindOnce("ended", function() {
            soundDie.play().bindOnce("ended", function() {
               clearTimeout(scoreFallback);
               revealScore();
            });
         });
      }
      catch(e)
      {
         clearTimeout(scoreFallback);
         revealScore();
      }
   }
}

function showScore()
{
   //unhide us
   $("#scoreboard").css("display", "block");

   //remove the big score
   setBigScore(true);

   //have they beaten their high score?
   if(score > highscore)
   {
      //yeah!
      highscore = score;
      //save it!
      localStorage.setItem("highscore", highscore);
   }

   //update the scoreboard
   setSmallScore();
   setHighScore();
   var wonmedal = setMedal();

   //SWOOSH!
   soundSwoosh.stop();
   soundSwoosh.play();

   //show the scoreboard
   $("#scoreboard").css({ y: '40px', opacity: 0 }); //move it down so we can slide it up
   $("#replay").css({ y: '40px', opacity: 0 });
   $("#scoreboard").transition({ y: '0px', opacity: 1}, 600, 'ease', function() {
      //When the animation is done, animate in the replay button and SWOOSH!
      soundSwoosh.stop();
      soundSwoosh.play();
      $("#replay").transition({ y: '0px', opacity: 1}, 600, 'ease');

      //also animate in the MEDAL! WOO!
      if(wonmedal)
      {
         $("#medal").css({ scale: 2, opacity: 0 });
         $("#medal").transition({ opacity: 1, scale: 1 }, 1200, 'ease');
      }
   });

   //make the replay button clickable
   replayclickable = true;
}

function doReplay() {
   //make sure we can only trigger once
   if(!replayclickable)
      return;
   else
      replayclickable = false;
   //SWOOSH!
   soundSwoosh.stop();
   soundSwoosh.play();

   //Return to the splash exactly once, even if the transition callback below
   //never fires (jquery.transit's "complete" callback can be skipped on some
   //browsers), so the restart can never get stuck half-way.
   var restarted = false;
   function backToSplash() {
      if(restarted)
         return;
      restarted = true;
      $("#scoreboard").css("display", "none");
      showSplash();
   }
   var restartFallback = setTimeout(backToSplash, 1200);

   //fade out the scoreboard
   $("#scoreboard").transition({ y: '-40px', opacity: 0}, 1000, 'ease', function() {
      clearTimeout(restartFallback);
      backToSplash();
   });
}

//Bind restart to click AND pointerup so a tap/click reliably restarts across
//mouse, trackpad and touch (the replayclickable guard prevents double-firing).
$("#replay").on("click pointerup", function(e) {
   e.preventDefault();
   doReplay();
});

//send an achievement unlock to the launcher (harmless if run standalone)
function postAchievement(id)
{
   try {
      window.parent.postMessage({ type: 'xbox-achievement', id: id }, '*');
   } catch(e) { /* not running inside the launcher */ }
}

function playerScore()
{
   score += 1;
   //play score sound
   soundScore.stop();
   soundScore.play();
   setBigScore();

   //notify the launcher to unlock achievements at score milestones
   if(score === 10)
      postAchievement('flappybird_bronze');
   if(score === 20)
      postAchievement('flappybird_silver');
   if(score === 30)
      postAchievement('flappybird_gold');
   if(score === 40)
      postAchievement('flappybird_platinum');
   if(score === 100)
      postAchievement('flappybird_tripledigits');
}

function updatePipes()
{
   //Do any pipes need removal?
   $(".pipe").filter(function() { return $(this).position().left <= -100; }).remove()

   //add a new pipe (top height + bottom height  + pipeheight == flyArea) and put it in our tracker
   var padding = 80;
   var constraint = flyArea - pipeheight - (padding * 2); //double padding (for top and bottom)
   var topheight = Math.floor((Math.random()*constraint) + padding); //add lower padding
   var bottomheight = (flyArea - pipeheight) - topheight;
   var newpipe = $('<div class="pipe animated"><div class="pipe_upper" style="height: ' + topheight + 'px;"></div><div class="pipe_lower" style="height: ' + bottomheight + 'px;"></div></div>');
   ($flyarea || $("#flyarea")).append(newpipe);
   pipes.push(newpipe);
}

var isIncompatible = {
   Android: function() {
   return navigator.userAgent.match(/Android/i);
   },
   BlackBerry: function() {
   return navigator.userAgent.match(/BlackBerry/i);
   },
   iOS: function() {
   return navigator.userAgent.match(/iPhone|iPad|iPod/i);
   },
   Opera: function() {
   return navigator.userAgent.match(/Opera Mini/i);
   },
   Safari: function() {
   return (navigator.userAgent.match(/OS X.*Safari/) && ! navigator.userAgent.match(/Chrome/));
   },
   Windows: function() {
   return navigator.userAgent.match(/IEMobile/i);
   },
   any: function() {
   return (isIncompatible.Android() || isIncompatible.BlackBerry() || isIncompatible.iOS() || isIncompatible.Opera() || isIncompatible.Safari() || isIncompatible.Windows());
   }
};
